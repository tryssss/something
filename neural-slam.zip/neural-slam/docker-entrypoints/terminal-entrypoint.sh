#!/bin/bash

source /opt/ros/indigo/setup.bash
source /usr/share/gazebo/setup.sh
source /root/catkin_ws/devel/setup.bash
rm /tmp/.X1-lock
export ROS_IP=172.17.0.2
export ROS_MASTER_URI=http://$ROS_IP:11311
Xvfb :1 -screen 0 1600x1200x16  &
export DISPLAY=:1.0
roslaunch gym_style_gazebo turtlebot_world.launch gui:=false
