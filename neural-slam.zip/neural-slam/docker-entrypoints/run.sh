sudo cp docker-compose.yml /neural-slam-docker-config/
