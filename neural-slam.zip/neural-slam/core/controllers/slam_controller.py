from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable

from core.controller import Controller

class SLAMController(Controller):
    def __init__(self, args):
        super(SLAMController, self).__init__(args)

        self.agent_type = args.agent_type
        self.enable_lstm = args.enable_lstm # NOTE: currently we only have the lstm version
        self.enable_continuous = args.enable_continuous
        self.enable_motion_model = args.enable_motion_model

        # build model
        if self.enable_lstm:
            self.in_2_hid = nn.LSTMCell(self.input_dim[0] + self.read_vec_dim, self.hidden_dim)

        self._reset()

    def _init_weights(self):
        pass

    def forward(self, input_vb, read_vec_vb, prev_action):
        if self.enable_lstm:
            self.lstm_hidden_vb = self.in_2_hid(torch.cat((input_vb[0].contiguous().view(-1, self.input_dim[0]), # NOTE: we only use the local view and leave out the map
                                                           read_vec_vb.contiguous().view(-1, self.read_vec_dim)), 1),
                                                self.lstm_hidden_vb)

            # we clip the controller states here
            # print("controler forward ---------------------->")
            # print("lstm_hidden_vb    --->", self.lstm_hidden_vb[0].data.abs().max(), self.lstm_hidden_vb[1].data.abs().max())
            # print("lstm_hidden_vb    --->", self.lstm_hidden_vb[0].data.max(), self.lstm_hidden_vb[1].data.max())
            # print("lstm_hidden_vb    --->", self.lstm_hidden_vb[0].data.abs().min(), self.lstm_hidden_vb[1].data.abs().min())
            # print("lstm_hidden_vb    --->", self.lstm_hidden_vb[0].data.min(), self.lstm_hidden_vb[1].data.min())
            # self.lstm_hidden_vb = [self.lstm_hidden_vb[0].clamp(min=-self.clip_value, max=self.clip_value),
            #                        self.lstm_hidden_vb[1].clamp(min=-self.clip_value, max=self.clip_value)]
            # print("lstm_hidden_vb    --->", self.lstm_hidden_vb[0].data.abs().max(), self.lstm_hidden_vb[1].data.abs().max())
            # print("lstm_hidden_vb    --->", self.lstm_hidden_vb[0].data.max(), self.lstm_hidden_vb[1].data.max())
            # print("lstm_hidden_vb    --->", self.lstm_hidden_vb[0].data.abs().min(), self.lstm_hidden_vb[1].data.abs().min())
            # print("lstm_hidden_vb    --->", self.lstm_hidden_vb[0].data.min(), self.lstm_hidden_vb[1].data.min())
            if self.enable_motion_model:    # normal hidden_vb
                return self.lstm_hidden_vb[0]
            else:                           # this case prev_action is concat into the hidden_vb
                return torch.cat((self.lstm_hidden_vb[0], Variable(torch.Tensor([prev_action])).view(1, 1)), 1)
