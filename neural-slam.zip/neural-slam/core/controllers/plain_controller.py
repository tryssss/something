from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable

from core.controller import Controller

class PlainController(Controller):
    def __init__(self, args):
        super(PlainController, self).__init__(args)

        self.agent_type = args.agent_type
        self.enable_lstm = args.enable_lstm # NOTE: currently we only have the lstm version
        self.enable_continuous = args.enable_continuous
        self.enable_motion_model = args.enable_motion_model
        self.enable_nav_lstms_0 = args.enable_nav_lstms_0
        self.enable_nav_lstms_1 = args.enable_nav_lstms_1

        # build model
        # # option 1: w/  linear layers
        # self.preprocess1 = nn.Linear(self.input_dim[0] + self.input_dim[1], self.hidden_dim)
        # self.preprocess2 = nn.Linear(self.hidden_dim, self.hidden_dim)
        # if self.enable_lstm:
        #     self.in_2_hid = nn.LSTMCell(self.hidden_dim, self.hidden_dim, 1)
        # # option 2: w/o linear layers
        # if self.enable_lstm:
        #     # # option 2.1: input local + map
        #     # self.in_2_hid = nn.LSTMCell(self.input_dim[0] + self.input_dim[1], self.hidden_dim, 1)
        #     # option 2.2: input local
        #     self.in_2_hid = nn.LSTMCell(self.input_dim[0], self.hidden_dim, 1)
        # option 3: w/o linear layers, 2 lstms
        if self.enable_lstm:
            if self.enable_motion_model:
                if self.enable_nav_lstms_0:     # 2 lstms, motion into 1st one
                    self.in_2_hid_0 = nn.LSTMCell(self.input_dim[0] + 1, self.hidden_dim)
                    self.in_2_hid_1 = nn.LSTMCell(self.hidden_dim,       self.hidden_dim)
                elif self.enable_nav_lstms_1:   # 2 lstms, motion into 2nd one
                    self.in_2_hid_0 = nn.LSTMCell(self.input_dim[0],     self.hidden_dim)
                    self.in_2_hid_1 = nn.LSTMCell(self.hidden_dim + 1,   self.hidden_dim)
                else:                           # 1 lstm, motion directly cat w/ input
                    self.in_2_hid = nn.LSTMCell(self.input_dim[0] + 1,   self.hidden_dim)
            else:
                self.in_2_hid = nn.LSTMCell(self.input_dim[0], self.hidden_dim)

        self._reset()

    def _reset(self):           # NOTE: should be called at each child's __init__
        self._init_weights()
        self.type(self.dtype)   # put on gpu if possible
        self.print_model()
        # reset internal states
        if self.enable_lstm:
            self.lstm_hidden_ts = []
            if self.enable_continuous:
                self.lstm_hidden_ts.append(torch.zeros(2, self.hidden_dim))
                self.lstm_hidden_ts.append(torch.zeros(2, self.hidden_dim))
            else:
                if self.enable_motion_model:    # here means pass action into 2nd lstm
                    if self.enable_nav_lstms_0 or self.enable_nav_lstms_1: # 2 lstms, motion into 1st/2nd one
                        self.lstm_hidden_ts.append(torch.zeros(2, self.hidden_dim))
                        self.lstm_hidden_ts.append(torch.zeros(2, self.hidden_dim))
                    else:                       # 1 lstm, motion directly cat w/ input
                        self.lstm_hidden_ts.append(torch.zeros(1, self.hidden_dim))
                        self.lstm_hidden_ts.append(torch.zeros(1, self.hidden_dim))
                else:
                    self.lstm_hidden_ts.append(torch.zeros(1, self.hidden_dim))
                    self.lstm_hidden_ts.append(torch.zeros(1, self.hidden_dim))
        self._reset_states_episode()
        self._reset_states_rollout()

    def _init_weights(self):
        pass

    def forward(self, input_vb, prev_action):
        if isinstance(input_vb, list):  # NOTE: we directly cat the local view and the map
            # # option 2.1: input local + map
            # input_vb = torch.cat(input_vb, 1)
            # option 2.2: input local
            input_vb = input_vb[0]
        # # option 1: w/  linear layers
        # input_vb = F.relu(self.preprocess1(input_vb))
        # input_vb = F.relu(self.preprocess2(input_vb))
        # if self.enable_lstm:
        #     self.lstm_hidden_vb = self.in_2_hid(input_vb,
        #                                         self.lstm_hidden_vb)
        #
        #     # we clip the controller states here
        #     self.lstm_hidden_vb = [self.lstm_hidden_vb[0].clamp(min=-self.clip_value, max=self.clip_value),
        #                            self.lstm_hidden_vb[1].clamp(min=-self.clip_value, max=self.clip_value)]
        #     return self.lstm_hidden_vb[0]
        # option 3: w/o linear layers, 2 lstms
        if self.enable_lstm:
            if self.enable_motion_model:
                if self.enable_nav_lstms_0:  # 2 lstms, motion into 1st one
                    # first we need to split the lstm_hidden_vb for 2 lstm layers
                    h_0, c_0 = torch.split(self.lstm_hidden_vb[0], 1)
                    h_1, c_1 = torch.split(self.lstm_hidden_vb[1], 1)
                    h_0, c_0 = self.in_2_hid_0(torch.cat((input_vb, Variable(torch.Tensor([prev_action])).view(1, 1)), 1),
                                               (h_0, c_0))
                    h_1, c_1 = self.in_2_hid_1(h_0,
                                               (h_1, c_1))

                    # we clip the controller states here
                    self.lstm_hidden_vb = [torch.cat((h_0, c_0), 0).clamp(min=-self.clip_value, max=self.clip_value),
                                           torch.cat((h_1, c_1), 0).clamp(min=-self.clip_value, max=self.clip_value)]
                    return h_1.clamp(min=-self.clip_value, max=self.clip_value)
                elif self.enable_nav_lstms_1:# 2 lstms, motion into 2nd one
                    # first we need to split the lstm_hidden_vb for 2 lstm layers
                    h_0, c_0 = torch.split(self.lstm_hidden_vb[0], 1)
                    h_1, c_1 = torch.split(self.lstm_hidden_vb[1], 1)
                    h_0, c_0 = self.in_2_hid_0(input_vb,
                                               (h_0, c_0))
                    h_1, c_1 = self.in_2_hid_1(torch.cat((h_0, Variable(torch.Tensor([prev_action])).view(1, 1)), 1),
                                               (h_1, c_1))

                    # we clip the controller states here
                    self.lstm_hidden_vb = [torch.cat((h_0, c_0), 0).clamp(min=-self.clip_value, max=self.clip_value),
                                           torch.cat((h_1, c_1), 0).clamp(min=-self.clip_value, max=self.clip_value)]
                    return h_1.clamp(min=-self.clip_value, max=self.clip_value)
                else:                       # 1 lstm, motion directly cat w/ input
                    self.lstm_hidden_vb = self.in_2_hid(torch.cat((input_vb, Variable(torch.Tensor([prev_action])).view(1, 1)), 1),
                                                        self.lstm_hidden_vb)

                    # we clip the controller states here
                    self.lstm_hidden_vb = [self.lstm_hidden_vb[0].clamp(min=-self.clip_value, max=self.clip_value),
                                           self.lstm_hidden_vb[1].clamp(min=-self.clip_value, max=self.clip_value)]
                    return self.lstm_hidden_vb[0]
            else:
                self.lstm_hidden_vb = self.in_2_hid(input_vb,
                                                    self.lstm_hidden_vb)

                # we clip the controller states here
                self.lstm_hidden_vb = [self.lstm_hidden_vb[0].clamp(min=-self.clip_value, max=self.clip_value),
                                       self.lstm_hidden_vb[1].clamp(min=-self.clip_value, max=self.clip_value)]
                return self.lstm_hidden_vb[0]
