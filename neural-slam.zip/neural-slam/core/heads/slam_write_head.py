from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from utils.helpers import tile_ts
from core.heads.slam_head import SLAMHead

class SLAMWriteHead(SLAMHead):
    def __init__(self, args):
        super(SLAMWriteHead, self).__init__(args)
        # params
        if self.visualize:
            self.win_head = "win_write_head"

        # buid model: add additional outs for write
        # for access
        if self.enable_motion_model:    # normal hidden_vb
            self.hid_2_erase = nn.Linear(self.hidden_dim, self.num_heads * self.mem_dep)
            self.hid_2_add   = nn.Linear(self.hidden_dim, self.num_heads * self.mem_dep)
        else:                           # this case prev_action is concat into the hidden_vb
            self.hid_2_erase = nn.Linear(self.hidden_dim + 1, self.num_heads * self.mem_dep)
            self.hid_2_add   = nn.Linear(self.hidden_dim + 1, self.num_heads * self.mem_dep)

        # logging
        self.logger.warning("<-----------------------------------> WriteHeads: {" + str(self.num_heads) + " heads}")
        self.logger.warning(self)

        # reset
        self._reset()

    def visual(self):
        if self.visualize:      # here we visualize the wl_curr of the first head of the first batch
            # self.win_head = self.vis.heatmap(self.wl_curr_vb.data[0][0].clone().cpu().numpy().reshape(self.mem_hei, self.mem_wid), env=self.refs, win=self.win_head, opts=dict(title="write_head"))
            self.win_head = self.vis.heatmap(self.wl_curr_vb.data[0][0].view(self.mem_hei, self.mem_wid).numpy()[::-1, :], env=self.refs, win=self.win_head, opts=dict(title="write_head"))
            # self.win_head = self.vis.image(tile_ts(self.wl_curr_vb.data[0][0].view(self.mem_hei, self.mem_wid)), env=self.refs, win=self.win_head, opts=dict(title="write_head"))
        if self.mode == 2 and self.visualize:
            # write_head_name = self.img_dir + "write_head_%04d.jpg" % self.frame_ind
            # self.imsave(write_head_name, np.transpose(self._mat_to_img(self._expand_mat(self.wl_curr_vb.data[0][0].view(self.mem_hei, self.mem_wid).numpy())), (1, 2, 0)))
            # self.logger.warning("Saved  WriteHead@ Step: " + str(self.frame_ind) + " To: " + write_head_name)
            self.frame_ind += 1

    def forward(self, hidden_vb, memory_vb, prev_action):
        # print("================================================================= write head")
        # content & location focus
        super(SLAMWriteHead, self).forward(hidden_vb, memory_vb, prev_action)
        self.wl_prev_vb = self.wl_curr_vb
        # access
        self.erase_vb = F.sigmoid(self.hid_2_erase(hidden_vb)).view(-1, self.num_heads, self.mem_dep)
        # self.add_vb   = F.tanh(self.hid_2_add(hidden_vb)).view(-1, self.num_heads, self.mem_dep)
        self.add_vb   = self.hid_2_add(hidden_vb).view(-1, self.num_heads, self.mem_dep)
        return self._access(memory_vb)

    def _access(self, memory_vb): # write
        """
        variables needed:
            wl_curr_vb: [batch_size x num_heads x(mem_hei x mem_wid)]
            erase_vb:   [batch_size x num_heads x mem_dep]
                     -> /in (0, 1)
            add_vb:     [batch_size x num_heads x mem_dep]
                     -> w/ no restrictions in range
            memory_vb:  [batch_size x(mem_hei x mem_wid)x mem_dep]
        returns:
            memory_vb:  [batch_size x(mem_hei x mem_wid)x mem_dep]
        NOTE: IMPORTANT: https://github.com/deepmind/dnc/issues/10
        """

        # first let's do erasion
        weighted_erase_vb = torch.bmm(self.wl_curr_vb.contiguous().view(-1, self.mem_hei * self.mem_wid, 1),
                                      self.erase_vb.contiguous().view(-1, 1, self.mem_dep)).view(-1, self.num_heads, self.mem_hei * self.mem_wid, self.mem_dep)
        # TODO: we now remove the multi-head support for this: https://discuss.pytorch.org/t/nan-in-backward-if-prod-is-used/564
        # keep_vb = torch.prod(1. - weighted_erase_vb, dim=1)
        keep_vb = 1. - weighted_erase_vb
        memory_vb = memory_vb * keep_vb
        # finally let's write (do addition)
        return memory_vb + torch.bmm(self.wl_curr_vb.transpose(1, 2), self.add_vb)
