from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import numpy as np
import torch

from utils.helpers import tile_ts
from core.heads.slam_head import SLAMHead

class SLAMReadHead(SLAMHead):
    def __init__(self, args):
        super(SLAMReadHead, self).__init__(args)
        # params
        if self.visualize:
            self.win_head = "win_read_head"
        # logging
        self.logger.warning("<-----------------------------------> ReadHeads:  {" + str(self.num_heads) + " heads}")
        self.logger.warning(self)

        # reset
        self._reset()

    def visual(self):
        if self.visualize:      # here we visualize the wl_curr of the first head of the first batch
            # self.win_head = self.vis.heatmap(self.wl_curr_vb.data[0][0].clone().cpu().numpy().reshape(self.mem_hei, self.mem_wid), env=self.refs, win=self.win_head, opts=dict(title="read_head"))
            self.win_head = self.vis.heatmap(self.wl_curr_vb.data[0][0].view(self.mem_hei, self.mem_wid).numpy()[::-1, :], env=self.refs, win=self.win_head, opts=dict(title="read_head"))
            # self.win_head = self.vis.image(tile_ts(self.wl_curr_vb.data[0][0].view(self.mem_hei, self.mem_wid)), env=self.refs, win=self.win_head, opts=dict(title="read_head"))
        if self.mode == 2 and self.visualize:
            # read_head_name = self.img_dir + "read_head_%04d.jpg" % self.frame_ind
            # self.imsave(read_head_name, np.transpose(self._mat_to_img(self._expand_mat(self.wl_curr_vb.data[0][0].view(self.mem_hei, self.mem_wid).numpy())), (1, 2, 0)))
            # self.logger.warning("Saved  ReadHead @ Step: " + str(self.frame_ind) + " To: " + read_head_name)
            self.frame_ind += 1

    def forward(self, hidden_vb, memory_vb, prev_action):
        # print("================================================================= read  head")
        # content & location focus
        super(SLAMReadHead, self).forward(hidden_vb, memory_vb, prev_action)
        self.wl_prev_vb = self.wl_curr_vb
        # access
        return self._access(memory_vb)

    def _access(self, memory_vb): # read
        """
        variables needed:
            wl_curr_vb:   [batch_size x num_heads x(mem_hei x mem_wid)]
                       -> location focus of {t}
            memory_vb:    [batch_size x            (mem_hei x mem_wid)x mem_dep]
        returns:
            read_vec_vb:  [batch_size x num_heads                     x mem_dep]
                       -> read vector of {t}
        """
        return torch.bmm(self.wl_curr_vb, memory_vb)
