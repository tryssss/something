from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable

from core.head import Head
from utils.similarities import batch_cosine_sim
from utils.kernels import init_particle_weights_ts
from utils.motion_model import MotionModel
from utils.ops import stable_softmax

class SLAMHead(Head):
    def __init__(self, args):
        super(SLAMHead, self).__init__(args)

        # build model
        if self.enable_motion_model:    # normal hidden_vb
            # for content focus
            self.hid_2_key   = nn.Linear(self.hidden_dim, self.num_heads * self.mem_dep)
            self.hid_2_beta  = nn.Linear(self.hidden_dim, self.num_heads * 1)
            # for location focus
            self.hid_2_gate  = nn.Linear(self.hidden_dim, self.num_heads * 1)
            self.hid_2_shift = nn.Linear(self.hidden_dim, self.num_heads * self.num_allowed_shifts * self.num_allowed_shifts)
            self.hid_2_gamma = nn.Linear(self.hidden_dim, self.num_heads * 1)
        else:                           # this case prev_action is concat into the hidden_vb
            # for content focus
            self.hid_2_key   = nn.Linear(self.hidden_dim + 1, self.num_heads * self.mem_dep)
            self.hid_2_beta  = nn.Linear(self.hidden_dim + 1, self.num_heads * 1)
            # for location focus
            self.hid_2_gate  = nn.Linear(self.hidden_dim + 1, self.num_heads * 1)
            self.hid_2_shift = nn.Linear(self.hidden_dim + 1, self.num_heads * self.num_allowed_shifts * self.num_allowed_shifts)
            self.hid_2_gamma = nn.Linear(self.hidden_dim + 1, self.num_heads * 1)

        self.motion_model = MotionModel(args.env_type, args.root_dir, self.mem_hei, self.mem_wid, self.laser_len, self.output_dim)  # load precalculated indices

    def _reset_states_episode(self, init_pose=[2,2,0], training=True): # NOTE: we overload this func here cos we want a bias initialization of the weights
        not_training = not training
        # option 1: always initialize the kernel
        self.wl_prev_ts = init_particle_weights_ts(self.mem_hei, self.mem_wid, self.laser_len, init_pose).unsqueeze(0).unsqueeze(0).expand(self.batch_size, self.num_heads, self.mem_hei, self.mem_wid)
        self.wl_prev_ts = self.wl_prev_ts.contiguous().view(self.batch_size, self.num_heads, self.mem_hei * self.mem_wid)
        # # option 2: only   initialize the kernel when enable_motion_model=True
        # if self.enable_motion_model:    # then we use the initial pose of the agent to initialize the head weights
        #     self.wl_prev_ts = init_particle_weights_ts(self.mem_hei, self.mem_wid, self.laser_len, init_pose).unsqueeze(0).unsqueeze(0).expand(self.batch_size, self.num_heads, self.mem_hei, self.mem_wid)
        #     self.wl_prev_ts = self.wl_prev_ts.view(self.batch_size, self.num_heads, self.mem_hei * self.mem_wid)
        # else:                           # then we just always bias the initlaization to the top-left pixel
        #     pass                        # don't need to do anything here
        self.wl_prev_vb = Variable(self.wl_prev_ts, volatile=not_training).type(self.dtype) # num_heads x mem_hei x mem_wid
        self.wl_curr_vb = self.wl_prev_vb                                                   # num_heads x mem_hei x mem_wid

    def _reset(self):   # NOTE: we overload this func here cos we want a bias initialization of the weights
        # self._init_weights()
        self.type(self.dtype)   # put on gpu if possible
        # NOTE: when reset, we put all the weights onto its current sensor range
        # TODO: check here again
        # reset internal states
        # option 1: always initialize the kernel
        self.wl_prev_ts = init_particle_weights_ts(self.mem_hei, self.mem_wid, self.laser_len).unsqueeze(0).unsqueeze(0).expand(self.batch_size, self.num_heads, self.mem_hei, self.mem_wid)
        # # option 2: only   initialize the kernel when enable_motion_model=True
        # if self.enable_motion_model:    # then we use the initial pose of the agent to initialize the head weights
        #     self.wl_prev_ts = init_particle_weights_ts(self.mem_hei, self.mem_wid, self.laser_len).unsqueeze(0).unsqueeze(0).expand(self.batch_size, self.num_heads, self.mem_hei, self.mem_wid)
        # else:
        #     self.wl_prev_ts = torch.zeros(self.batch_size, self.num_heads, self.mem_hei * self.mem_wid)
        #     self.wl_prev_ts[:, :, 0] = 1
        self.wl_prev_ts = self.wl_prev_ts.contiguous().view(self.batch_size, self.num_heads, self.mem_hei * self.mem_wid)
        self._reset_states_episode()
        self._reset_states_rollout()

    def _expand_mat(self, mat, expand_by=None):
        if expand_by is None: expand_by = 21#self.grid_siz
        mat = np.repeat(mat, expand_by, axis=0)
        mat = np.repeat(mat, expand_by, axis=1)
        return mat

    def _mat_to_img(self, mat):
        return 255. - np.tile(mat, (3, 1, 1)) * 255.

    def _content_focus(self, memory_vb):
        """
        variables needed:
            key_vb:    [batch_size x num_heads                     x mem_dep]
                    -> similarity key vector, to compare to each drawer in memory
                    -> by cosine similarity
            beta_vb:   [batch_size x num_heads x 1]
                    -> NOTE: refer here: https://github.com/deepmind/dnc/issues/9
                    -> \in (1, +inf) after oneplus(); similarity key strength
                    -> amplify or attenuate the pecision of the focus
            memory_vb: [batch_size             x(mem_hei x mem_wid)x mem_dep]
        returns:
            wc_vb:     [batch_size x num_heads x(mem_hei x mem_wid)]
                    -> the attention weight by content focus
        """
        K_vb = batch_cosine_sim(self.key_vb, memory_vb)     # [batch_size x num_heads x (mem_hei x mem_wid)]
        self.wc_vb = K_vb * self.beta_vb.expand_as(K_vb)    # [batch_size x num_heads x (mem_hei x mem_wid)]
        self.wc_vb = stable_softmax(self.wc_vb.transpose(0, 2)).transpose(0, 2)

    def _shift(self, wg_vb, shift_vb):
        """
        variables needed:
            wg_vb:    [batch_size x num_heads x(mem_hei x mem_wid)]
            shift_vb: [batch_size x num_heads x num_allowed_shifts x num_allowed_shifts]
                   -> sum=1; the shift weight vector
        returns:
            ws_vb:    [batch_size x num_heads x(mem_hei x mem_wid)]
                   -> the attention weight by location focus
        """
        batch_size = wg_vb.size(0)
        wg_vb = wg_vb.view(self.batch_size, self.num_heads, self.mem_hei, self.mem_wid)
        input_dim = wg_vb.size(2); assert input_dim == self.mem_hei
        filter_dim = shift_vb.size(2); assert filter_dim == self.num_allowed_shifts

        ws_vb = None
        for i in range(batch_size): # for each head in each batch, the kernel is different ... seems there's no other way by doing the loop here
            for j in range(self.num_heads):
                ws_tmp_vb = F.conv2d(wg_vb[i][j].unsqueeze(0).unsqueeze(0),
                                     shift_vb[i][j].unsqueeze(0).unsqueeze(0),
                                     padding=self.num_allowed_shifts//2)
                if ws_vb is None:
                    ws_vb = ws_tmp_vb
                else:
                    ws_vb = torch.cat((ws_vb, ws_tmp_vb), 0)
        ws_vb = ws_vb.view(-1, self.num_heads, self.mem_hei * self.mem_wid)
        return ws_vb

    def _apply_motion(self, prev_action):
        """
        variables needed:
            prev_action: the last action taken
            wl_prev_vb: [batch_size x num_heads x(mem_hei x mem_wid)]
        returns:
            wl_prev_vb: [batch_size x num_heads x(mem_hei x mem_wid)]
                     -> the attention weight after forward motion
        """
        # TODO: should first apply motion model here to wl_prev_vb then gate those two together
        # TODO: and maybe we would also want that shift later for cases where there might be noise
        # TODO: then the other gamma operation would also make sense here
        # TODO: and we should make a detailed visualization here to check the correctness of every step
        # TODO: and how to actually get reward from the memory
        # print("----------------------------------------------------------------- apply motion > ", prev_action)
        # print("self.wl_prev_vb")
        # print(self.wl_prev_vb.data.view(self.mem_hei, self.mem_wid))
        self.wl_prev_vb = self.motion_model.apply_motion(self.wl_prev_vb, [prev_action])
        # print("self.wl_prev_vb")
        # print(self.wl_prev_vb.data.view(self.mem_hei, self.mem_wid))

    def _location_focus(self, prev_action):
        """
        variables needed:
            prev_action: the last action taken
            wl_prev_vb: [batch_size x num_heads x(mem_hei x mem_wid)]
            wc_vb:      [batch_size x num_heads x(mem_hei x mem_wid)]
            gate_vb:    [batch_size x num_heads x 1]
                     -> \in (0, 1); the interpolation gate
            shift_vb:   [batch_size x num_heads x num_allowed_shifts x num_allowed_shifts]
                     -> sum=1; the shift weight vector
            gamma_vb:   [batch_size x num_heads x 1]
                     -> >=1; the sharpening vector
        returns:
            wl_curr_vb: [batch_size x num_heads x(mem_hei x mem_wid)]
                     -> the attention weight by location focus
        """
        # we first apply motion model to weights from the last time step
        if self.enable_motion_model:
            self._apply_motion(prev_action)   # TODO: should modify for continuous case
        # print("self.gate_vb:", self.gate_vb)
        self.gate_vb = self.gate_vb.expand_as(self.wc_vb)
        wg_vb = self.wc_vb * self.gate_vb + self.wl_prev_vb * (1. - self.gate_vb)
        # print("after gating:")
        # print(wg_vb.data.view(self.mem_hei, self.mem_wid))
        # print("self.shift_vb:", self.shift_vb)
        ws_vb = self._shift(wg_vb, self.shift_vb)
        # print("self.gamma_vb:", self.gamma_vb)
        wp_vb = ws_vb.pow(self.gamma_vb.expand_as(ws_vb))
        # print("wp_vb.sum(2) ------>", wp_vb.sum(2))
        self.wl_curr_vb = wp_vb / (wp_vb.sum(2) + 1e-6).expand_as(wp_vb)
        # self.wl_curr_vb = self.wl_prev_vb   # TODO: delete this line & uncomment above

    def forward(self, hidden_vb, memory_vb, prev_action):
        # outputs for computing addressing for heads
        # NOTE: to be consistent w/ the dnc paper, we use
        # NOTE: sigmoid to constrain to [0, 1]
        # NOTE: oneplus to constrain to [1, +inf]
        # self.key_vb   = F.tanh(self.hid_2_key(hidden_vb)).view(-1, self.num_heads, self.mem_dep)    # TODO: relu to bias the memory to store positive values ??? check again
        self.key_vb   = self.hid_2_key(hidden_vb).view(-1, self.num_heads, self.mem_dep)
        self.beta_vb  = F.softplus(self.hid_2_beta(hidden_vb)).view(-1, self.num_heads, 1)          # beta >=1: https://github.com/deepmind/dnc/issues/9
        self.gate_vb  = F.sigmoid(self.hid_2_gate(hidden_vb)).view(-1, self.num_heads, 1)           # gate /in (0, 1): interpolation gate, blend wl_{t-1} & wc
        self.shift_vb = stable_softmax(self.hid_2_shift(hidden_vb).view(-1, self.num_heads, self.num_allowed_shifts * self.num_allowed_shifts).transpose(0, 2)).transpose(0, 2).contiguous().view(-1, self.num_heads, self.num_allowed_shifts, self.num_allowed_shifts)   # shift: /sum=1
        self.gamma_vb = (1. + F.softplus(self.hid_2_gamma(hidden_vb))).view(-1, self.num_heads, 1)  # gamma >= 1: sharpen the final weights # TODO: check the 10 here again

        # now we compute the addressing mechanism
        self._content_focus(memory_vb)
        # print("content   focus   ---------------------->")
        # print("self.wc_vb        --->", self.wc_vb.data.max(), self.wc_vb.data.min())
        self._location_focus(prev_action)
        # print("location  focus   ---------------------->")
        # print("self.wl_curr_vb   --->", self.wl_curr_vb.data.max(), self.wl_curr_vb.data.min())
