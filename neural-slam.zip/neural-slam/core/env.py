from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import numpy as np
import torch

from utils.helpers import Experience            # NOTE: here state0 is always "None"

class Env(object):
    def __init__(self, args, env_ind=0):
        self.logger     = args.logger
        self.ind        = env_ind               # NOTE: for creating multiple environment instances
        # general setup
        self.mode       = args.mode             # NOTE: save frames when mode=2
        if self.mode == 2:
            try:
                import scipy.misc
                self.imsave = scipy.misc.imsave
            except ImportError as e: self.logger.warning("WARNING: scipy.misc not found")
            self.img_dir = args.root_dir + "/imgs/"
            self.frame_ind = 0
        self.seed       = args.seed + self.ind  # NOTE: so to give a different seed to each instance
        self.visualize  = args.visualize
        if self.visualize:
            self.vis        = args.vis
            self.refs       = args.refs
            self.win_state1 = "win_state1"

        self.env_type   = args.env_type
        self.game       = args.game
        self._reset_experience()

        self.logger.warning("<-----------------------------======> Env:")
        self.logger.warning("Creating {" + self.env_type + " | " + self.game + "} w/ Seed: " + str(self.seed))

    def _reset_experience(self):
        self.exp_state0 = None  # NOTE: always None in this module
        self.exp_action = None
        self.exp_reward = None
        self.exp_state1 = None
        self.exp_terminal1 = None

    def _get_experience(self):
        return Experience(state0 = self.exp_state0, # NOTE: here state0 is always None
                          action = self.exp_action,
                          reward = self.exp_reward,
                          state1 = self._preprocessState(self.exp_state1),
                          terminal1 = self.exp_terminal1)

    def _preprocessState(self, state):
        raise NotImplementedError("not implemented in base calss")

    @property
    def state_shape(self):
        raise NotImplementedError("not implemented in base calss")

    @property
    def action_dim(self):
        return self.env.action_space.n

    def render(self):       # render using the original gl window
        raise NotImplementedError("not implemented in base calss")

    def _expand_mat(self, mat, expand_by=None):
        if expand_by is None: expand_by = self.grid_siz
        mat = np.repeat(mat, expand_by, axis=0)
        mat = np.repeat(mat, expand_by, axis=1)
        return mat

    def _mat_to_img(self, mat):
        return 255. - np.tile(mat, (3, 1, 1)) * 255.

    def _draw_dir(self, img, grid_siz=None):
        if grid_siz is None: grid_siz = self.grid_siz
        bot_y_pixel = self.bot_pose[0] * grid_siz + grid_siz // 2
        bot_x_pixel = self.bot_pose[1] * grid_siz + grid_siz // 2
        bot_dir     = self.bot_pose[2]
        dir_len = grid_siz // 2 + 1
        dir_wid = 7
        dir_edg = dir_wid // 2
        if bot_dir == 0:   # >: facing right
            dir_y_min, dir_y_max, dir_x_min, dir_x_max = bot_y_pixel - dir_edg, bot_y_pixel + dir_edg, bot_x_pixel - dir_edg, bot_x_pixel + (dir_len - 1)
        elif bot_dir == 1: # V: facing down
            dir_y_min, dir_y_max, dir_x_min, dir_x_max = bot_y_pixel - dir_edg, bot_y_pixel + (dir_len - 1), bot_x_pixel - dir_edg, bot_x_pixel + dir_edg
        elif bot_dir == 2: # <: facing left
            dir_y_min, dir_y_max, dir_x_min, dir_x_max = bot_y_pixel - dir_edg, bot_y_pixel + dir_edg, bot_x_pixel - (dir_len - 1), bot_x_pixel + dir_edg
        elif bot_dir == 3: # ^: facing up
            dir_y_min, dir_y_max, dir_x_min, dir_x_max = bot_y_pixel - (dir_len - 1), bot_y_pixel + dir_edg, bot_x_pixel - dir_edg, bot_x_pixel + dir_edg
        img[dir_y_min:dir_y_max+1, dir_x_min:dir_x_max+1] = 1
        return img

    def visual(self):       # visualize onto visdom
        raise NotImplementedError("not implemented in base calss")

    def reset(self):
        raise NotImplementedError("not implemented in base calss")

    def step(self, action):
        raise NotImplementedError("not implemented in base calss")
