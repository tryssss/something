from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import numpy as np
from random import randint
import torch

from core.env import Env

class GridWorldEnv(Env): # give back local views
    def __init__(self, args, env_ind=0):
        super(GridWorldEnv, self).__init__(args, env_ind)

        # grid-world-specific params
        self.enable_random_init_pose = args.enable_random_init_pose
        self.enable_internal_explore_reward = args.enable_internal_explore_reward
        self.sensor_type = args.sensor_type
        self.laser_len = args.laser_len
        self.grid_siz = args.grid_siz
        self.act_set  = args.act_set

        self.view_hei = self.laser_len
        self.view_wid = self.laser_len * 2 - 1
        self.course_ind = 0
        self.world = None
        self.local_view_mask = np.ones([self.view_hei, self.view_wid])
        if self.sensor_type == "laser":
            self.local_view_mask[0][0] = 0 # limited by the laser scanner range
            self.local_view_mask[1][0] = 0 # limited by the laser scanner range
            self.local_view_mask[0][1] = 0 # limited by the laser scanner range
            self.local_view_mask[0][3] = 0 # limited by the laser scanner range
            self.local_view_mask[0][4] = 0 # limited by the laser scanner range
            self.local_view_mask[1][4] = 0 # limited by the laser scanner range

        if self.game == "simple":       # just train on several predefined worlds
            from utils.worlds import worlds as worlds
            self.worlds = worlds
            self.map_siz = self.worlds[len(self.worlds)-1].shape[0]
            self.sensor_len = self.laser_len
        elif self.game == "curriculum": # train on randomly generated worlds
            from utils.grid_world_generator import GridWorldGenerator
            self.worlds = GridWorldGenerator(self.laser_len)
            self.map_siz = self.worlds.map_siz
            self.sensor_len = self.worlds.sensor_len

        # NOTE: we make this assumption here that bot always starts just besides the edge facing right
        # NOTE: we make sure all worlds are padded w/ self.view_len-1 1's on the edge
        # NOTE: bot_dir here is [0, 3]
        self.bot_pose_reset = np.array([self.laser_len - 1, self.laser_len - 1, 0]) # [y, x, dir]
        self.bot_pose       = self.bot_pose_reset.copy()                            # [y, x, dir]
        self.bot_pose_old   = self.bot_pose_reset.copy()                            # [y, x, (dir: not really used here)]

        # action
        if self.act_set == 0:   # go TODO: not implemented yet
            self.act_num = 5
            self.act_pos_ind = np.array([
                [ 0,  0], # 0: o | STILL
                [-1,  0], # 1: ^ | UP
                [ 1,  0], # 2: V | DOWN
                [ 0, -1], # 3: < | LEFT
                [ 0,  1]  # 4: > | RIGHT
            ])
        elif self.act_set == 1: # turn-go
            self.act_num = 4
            self.dir_num = 4
            self.act_pos_ind = np.array([
                # NOTE: if act_ind <  3 then bot_dir += [act_ind][2]
                # NOTE: if act_ind == 3 then use act_pos_ind[act_ind+bot_dir][y/x]
                [ 0,  0,  0], # 0:       o | STILL
                [ 0,  0, -1], # 1:       < | TURN LEFT
                [ 0,  0,  1], # 2:       > | TURN RIGHT
                [ 0,  1,  0], # 3: dir:0 > | GO STRAIGHT
                [ 1,  0,  0], # 4: dir:1 V | GO STRAIGHT
                [ 0, -1,  0], # 5: dir:2 < | GO STRAIGHT
                [-1,  0,  0]  # 6: dir:3 ^ | GO STRAIGHT
            ])

        # action space setup
        self.actions     = range(self.action_dim)
        self.logger.warning("Action Space: %s", self.actions)

        # state space setup
        self.logger.warning("State  Space: %s", self.state_shape)

        # additional display setup
        if self.visualize:
            self.win_world  = "win_world"   # the whole world
            self.win_local  = "win_local"   # state1[0]: local view
            self.win_map    = "win_map"     # state1[1]: explored areas in the map
            self.win_target = "win_target"  # how we want the final map to look like

    def prep_eval_pregen_worlds(self, eval_pregen_worlds_fil):
        self.game = "eval_pregen_worlds"
        self.worlds = torch.load(eval_pregen_worlds_fil)
        self.map_siz = self.worlds[len(self.worlds)-1][0].shape[0]
        self.sensor_len = self.laser_len
        self.reset_eval_pregen_worlds_ind()

    def reset_eval_pregen_worlds_ind(self): # NOTE: to be called at the beginning of each evaluation, to always evaluate from the 1st episode in this current course
        self.eval_pregen_worlds_ind = 0

    def _reset_experience(self):
        self.exp_state0 = None  # NOTE: always None in this module
        self.exp_action = None
        self.exp_reward = None
        self.exp_state1 = []    # [0]: local view, [1]: map
        self.exp_terminal1 = None

    # def _preprocessState(self, state, action):
    #     # NOTE: then we need to pad the smaller maps with 0.5's on the edges
    #     padded_map = np.ones([self.map_siz, self.map_siz]) * 0.5
    #     current_map_siz = state[1].shape[0]
    #     padded_map[0:current_map_siz, 0:current_map_siz] = state[1]
    #     motion_command = []
    #     motion_command.append(action)   # 0: action_ind
    #     if action == 0:                 # 1: linear; 2: angular
    #         motion_command.append(0)
    #         motion_command.append(np.deg2rad(0.))
    #     elif action == 1:
    #         motion_command.append(0)
    #         motion_command.append(np.deg2rad(90.))
    #     elif action == 2:
    #         motion_command.append(0)
    #         motion_command.append(np.deg2rad(-90.))
    #     elif action == 3:
    #         motion_command.append(1)
    #         motion_command.append(np.deg2rad(0.))
    #     return [state[0].copy().reshape(-1), padded_map.copy().reshape(-1), motion_command]

    def _preprocessState(self, state):
        # NOTE: then we need to pad the smaller maps with 0.5's on the edges
        padded_map = np.ones([self.map_siz, self.map_siz]) * 0.5
        current_map_siz = state[1].shape[0]
        padded_map[0:current_map_siz, 0:current_map_siz] = state[1]
        return [state[0].copy().reshape(-1), padded_map.copy().reshape(-1)]

    @property
    def state_shape(self):
        return [self.view_hei * self.view_wid, self.map_siz * self.map_siz]

    @property
    def action_dim(self):
        return self.act_num

    @property
    def mem_siz(self):
        return self.map_siz

    @property
    def init_pose(self):    # NOTE: should only be called after reset
        return self.bot_pose

    def visual(self):
        if self.visualize:
            self.win_world  = self.vis.image(self._mat_to_img(self._draw_dir(self._expand_mat(self.world))), env=self.refs, win=self.win_world,  opts=dict(title="world"))
            self.win_local  = self.vis.image(self._mat_to_img(self._expand_mat(self.exp_state1[0])),         env=self.refs, win=self.win_local,  opts=dict(title="state1[0]:local"))
            self.win_map    = self.vis.image(self._mat_to_img(self._expand_mat(self.exp_state1[1])),         env=self.refs, win=self.win_map,    opts=dict(title="state1[1]:map"))
            self.win_target = self.vis.image(self.target_map,                                                env=self.refs, win=self.win_target, opts=dict(title="target"))
        if self.mode == 2 and self.visualize:
            # world_name = self.img_dir + "world_%04d.jpg" % self.frame_ind
            # self.imsave(world_name, np.transpose(self._mat_to_img(self._draw_dir(self._expand_mat(self.world))), (1, 2, 0)))
            # self.logger.warning("Saved  World    @ Step: " + str(self.frame_ind) + " To: " + world_name)
            # local_name = self.img_dir + "local_%04d.jpg" % self.frame_ind
            # self.imsave(local_name, np.transpose(self._mat_to_img(self._expand_mat(self.exp_state1[0])), (1, 2, 0)))
            # self.logger.warning("Saved  Local    @ Step: " + str(self.frame_ind) + " To: " + local_name)
            map_name   = self.img_dir + "map_%04d.jpg"   % self.frame_ind
            self.imsave(map_name,   np.transpose(self._mat_to_img(self._draw_dir(self._expand_mat(self.exp_state1[1]))), (1, 2, 0)))
            self.logger.warning("Saved  Map      @ Step: " + str(self.frame_ind) + " To: " + map_name)
            # target_name = self.img_dir + "target_%04d.jpg"   % self.frame_ind
            # self.imsave(target_name, np.transpose(self.target_map, (1, 2, 0)))
            # self.logger.warning("Saved  Target   @ Step: " + str(self.frame_ind) + " To: " + target_name)
            self.frame_ind += 1

    def _act(self, act_ind=0):
        # 0. update bot pose
        bot_y   = self.bot_pose[0]
        bot_x   = self.bot_pose[1]
        bot_dir = self.bot_pose[2]
        if act_ind < 3: # just turning, will not collide for sure, just update dir directly w/o checking
            self.bot_pose[2] = (bot_dir + self.act_pos_ind[act_ind][2]) % self.dir_num
        else:           # go straight
            bot_y  += self.act_pos_ind[act_ind + bot_dir][0]
            bot_x  += self.act_pos_ind[act_ind + bot_dir][1]
            if self.world[bot_y][bot_x] == 1:   # collision, no move & penalize
                self.exp_reward += -0.96
            else:                               # free space, move & just pay step cost (already added)
                self.bot_pose[0] = bot_y
                self.bot_pose[1] = bot_x
        # 1. keep track of old poses # NOTE: old pose has already been erased from world now
        self.bot_pose_old = self.bot_pose.copy()

    def _get_local_view(self, laser_len=None):
        # 0. setting up
        bot_y   = self.bot_pose[0]
        bot_x   = self.bot_pose[1]
        bot_dir = self.bot_pose[2]
        if laser_len is None: laser_len = self.laser_len
        edge_len = laser_len - 1
        old_explored_counts = np.sum(self.explored_mask)
        newly_explored_mask = np.zeros_like(self.explored_mask)
        # 1. crop local view and push into exp_state1 & update explored_mask
        if bot_dir == 0:   # >: facing right
            min_y, max_y, min_x, max_x = bot_y - edge_len, bot_y + edge_len, bot_x, bot_x + edge_len
            local_view = self.world[min_y:max_y+1, min_x:max_x+1].copy().transpose()[::-1]
            local_view_original = local_view.copy()
            # then we udpate the explored_mask
            newly_explored_mask[min_y:max_y+1, min_x:max_x+1] = 1
            # the agent cannot see through the walls, so we process the local view and update explored_mask accordingly
            # NOTE: we're trying to simulate a depth/laserscanner here, so we only need to deal w/ one situation
            if self.sensor_type == "laser":
                if local_view_original[2][1] == 1:
                    local_view[2][0] = 0.5; newly_explored_mask[min_y][min_x] = 0
                if local_view_original[2][3] == 1:
                    local_view[2][4] = 0.5; newly_explored_mask[max_y][min_x] = 0
                if local_view_original[1][2] == 1:
                    local_view[0][2] = 0.5; newly_explored_mask[bot_y][max_x] = 0
                if local_view_original[2][1] == 1 and local_view_original[1][2] == 1:
                    local_view[0][0] = 0.5; newly_explored_mask[min_y][max_x] = 0
                    local_view[1][1] = 0.5; newly_explored_mask[min_y+1][max_x-1] = 0
                if local_view_original[2][3] == 1 and local_view_original[1][2] == 1:
                    local_view[0][4] = 0.5; newly_explored_mask[max_y][max_x] = 0
                    local_view[1][3] = 0.5; newly_explored_mask[max_y-1][max_x-1] = 0
            elif self.sensor_type == "rectangle":
                if local_view_original[2][1] == 1:
                    local_view[2][0] = 0.5; newly_explored_mask[min_y][min_x] = 0
                    local_view[1][0] = 0.5; newly_explored_mask[min_y][min_x+1] = 0
                if local_view_original[2][3] == 1:
                    local_view[2][4] = 0.5; newly_explored_mask[max_y][min_x] = 0
                    local_view[1][4] = 0.5; newly_explored_mask[max_y][min_x+1] = 0
                if local_view_original[1][2] == 1:
                    local_view[0][1] = 0.5; newly_explored_mask[bot_y-1][max_x] = 0
                    local_view[0][2] = 0.5; newly_explored_mask[bot_y][max_x] = 0
                    local_view[0][3] = 0.5; newly_explored_mask[bot_y+1][max_x] = 0
                if local_view_original[1][0] == 1 and local_view_original[0][1] == 1:
                    local_view[0][0] = 0.5; newly_explored_mask[min_y][max_x] = 0
                if local_view_original[1][4] == 1 and local_view_original[0][3] == 1:
                    local_view[0][4] = 0.5; newly_explored_mask[max_y][max_x] = 0
                if local_view_original[1][1] == 1:
                    local_view[1][0] = 0.5; newly_explored_mask[min_y][max_x-1] = 0
                    local_view[0][0] = 0.5; newly_explored_mask[min_y][max_x] = 0
                    local_view[0][1] = 0.5; newly_explored_mask[min_y+1][max_x] = 0
                if local_view_original[1][3] == 1:
                    local_view[1][4] = 0.5; newly_explored_mask[max_y][max_x-1] = 0
                    local_view[0][4] = 0.5; newly_explored_mask[max_y][max_x] = 0
                    local_view[0][3] = 0.5; newly_explored_mask[max_y-1][max_x] = 0
                if local_view_original[2][1] == 1 and local_view_original[1][2] == 1:
                    local_view[0][0] = 0.5; newly_explored_mask[min_y][max_x] = 0
                    local_view[1][1] = 0.5; newly_explored_mask[min_y+1][max_x-1] = 0
                if local_view_original[2][3] == 1 and local_view_original[1][2] == 1:
                    local_view[0][4] = 0.5; newly_explored_mask[max_y][max_x] = 0
                    local_view[1][3] = 0.5; newly_explored_mask[max_y-1][max_x-1] = 0
            # limit the laser range
            local_view = local_view * self.local_view_mask + (1. - self.local_view_mask) * 0.5
            self.explored_mask[min_y:max_y+1, min_x:max_x+1] += (1. - self.explored_mask[min_y:max_y+1, min_x:max_x+1]) * newly_explored_mask[min_y:max_y+1, min_x:max_x+1] * self.local_view_mask.copy().transpose()[:, ::-1]
        elif bot_dir == 1: # V: facing down
            min_y, max_y, min_x, max_x = bot_y, bot_y + edge_len, bot_x - edge_len, bot_x + edge_len
            local_view = self.world[min_y:max_y+1, min_x:max_x+1].copy()[::-1,::-1]
            local_view_original = local_view.copy()
            # then we udpate the explored_mask
            newly_explored_mask[min_y:max_y+1, min_x:max_x+1] = 1
            # the agent cannot see through the walls, so we process the local view and update explored_mask accordingly
            # NOTE: we're trying to simulate a depth/laserscanner here, so we only need to deal w/ one situation
            if self.sensor_type == "laser":
                if local_view_original[2][1] == 1:
                    local_view[2][0] = 0.5; newly_explored_mask[min_y][max_x] = 0
                if local_view_original[2][3] == 1:
                    local_view[2][4] = 0.5; newly_explored_mask[min_y][min_x] = 0
                if local_view_original[1][2] == 1:
                    local_view[0][2] = 0.5; newly_explored_mask[max_y][bot_x] = 0
                if local_view_original[2][1] == 1 and local_view_original[1][2] == 1:
                    local_view[0][0] = 0.5; newly_explored_mask[max_y][max_x] = 0
                    local_view[1][1] = 0.5; newly_explored_mask[max_y-1][max_x-1] = 0
                if local_view_original[2][3] == 1 and local_view_original[1][2] == 1:
                    local_view[0][4] = 0.5; newly_explored_mask[max_y][min_x] = 0
                    local_view[1][3] = 0.5; newly_explored_mask[max_y-1][min_x+1] = 0
            elif self.sensor_type == "rectangle":
                if local_view_original[2][1] == 1:
                    local_view[2][0] = 0.5; newly_explored_mask[min_y][max_x] = 0
                    local_view[1][0] = 0.5; newly_explored_mask[min_y+1][max_x] = 0
                if local_view_original[2][3] == 1:
                    local_view[2][4] = 0.5; newly_explored_mask[min_y][min_x] = 0
                    local_view[1][4] = 0.5; newly_explored_mask[min_y+1][min_x] = 0
                if local_view_original[1][2] == 1:
                    local_view[0][1] = 0.5; newly_explored_mask[max_y][bot_x+1] = 0
                    local_view[0][2] = 0.5; newly_explored_mask[max_y][bot_x] = 0
                    local_view[0][3] = 0.5; newly_explored_mask[max_y][bot_x-1] = 0
                if local_view_original[1][0] == 1 and local_view_original[0][1] == 1:
                    local_view[0][0] = 0.5; newly_explored_mask[max_y][max_x] = 0
                if local_view_original[1][4] == 1 and local_view_original[0][3] == 1:
                    local_view[0][4] = 0.5; newly_explored_mask[max_y][min_x] = 0
                if local_view_original[1][1] == 1:
                    local_view[1][0] = 0.5; newly_explored_mask[max_y-1][max_x] = 0
                    local_view[0][0] = 0.5; newly_explored_mask[max_y][max_x] = 0
                    local_view[0][1] = 0.5; newly_explored_mask[max_y][max_x-1] = 0
                if local_view_original[1][3] == 1:
                    local_view[1][4] = 0.5; newly_explored_mask[max_y-1][min_x] = 0
                    local_view[0][4] = 0.5; newly_explored_mask[max_y][min_x] = 0
                    local_view[0][3] = 0.5; newly_explored_mask[max_y][min_x+1] = 0
                if local_view_original[2][1] == 1 and local_view_original[1][2] == 1:
                    local_view[0][0] = 0.5; newly_explored_mask[max_y][max_x] = 0
                    local_view[1][1] = 0.5; newly_explored_mask[max_y-1][max_x-1] = 0
                if local_view_original[2][3] == 1 and local_view_original[1][2] == 1:
                    local_view[0][4] = 0.5; newly_explored_mask[max_y][min_x] = 0
                    local_view[1][3] = 0.5; newly_explored_mask[max_y-1][min_x+1] = 0
            # limit the laser range
            local_view = local_view * self.local_view_mask + (1. - self.local_view_mask) * 0.5
            self.explored_mask[min_y:max_y+1, min_x:max_x+1] += (1. - self.explored_mask[min_y:max_y+1, min_x:max_x+1]) * newly_explored_mask[min_y:max_y+1, min_x:max_x+1] * self.local_view_mask.copy()[::-1, ::-1]
        elif bot_dir == 2: # <: facing left
            min_y, max_y, min_x, max_x = bot_y - edge_len, bot_y + edge_len, bot_x - edge_len, bot_x
            local_view = self.world[min_y:max_y+1, min_x:max_x+1].copy().transpose()[:,::-1]
            # then we udpate the explored_mask
            newly_explored_mask[min_y:max_y+1, min_x:max_x+1] = 1
            local_view_original = local_view.copy()
            # the agent cannot see through the walls, so we process the local view and update explored_mask accordingly
            # NOTE: we're trying to simulate a depth/laserscanner here, so we only need to deal w/ one situation
            if self.sensor_type == "laser":
                if local_view_original[2][1] == 1:
                    local_view[2][0] = 0.5; newly_explored_mask[max_y][max_x] = 0
                if local_view_original[2][3] == 1:
                    local_view[2][4] = 0.5; newly_explored_mask[min_y][max_x] = 0
                if local_view_original[1][2] == 1:
                    local_view[0][2] = 0.5; newly_explored_mask[bot_y][min_x] = 0
                if local_view_original[2][1] == 1 and local_view_original[1][2] == 1:
                    local_view[0][0] = 0.5; newly_explored_mask[max_y][min_x] = 0
                    local_view[1][1] = 0.5; newly_explored_mask[max_y-1][min_x+1] = 0
                if local_view_original[2][3] == 1 and local_view_original[1][2] == 1:
                    local_view[0][4] = 0.5; newly_explored_mask[min_y][min_x] = 0
                    local_view[1][3] = 0.5; newly_explored_mask[min_y+1][min_x+1] = 0
            elif self.sensor_type == "rectangle":
                if local_view_original[2][1] == 1:
                    local_view[2][0] = 0.5; newly_explored_mask[max_y][max_x] = 0
                    local_view[1][0] = 0.5; newly_explored_mask[max_y][max_x-1] = 0
                if local_view_original[2][3] == 1:
                    local_view[2][4] = 0.5; newly_explored_mask[min_y][max_x] = 0
                    local_view[1][4] = 0.5; newly_explored_mask[min_y][max_x-1] = 0
                if local_view_original[1][2] == 1:
                    local_view[0][1] = 0.5; newly_explored_mask[bot_y+1][min_x] = 0
                    local_view[0][2] = 0.5; newly_explored_mask[bot_y][min_x] = 0
                    local_view[0][3] = 0.5; newly_explored_mask[bot_y-1][min_x] = 0
                if local_view_original[1][0] == 1 and local_view_original[0][1] == 1:
                    local_view[0][0] = 0.5; newly_explored_mask[max_y][min_x] = 0
                if local_view_original[1][4] == 1 and local_view_original[0][3] == 1:
                    local_view[0][4] = 0.5; newly_explored_mask[min_y][min_x] = 0
                if local_view_original[1][1] == 1:
                    local_view[1][0] = 0.5; newly_explored_mask[max_y][min_x+1] = 0
                    local_view[0][0] = 0.5; newly_explored_mask[max_y][min_x] = 0
                    local_view[0][1] = 0.5; newly_explored_mask[max_y-1][min_x] = 0
                if local_view_original[1][3] == 1:
                    local_view[1][4] = 0.5; newly_explored_mask[min_y][min_x+1] = 0
                    local_view[0][4] = 0.5; newly_explored_mask[min_y][min_x] = 0
                    local_view[0][3] = 0.5; newly_explored_mask[min_y+1][min_x] = 0
                if local_view_original[2][1] == 1 and local_view_original[1][2] == 1:
                    local_view[0][0] = 0.5; newly_explored_mask[max_y][min_x] = 0
                    local_view[1][1] = 0.5; newly_explored_mask[max_y-1][min_x+1] = 0
                if local_view_original[2][3] == 1 and local_view_original[1][2] == 1:
                    local_view[0][4] = 0.5; newly_explored_mask[min_y][min_x] = 0
                    local_view[1][3] = 0.5; newly_explored_mask[min_y+1][min_x+1] = 0
            # limit the laser range
            local_view = local_view * self.local_view_mask + (1. - self.local_view_mask) * 0.5
            self.explored_mask[min_y:max_y+1, min_x:max_x+1] += (1. - self.explored_mask[min_y:max_y+1, min_x:max_x+1]) * newly_explored_mask[min_y:max_y+1, min_x:max_x+1] * self.local_view_mask.copy().transpose()[::-1]
        elif bot_dir == 3: # ^: facing up
            min_y, max_y, min_x, max_x = bot_y - edge_len, bot_y, bot_x - edge_len, bot_x + edge_len
            local_view = self.world[min_y:max_y+1, min_x:max_x+1].copy()
            local_view_original = local_view.copy()
            # then we udpate the explored_mask
            newly_explored_mask[min_y:max_y+1, min_x:max_x+1] = 1
            # the agent cannot see through the walls, so we process the local view and update explored_mask accordingly
            # NOTE: we're trying to simulate a depth/laserscanner here, so we only need to deal w/ one situation
            if self.sensor_type == "laser":
                if local_view_original[2][1] == 1:
                    local_view[2][0] = 0.5; newly_explored_mask[max_y][min_x] = 0
                if local_view_original[2][3] == 1:
                    local_view[2][4] = 0.5; newly_explored_mask[max_y][max_x] = 0
                if local_view_original[1][2] == 1:
                    local_view[0][2] = 0.5; newly_explored_mask[min_y][bot_x] = 0
                if local_view_original[2][1] == 1 and local_view_original[1][2] == 1:
                    local_view[0][0] = 0.5; newly_explored_mask[min_y][min_x] = 0
                    local_view[1][1] = 0.5; newly_explored_mask[min_y+1][min_x+1] = 0
                if local_view_original[2][3] == 1 and local_view_original[1][2] == 1:
                    local_view[0][4] = 0.5; newly_explored_mask[min_y][max_x] = 0
                    local_view[1][3] = 0.5; newly_explored_mask[min_y+1][max_x-1] = 0
            elif self.sensor_type == "rectangle":
                if local_view_original[2][1] == 1:
                    local_view[2][0] = 0.5; newly_explored_mask[max_y][min_x] = 0
                    local_view[1][0] = 0.5; newly_explored_mask[max_y-1][min_x] = 0
                if local_view_original[2][3] == 1:
                    local_view[2][4] = 0.5; newly_explored_mask[max_y][max_x] = 0
                    local_view[1][4] = 0.5; newly_explored_mask[max_y-1][max_x] = 0
                if local_view_original[1][2] == 1:
                    local_view[0][1] = 0.5; newly_explored_mask[min_y][bot_x-1] = 0
                    local_view[0][2] = 0.5; newly_explored_mask[min_y][bot_x] = 0
                    local_view[0][3] = 0.5; newly_explored_mask[min_y][bot_x+1] = 0
                if local_view_original[1][0] == 1 and local_view_original[0][1] == 1:
                    local_view[0][0] = 0.5; newly_explored_mask[min_y][min_x] = 0
                if local_view_original[1][4] == 1 and local_view_original[0][3] == 1:
                    local_view[0][4] = 0.5; newly_explored_mask[min_y][max_x] = 0
                if local_view_original[1][1] == 1:
                    local_view[1][0] = 0.5; newly_explored_mask[min_y+1][min_x] = 0
                    local_view[0][0] = 0.5; newly_explored_mask[min_y][min_x] = 0
                    local_view[0][1] = 0.5; newly_explored_mask[min_y][min_x+1] = 0
                if local_view_original[1][3] == 1:
                    local_view[1][4] = 0.5; newly_explored_mask[min_y+1][max_x] = 0
                    local_view[0][4] = 0.5; newly_explored_mask[min_y][max_x] = 0
                    local_view[0][3] = 0.5; newly_explored_mask[min_y][max_x-1] = 0
                if local_view_original[2][1] == 1 and local_view_original[1][2] == 1:
                    local_view[0][0] = 0.5; newly_explored_mask[min_y][min_x] = 0
                    local_view[1][1] = 0.5; newly_explored_mask[min_y+1][min_x+1] = 0
                if local_view_original[2][3] == 1 and local_view_original[1][2] == 1:
                    local_view[0][4] = 0.5; newly_explored_mask[min_y][max_x] = 0
                    local_view[1][3] = 0.5; newly_explored_mask[min_y+1][max_x-1] = 0
            # limit the laser range
            local_view = local_view * self.local_view_mask + (1. - self.local_view_mask) * 0.5
            self.explored_mask[min_y:max_y+1, min_x:max_x+1] += (1. - self.explored_mask[min_y:max_y+1, min_x:max_x+1]) * newly_explored_mask[min_y:max_y+1, min_x:max_x+1] * self.local_view_mask.copy()
        # local_view[2][2] = 0  # TODO: we indicate bot's position in the local map now
        self.exp_state1.append(local_view)
        # 2. check exploration status and give out explore_reward
        if not self.enable_internal_explore_reward: # NOTE: only calculate the explore_reward using the true map here if not using internal map to calculate
            explore_reward = (np.sum(self.explored_mask) - old_explored_counts) * (1. / (self.view_hei * self.view_wid))    # NOTE: 0.067 for getting a new cell
            self.exp_reward += explore_reward
        # 3. update map
        self.map = self.map * (1. - self.explored_mask) + self.world * self.explored_mask
        self.exp_state1.append(self.map)
        # self.exp_state1[1][bot_y][bot_x] = 0    # TODO: check again: we don't want to give the agent the localization info
        # 4. check if terminal or not
        if np.sum(self.explored_mask * self.target_mask) == np.sum(self.target_mask):
            self.exp_reward = 10.
            self.exp_terminal1 = True

    @property
    def latest_course_ind(self):
        return self.course_ind

    def reset(self, course_ind):
        if course_ind is not None and course_ind > self.course_ind:
            self.course_ind = course_ind
        # 0. reset experience
        self._reset_experience()
        # 1. erase last bot pose from last episode
        if self.world is not None:
            self.world[self.bot_pose_old[0]][self.bot_pose_old[1]] = 0
        # 2. reset world
        # 2.1. load new world
        if self.game == "simple":
            self.world = self.worlds[course_ind].copy()
        elif self.game == "curriculum":
            self.world = self.worlds.get_new(course_ind)
        elif self.game == "eval_pregen_worlds": # then sequentially load from the pregen worlds
            self.world = self.worlds[course_ind][self.eval_pregen_worlds_ind]
            self.eval_pregen_worlds_ind += 1
        self.world_hei = self.world.shape[0]
        self.world_wid = self.world.shape[1]
        # 2.2. we also need to reset the target_mask here
        self.target_mask = 1 - self.world
        # 2.3. expand those free grids to 3x3
        for y in range(self.world_hei):
            for x in range(self.world_wid):
                if self.world[y][x] == 0:
                    self.target_mask[y-1:y+2, x-1:x+2] = 1
        # 2.4. cut out those edges, we don't need those to be seed for the agent to complete the mission
        for y in range(1, self.world_hei-1):
            for x in range(1, self.world_wid-1):
                if (self.world[y][x-1] + self.world[y][x+1] + self.world[y-1][x] + self.world[y+1][x]) == 4 and self.world[y][x] == 1:
                    self.target_mask[y][x] = 0
        self.target_map = self._mat_to_img((self._expand_mat(self.target_mask * self.world + (1.-self.target_mask) * 0.5)))
        # 3. reset map & explored_mask
        self.map = np.ones_like(self.world) * 0.5 # start off w/ all 0.5 (most uncertain)
        self.explored_mask = np.zeros_like(self.world)
        self.map = self.map * (1. - self.explored_mask) + self.world * self.explored_mask
        # 4. reset bot's starting pose
        if self.enable_random_init_pose:
            num_free_cells = self.world_hei * self.world_wid - self.world.sum()
            free_cell_lst = []
            for y in range(self.world_hei):
                for x in range(self.world_wid):
                    if self.world[y][x] == 0:   # free
                        free_cell_lst.append([y, x])
            assert len(free_cell_lst) == self.world_hei * self.world_wid - self.world.sum()
            init_pose_ind = np.random.randint(len(free_cell_lst))
            self.bot_pose[0]  = free_cell_lst[init_pose_ind][0]
            self.bot_pose[1]  = free_cell_lst[init_pose_ind][1]
            self.bot_pose[2]  = np.random.randint(4)    # TODO: num directions
        else:
            self.bot_pose = self.bot_pose_reset.copy()
        self.bot_pose_old = self.bot_pose.copy()
        # 5. wrap up
        return self.step(0)

    def step(self, act_ind=0):
        # 0. setting up
        self.exp_action    = act_ind
        self.exp_reward    = -0.04  # NOTE: we just add step cost here, other rewards will be added in _act
        self.exp_state1    = []     # NOTE
        self.exp_terminal1 = False
        # 1. erase bot's last pose
        self.world[self.bot_pose_old[0]][self.bot_pose_old[1]] = 0
        # 2. execute action & update bot_pose
        self._act(act_ind)
        # 3. indicate bot's current position
        self.world[self.bot_pose[0]][self.bot_pose[1]] = 0.25
        # 4. crop the local view & update map & calculate explore_reward & decide terminal or not
        self._get_local_view()
        # 5. wrap up
        return self._get_experience()
