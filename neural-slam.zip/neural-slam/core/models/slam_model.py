from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable

from core.model import Model
from core.controllers.slam_controller import SLAMController as Controller
from core.accessors.slam_accessor import SLAMAccessor as Accessor
from utils.init_weights import init_weights, normalized_columns_initializer
from utils.ops import stable_softmax

class SLAMModel(Model):
    def __init__(self, args):
        super(SLAMModel, self).__init__(args)

        self.enable_motion_model = args.enable_motion_model
        self.controller_params.enable_motion_model = args.enable_motion_model
        self.accessor_params.enable_motion_model = args.enable_motion_model

        # functional components
        self.controller = Controller(self.controller_params)
        self.accessor = Accessor(self.accessor_params)

        # build model
        if self.enable_motion_model:    # normal hidden_vb
            self.hid_2_policy = nn.Linear(self.hidden_dim + self.read_vec_dim, self.output_dim)
            self.hid_2_value = nn.Linear(self.hidden_dim + self.read_vec_dim, 1)
        else:                           # this case prev_action is concat into the hidden_vb
            self.hid_2_policy = nn.Linear(self.hidden_dim + 1 + self.read_vec_dim, self.output_dim)
            self.hid_2_value = nn.Linear(self.hidden_dim + 1 + self.read_vec_dim, 1)

        self._reset()

    def _init_weights(self):
        self.apply(init_weights)

        self.controller.in_2_hid.bias_ih.data.fill_(0)
        self.controller.in_2_hid.bias_hh.data.fill_(0)

        self.hid_2_policy.weight.data = normalized_columns_initializer(self.hid_2_policy.weight.data, 0.01)
        self.hid_2_policy.bias.data.fill_(0)
        self.hid_2_value.weight.data = normalized_columns_initializer(self.hid_2_value.weight.data, 1.0)
        self.hid_2_value.bias.data.fill_(0)

    def visual(self):
        self.accessor.visual()

    # NOTE: to be called at the beginning of each new episode, clear up the hidden state
    def _reset_states_episode(self, init_pose=[2,2,0], training=True): # should be called at the beginning of forwarding a new input sequence
        # we first reset the previous read vector
        self.read_vec_vb = Variable(self.read_vec_ts).type(self.dtype)
        # we then reset the previous read vector and controller's hidden state
        self.controller._reset_states_episode(training)
        # we then reset the write/read weights of heads
        self.accessor._reset_states_episode(init_pose, training)

    # NOTE: to be called at the beginning of each rollout, detach the previous variable from the graph
    def _reset_states_rollout(self): # should be called at the beginning of forwarding a new input sequence
        # we first reset the previous read vector
        self.read_vec_vb = Variable(self.read_vec_vb.data)
        # we then reset the previous read vector and controller's hidden state
        self.controller._reset_states_rollout()
        # we then reset the write/read weights of heads
        self.accessor._reset_states_rollout()

    def _reset(self):
        self._init_weights()
        self.type(self.dtype)
        self.print_model()
        # reset internal states
        self.read_vec_ts = torch.zeros(self.batch_size, self.read_vec_dim)  # TODO: check what bias value should we set it to
        self._reset_states_episode()
        self._reset_states_rollout()

    def forward(self, input_vb, prev_action):
        # NOTE: the operation order must be the following: control, access{write, read}, output

        # print("model    forward ----------------------------------------------->")
        # 1. first feed {input, read_vec_{t-1}} to controller
        hidden_vb = self.controller.forward(input_vb, self.read_vec_vb, prev_action)
        # 2. then we write to memory_{t-1} to get memory_{t}; then read from memory_{t} to get read_vec_{t}
        self.read_vec_vb = self.accessor.forward(hidden_vb, prev_action)
        # print("read_vec_vb       --->", self.read_vec_vb.data.abs().max(), self.read_vec_vb.data.abs().min())
        # print("read_vec_vb       --->", self.read_vec_vb.data.max(), self.read_vec_vb.data.min())
        # 3. finally we concat the output from the controller and the current read_vec_{t} to get the final output
        if self.enable_motion_model:    # normal hidden_vb
            preout_vb = torch.cat((hidden_vb.view(-1, self.hidden_dim),
                                   self.read_vec_vb.view(-1, self.read_vec_dim)), 1)
        else:                           # this case prev_action is concat into the hidden_vb
            preout_vb = torch.cat((hidden_vb.view(-1, self.hidden_dim + 1),
                                   self.read_vec_vb.view(-1, self.read_vec_dim)), 1)
        # print("preout_vb         --->", preout_vb.data.abs().max(), preout_vb.data.abs().min())
        # print("preout_vb         --->", preout_vb.data.max(), preout_vb.data.min())
        policy_vb = stable_softmax(self.hid_2_policy(preout_vb))
        value_vb  = self.hid_2_value(preout_vb)
        return policy_vb, value_vb
