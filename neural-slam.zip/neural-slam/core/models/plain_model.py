from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import torch.nn as nn
import torch.nn.functional as F

from core.model import Model
from core.controllers.plain_controller import PlainController as Controller
from utils.init_weights import init_weights, normalized_columns_initializer
from utils.ops import stable_softmax

class PlainModel(Model):
    def __init__(self, args):
        super(PlainModel, self).__init__(args)

        self.enable_motion_model = args.enable_motion_model
        self.enable_nav_lstms_0 = args.enable_nav_lstms_0
        self.enable_nav_lstms_1 = args.enable_nav_lstms_1

        # functional components
        self.controller = Controller(self.controller_params)

        # build model
        self.hid_2_policy = nn.Linear(self.hidden_dim, self.output_dim)
        self.hid_2_value = nn.Linear(self.hidden_dim, 1)

        self._reset()

    def _init_weights(self):
        self.apply(init_weights)

        if self.enable_motion_model:
            if self.enable_nav_lstms_0 or self.enable_nav_lstms_1:  # 2 lstms, motion into 1st/2nd one
                self.controller.in_2_hid_0.bias_ih.data.fill_(0)
                self.controller.in_2_hid_0.bias_hh.data.fill_(0)
                self.controller.in_2_hid_1.bias_ih.data.fill_(0)
                self.controller.in_2_hid_1.bias_hh.data.fill_(0)
            else:                       # 1 lstm, motion directly cat w/ input
                self.controller.in_2_hid.bias_ih.data.fill_(0)
                self.controller.in_2_hid.bias_hh.data.fill_(0)
        else:
            self.controller.in_2_hid.bias_ih.data.fill_(0)
            self.controller.in_2_hid.bias_hh.data.fill_(0)

        self.hid_2_policy.weight.data = normalized_columns_initializer(self.hid_2_policy.weight.data, 0.01)
        self.hid_2_policy.bias.data.fill_(0)
        self.hid_2_value.weight.data = normalized_columns_initializer(self.hid_2_value.weight.data, 1.0)
        self.hid_2_value.bias.data.fill_(0)

    def visual(self):
        pass

    # NOTE: to be called at the beginning of each new episode, clear up the hidden state
    def _reset_states_episode(self, init_pose=[2,2,0], training=True): # should be called at the beginning of forwarding a new input sequence
        # we first reset the previous read vector and controller's hidden state
        self.controller._reset_states_episode(training)

    # NOTE: to be called at the beginning of each rollout, detach the previous variable from the graph
    def _reset_states_rollout(self): # should be called at the beginning of forwarding a new input sequence
        # we first reset the previous read vector and controller's hidden state
        self.controller._reset_states_rollout()

    def _reset(self):
        self._init_weights()
        self.type(self.dtype)
        self.print_model()
        # reset internal states
        self._reset_states_episode()
        self._reset_states_rollout()

    def forward(self, input_vb, prev_action):
        # NOTE: the operation order must be the following: control, access{write, read}, output

        # 1. first feed {input} to controller
        hidden_vb = self.controller.forward(input_vb, prev_action)
        # 2. get the final output
        policy_vb = stable_softmax(self.hid_2_policy(hidden_vb))
        value_vb  = self.hid_2_value(hidden_vb)
        return policy_vb, value_vb
