from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable

from utils.init_weights import init_weights, normalized_columns_initializer

class Controller(nn.Module):
    def __init__(self, args):
        super(Controller, self).__init__()
        # logging
        self.logger = args.logger
        # general params
        self.use_cuda = args.use_cuda
        self.dtype = args.dtype

        # params
        self.batch_size = args.batch_size
        self.input_dim = args.input_dim
        self.read_vec_dim = args.read_vec_dim
        self.output_dim = args.output_dim
        self.hidden_dim = args.hidden_dim
        self.mem_hei = args.mem_hei
        self.mem_wid = args.mem_wid
        self.mem_dep = args.mem_dep
        self.clip_value = args.clip_value

    def _init_weights(self):
        raise NotImplementedError("not implemented in base calss")

    def print_model(self):
        self.logger.warning("<--------------------------------===> Controller:")
        self.logger.warning(self)

    # NOTE: to be called at the beginning of each new episode, clear up the hidden state
    def _reset_states_episode(self, training=True):
        not_training = not training
        # we reset controller's hidden state
        if self.enable_lstm:
            self.lstm_hidden_vb = (Variable(self.lstm_hidden_ts[0], volatile=not_training).type(self.dtype),
                                   Variable(self.lstm_hidden_ts[1], volatile=not_training).type(self.dtype))

    # NOTE: to be called at the beginning of each rollout, detach the previous variable from the graph
    def _reset_states_rollout(self):
        # we reset controller's hidden state
        if self.enable_lstm:
            self.lstm_hidden_vb = (Variable(self.lstm_hidden_vb[0].data),
                                   Variable(self.lstm_hidden_vb[1].data))

    def _reset(self):           # NOTE: should be called at each child's __init__
        self._init_weights()
        self.type(self.dtype)   # put on gpu if possible
        self.print_model()
        # reset internal states
        if self.enable_lstm:
            self.lstm_hidden_ts = []
            if self.enable_continuous:
                self.lstm_hidden_ts.append(torch.zeros(2, self.hidden_dim))
                self.lstm_hidden_ts.append(torch.zeros(2, self.hidden_dim))
            else:
                self.lstm_hidden_ts.append(torch.zeros(1, self.hidden_dim))
                self.lstm_hidden_ts.append(torch.zeros(1, self.hidden_dim))
        self._reset_states_episode()
        self._reset_states_rollout()

    def forward(self, input_vb):
        raise NotImplementedError("not implemented in base calss")
