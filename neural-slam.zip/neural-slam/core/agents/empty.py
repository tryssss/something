from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import random
import time
import torch
from torch.autograd import Variable

from utils.helpers import Experience
from utils.courses import Courses
from core.agent import Agent

class EmptyAgent(Agent):
    def __init__(self, args, env_prototype, model_prototype):
        super(EmptyAgent, self).__init__(args, env_prototype, model_prototype)
        self.logger.warning("<===================================> Empty")

        # env
        self.env = self.env_prototype(self.env_params)
        self.state_shape = self.env.state_shape
        self.action_dim  = self.env.action_dim
        # NOTE: we need to keep track of the last action taken to apply motion on the attention
        self.prev_action = 0    # TODO: should modify for continuous version

        self._reset_experience()

        # NOTE: we also get the course schedule for this training
        self.courses = Courses()

    def _preprocessState(self, state, is_valotile=False):
        if isinstance(state, list):
            state_vb = []
            for i in range(len(state)):
                state_vb.append(Variable(torch.from_numpy(state[i]).unsqueeze(0).type(self.dtype), volatile=is_valotile))
        else:
            state_vb = Variable(torch.from_numpy(state).unsqueeze(0).type(self.dtype), volatile=is_valotile)
        return state_vb

    def _forward(self, state_vb):
        return 0

    def _backward(self, reward, terminal):
        pass

    def _eval_model(self):
        pass

    def fit_model(self):
        self.logger.warning("<===================================> Training ...")
        self.training = True
        # self._reset_training_loggings()

        start_time = time.time()
        self.step = 0

        nepisodes = 0
        nepisodes_solved = 0
        episode_steps = None
        episode_reward = None
        total_reward = 0.
        should_start_new = True
        while self.step < self.steps:
            print(self.step)
            if should_start_new:
                episode_steps = 0
                episode_reward = 0.
                # Obtain the initial observation by resetting the environment
                self._reset_experience()
                self.experience = self.env.reset(self.courses.get_course_ind(self.step/self.steps))
                assert self.experience.state1 is not None
                if self.visualize: self.env.visual()
                if self.render: self.env.render()
                # reset flag
                should_start_new = False
                self.prev_action = 0 # TODO: should modify for continuous version
                print("new game ----------->")
                raw_input()
            # action = random.randrange(self.action_dim)      # thus we only randomly sample actions here, since the model hasn't been updated at all till now
            action = int(raw_input("action --->"))
            print("self.prev_action that's fed in", self.prev_action)
            # action = self._forward(self.experience.state1)
            self._forward(self._preprocessState(self.experience.state1))
            self.experience = self.env.step(action); self.prev_action = action
            print(self.experience.terminal1, self.experience.reward)
            if self.visualize: self.env.visual()
            if self.render: self.env.render()
            if self.experience.terminal1 or self.early_stop and (episode_steps + 1) >= self.early_stop:
                should_start_new = True

            episode_steps += 1
            episode_reward += self.experience.reward
            self.step += 1

            if should_start_new:
                nepisodes += 1
                if self.experience.terminal1:
                    nepisodes_solved + 1

            # raw_input()
        print(time.time() - start_time)

    def test_model(self):
        pass
