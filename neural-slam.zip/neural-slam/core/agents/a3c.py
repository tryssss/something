from __future__ import absolute_import
from __future__ import division
import torch.multiprocessing as mp

from core.agent import Agent
from core.agents.a3cSingleProcess import A3CLearner, A3CEvaluator, A3CTester

class A3CAgent(Agent):
    def __init__(self, args, env_prototype, model_prototype):
        super(A3CAgent, self).__init__(args, env_prototype, model_prototype)
        self.logger.warning("<===================================> A3C-Master {Env(dummy) & Model}")

        # # dummy_env just to get state_shape & action_dim
        # self.dummy_env   = self.env_prototype(self.env_params, self.num_processes)
        # self.state_shape = self.dummy_env.state_shape
        # self.action_dim  = self.dummy_env.action_dim
        # self.mem_hei = self.dummy_env.mem_siz
        # self.mem_wid = self.dummy_env.mem_siz
        # self.laser_len = self.dummy_env.laser_len
        # del self.dummy_env
        if args.env_type == "grid-world":
            self.dummy_env   = self.env_prototype(self.env_params, self.num_processes)
            self.state_shape = self.dummy_env.state_shape
            self.action_dim  = self.dummy_env.action_dim
            self.mem_hei = self.dummy_env.mem_siz
            self.mem_wid = self.dummy_env.mem_siz
            self.laser_len = self.dummy_env.laser_len
            del self.dummy_env
        elif args.env_type == "gazebo":
            # self.state_shape = [181, 32*32]
            self.state_shape = [15, 32*32]
            self.action_dim  = 4#6
            self.mem_hei = 10#14
            self.mem_wid = 10#14
            self.laser_len = 4

        # global shared model
        self.model_params.enable_motion_model = args.enable_motion_model
        self.model_params.batch_size = self.batch_size
        self.model_params.input_dim = self.state_shape
        self.model_params.output_dim = self.action_dim
        self.model_params.hidden_dim = self.hidden_dim
        self.model_params.mem_hei = self.mem_hei
        self.model_params.mem_wid = self.mem_wid
        self.model_params.accessor_params.laser_len = self.laser_len
        self.model = self.model_prototype(self.model_params)
        self._load_model(self.model_file)   # load pretrained model if provided
        self.model.share_memory()           # NOTE

        # learning algorithm # TODO: could also linearly anneal learning rate
        self.optimizer = self.optim(self.model.parameters(), lr = self.lr)
        self.optimizer.share_memory()       # NOTE

        # global counters
        self.frame_step   = mp.Value('l', 0) # global frame step counter
        self.train_step   = mp.Value('l', 0) # global train step counter
        # global training stats
        self.p_loss_avg   = mp.Value('d', 0.) # global policy loss
        self.v_loss_avg   = mp.Value('d', 0.) # global value loss
        self.loss_avg     = mp.Value('d', 0.) # global loss
        self.loss_counter = mp.Value('l', 0)  # storing this many losses
        self.latest_course_ind = mp.Value('l', 0) # the hardest course that has been trained on so far
        self._reset_training_loggings()

    def _reset_training_loggings(self):
        self.p_loss_avg.value   = 0.
        self.v_loss_avg.value   = 0.
        self.loss_avg.value     = 0.
        self.loss_counter.value = 0
        # self.latest_course_ind.value = 0

    def fit_model(self):
        self.jobs = []
        for process_id in range(self.num_processes):
            self.jobs.append(A3CLearner(self, process_id))
        self.jobs.append(A3CEvaluator(self, self.num_processes))

        self.logger.warning("<===================================> Training ...")
        for job in self.jobs:
            job.start()
        for job in self.jobs:
            job.join()

    def test_model(self):
        self.jobs = []
        self.jobs.append(A3CTester(self))

        self.logger.warning("<===================================> Testing ...")
        for job in self.jobs:
            job.start()
        for job in self.jobs:
            job.join()
