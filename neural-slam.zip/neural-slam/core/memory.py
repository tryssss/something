from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import numpy as np
import torch
import torch.nn.functional as F
from torch.autograd import Variable

from utils.helpers import tile_ts

class ExternalMemory(object):
    def __init__(self, args):
        # logging
        self.logger = args.logger
        # params
        self.mode       = args.mode             # NOTE: save frames when mode=2
        self.visualize  = args.visualize
        if self.mode == 2 and self.visualize:
            try:
                import scipy.misc
                self.imsave = scipy.misc.imsave
            except ImportError as e: self.logger.warning("WARNING: scipy.misc not found")
            self.img_dir = args.root_dir + "/imgs/"
            self.frame_ind = 0
        if self.visualize:
            self.vis        = args.vis
            self.refs       = args.refs
            self.win_memory = "win_memory"
        self.use_cuda = args.use_cuda
        self.dtype = args.dtype

        self.batch_size = args.batch_size
        self.mem_hei = args.mem_hei
        self.mem_wid = args.mem_wid

    def _save_memory(self):
        raise NotImplementedError("not implemented in base calss")

    def _load_memory(self):
        raise NotImplementedError("not implemented in base calss")

    def _reset_states_episode(self, training=True):
        not_training = not training
        self.memory_vb = Variable(self.memory_ts, volatile=not_training).type(self.dtype)
        # # option 1: the correct one, sum of reward should be exactly the same as the one using external reward
        # self.prev_explored_area = np.minimum((self._readout_internal_map() - 0.5).abs().sum() / (np.pi * self.laser_len ** 2 / 2), 1) # TODO: should check again
        # option 2: NOTE: here we keep it the same as the ones before
        self.prev_explored_area = (self._readout_internal_map() - 0.5).abs().sum()# / 15. # TODO: should check again

    def _reset_states_rollout(self):
        self.memory_vb = Variable(self.memory_vb.data)

    def _reset(self):           # NOTE: should be called at each child's __init__
        raise NotImplementedError("not implemented in base calss")

    def _expand_mat(self, mat, expand_by=None):
        if expand_by is None: expand_by = 21#self.grid_siz
        mat = np.repeat(mat, expand_by, axis=0)
        mat = np.repeat(mat, expand_by, axis=1)
        return mat

    def _mat_to_img(self, mat):
        return 255. - np.tile(mat, (3, 1, 1)) * 255.

    def visual(self):
        if self.visualize:      # here we visualize the memory of batch0
            # self.win_memory = self.vis.heatmap(np.sum(self.memory_vb.data[0].clone().cpu().numpy().reshape(self.mem_hei, self.mem_wid, self.mem_dep), axis=2), env=self.refs, win=self.win_memory, opts=dict(title="memory"))
            # self.win_memory = self.vis.heatmap(torch.mean(self.memory_vb.data[0].view(self.mem_hei, self.mem_wid, self.mem_dep), 2).squeeze(2).numpy()[::-1, :], env=self.refs, win=self.win_memory, opts=dict(title="memory"))
            # self.win_memory = self.vis.heatmap(F.sigmoid(self.memory_vb[0]).mean(1).view(self.mem_hei, self.mem_wid).data.numpy()[::-1, :], env=self.refs, win=self.win_memory, opts=dict(title="memory"))
            self.win_memory = self.vis.heatmap(self._readout_internal_map()[0].view(self.mem_hei, self.mem_wid).numpy()[::-1, :], env=self.refs, win=self.win_memory, opts=dict(title="memory"))
            # self.win_memory = self.vis.image(tile_ts(torch.mean(self.memory_vb.data[0].view(self.mem_hei, self.mem_wid, self.mem_dep), 2).squeeze(2)), env=self.refs, win=self.win_memory, opts=dict(title="memory"))
        if self.mode == 2 and self.visualize:
            # memory_name = self.img_dir + "memory_%04d.jpg" % self.frame_ind
            # self.imsave(memory_name, np.transpose(self._mat_to_img(self._expand_mat(self._readout_internal_map()[0].view(self.mem_hei, self.mem_wid).numpy())), (1, 2, 0)))
            # self.logger.warning("Saved  Memory   @ Step: " + str(self.frame_ind) + " To: " + memory_name)
            self.frame_ind += 1

class External2DMemory(ExternalMemory):
    def __init__(self, args):
        super(External2DMemory, self).__init__(args)
        self._reset()

        self.logger.warning("<-----------------------------------> Memory:     {" + str(self.batch_size) + "(batch_size) x " + str(self.mem_hei) + "(mem_hei) x " + str(self.mem_wid) + "(mem_wid)}")

    def _reset(self):
        self.memory_ts = torch.zeros(self.batch_size, self.mem_hei, self.mem_wid)#.fill_(5e-6)
        self._reset_states_episode()
        self._reset_states_rollout()

class External3DMemory(ExternalMemory):
    def __init__(self, args):
        super(External3DMemory, self).__init__(args)
        self.mem_dep = args.mem_dep
        self.laser_len = args.laser_len
        self._reset()

        self.logger.warning("<-----------------------------------> Memory:     {" + str(self.batch_size) + "(batch_size) x " + str(self.mem_hei) + "(mem_hei) x " + str(self.mem_wid) + "(mem_wid) x " + str(self.mem_dep) + "(mem_dep)}")

    def _reset(self):
        # TODO: should fill in 0, so the initial values after a sigmoid would be 0.5, which is exactly what we want
        # NOTE: here we bias it to be the initialization of an occupancy grid map
        self.memory_ts = torch.zeros(self.batch_size, self.mem_hei * self.mem_wid, self.mem_dep)#.fill_(0.5)
        self._reset_states_episode()
        self._reset_states_rollout()

    def _get_internal_explore_reward(self):
        # # option 1: the correct one, sum of reward should be exactly the same as the one using external reward
        # self.curr_explored_area = np.minimum((self._readout_internal_map() - 0.5).abs().sum() / (np.pi * self.laser_len ** 2 / 2), 1) # TODO: should check again
        # explore_reward = np.maximum(self.curr_explored_area - self.prev_explored_area, 0)
        # option 2: NOTE: here we keep it the same as the ones before
        self.curr_explored_area = (self._readout_internal_map() - 0.5).abs().sum()# / 15. # TODO: should check again
        explore_reward = self.curr_explored_area - self.prev_explored_area
        # wrap up
        self.prev_explored_area = self.curr_explored_area
        return explore_reward

    def _readout_internal_map(self):
        return F.sigmoid(self.memory_vb).data.mean(2)
        # return self._inverse_log_odds(self.memory_vb.data).mean(2)

    def _inverse_log_odds(self, log_odds_ts): # NOTE: equivalent to sigmoid !!!
        return 1 - 1. / (1. + torch.exp(log_odds_ts))
