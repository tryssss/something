from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import torch.nn as nn
from torch.autograd import Variable

from core.accessor import Accessor
from core.heads.slam_write_head import SLAMWriteHead as WriteHead
from core.heads.slam_read_head import SLAMReadHead as ReadHead
from core.memory import External3DMemory as ExternalMemory
# from utils.ops import clamp_memory

class SLAMAccessor(Accessor):
    def __init__(self, args):
        super(SLAMAccessor, self).__init__(args)
        # # logging
        # self.logger = args.logger
        # # params
        # self.use_cuda = args.use_cuda
        # self.dtype = args.dtype

        self.logger.warning("<--------------------------------===> Accessor:   {WriteHead, ReadHead, Memory}")

        # functional components
        self.write_heads = WriteHead(self.write_head_params)
        self.read_heads = ReadHead(self.read_head_params)
        self.memory = ExternalMemory(self.memory_params)

        self._reset()

    def _init_weights(self):
        pass

    def _reset_states_episode(self, init_pose=[2,2,0], training=True):
        # we reset the write/read weights of heads
        self.write_heads._reset_states_episode(init_pose, training)
        self.read_heads._reset_states_episode(init_pose,training)
        # we also reset the memory to bias value
        self.memory._reset_states_episode(training)

    def _reset_states_rollout(self):
        # we reset the write/read weights of heads
        self.write_heads._reset_states_rollout()
        self.read_heads._reset_states_rollout()
        # we also reset the memory to bias value
        self.memory._reset_states_rollout()

    def _reset(self):           # NOTE: should be called at __init__
        self._init_weights()
        self.type(self.dtype)   # put on gpu if possible
        # reset internal states
        self._reset_states_episode()
        self._reset_states_rollout()

    def forward(self, hidden_vb, prev_action):
        # 1. first write to memory_{t-1} to get memory_{t}
        # print("accessor  forward ---------------------->")
        # print("mem before write  --->", self.memory.memory_vb.data.abs().max(), self.memory.memory_vb.data.abs().min())
        # print("mem before write  --->", self.memory.memory_vb.data.max(), self.memory.memory_vb.data.min())
        self.memory.memory_vb = self.write_heads.forward(hidden_vb, self.memory.memory_vb, prev_action)
        # print("mem after  write  --->", self.memory.memory_vb.data.abs().max(), self.memory.memory_vb.data.abs().min())
        # print("mem after  write  --->", self.memory.memory_vb.data.max(), self.memory.memory_vb.data.min())
        # 2. we clamp the values in memory before read from it, to prevent the values being too small
        # print(self.memory.memory_vb.data)
        # self.memory.memory_vb = clamp_memory(self.memory.memory_vb)
        # print(self.memory.memory_vb.data)
        # print("mem after  clamp  --->", self.memory.memory_vb.data.abs().max(), self.memory.memory_vb.data.abs().min())
        # print("mem after  clamp  --->", self.memory.memory_vb.data.max(), self.memory.memory_vb.data.min())
        # 3. then read from memory_{t} to get read_vec_{t}
        read_vec_vb = self.read_heads.forward(hidden_vb, self.memory.memory_vb, prev_action)
        return read_vec_vb#.clamp(min=-self.clip_value, max=self.clip_value)
