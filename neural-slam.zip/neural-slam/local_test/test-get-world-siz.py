from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import numpy as np

world_siz_start = 4 - 2 + 6 # [6x6]   we leave 2 for edge
world_siz_end   = 4 - 2 + 14 #10#15 # [15x15] we leave 2 for edge
world_siz_inc   = 2    # NOTE: should be increase by 2 so that we can pad 1's on the smaller worlds
total_nepisodes = 200

nepisodes =  0
nepisodes =  999999
nepisodes = 5000000
world_siz = np.floor(world_siz_start + (world_siz_end - world_siz_start + world_siz_inc) * (nepisodes // world_siz_inc * world_siz_inc / total_nepisodes)).astype(int)
world_siz = np.floor(world_siz_start + (world_siz_end - world_siz_start + world_siz_inc) // world_siz_inc * (nepisodes / total_nepisodes)).astype(int)
print(world_siz_end - world_siz_start + world_siz_inc)
print((world_siz_end - world_siz_start + world_siz_inc) // world_siz_inc)
print(total_nepisodes // ((world_siz_end - world_siz_start + world_siz_inc) // world_siz_inc))
print(nepisodes // (total_nepisodes // ((world_siz_end - world_siz_start + world_siz_inc) // world_siz_inc)))
world_siz = (world_siz_start + (nepisodes // (total_nepisodes // ((world_siz_end - world_siz_start + world_siz_inc) // world_siz_inc))) * world_siz_inc)
print(world_siz-2)
