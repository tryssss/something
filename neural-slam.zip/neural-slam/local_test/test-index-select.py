import numpy as np
import torch
import torch.nn as nn
from torch.autograd import Variable

mem_hei = 5
mem_wid = 5
a = Variable(torch.arange(0, mem_hei * mem_wid).view(mem_hei, mem_wid))
print(a)
indices_ts = torch.ones(3, mem_hei*mem_wid)
for y in range(0, mem_hei):
    for x in range(0, mem_wid):
        indices_ts[0][y * mem_wid + x] = y
        indices_ts[1][y * mem_wid + x] = x
print(indices_ts)
origin_y = 0
origin_x = 0

# rotated_indices_ts = torch.mm(rotation_ts, indices_ts)
# print(rotated_indices_ts)
# rotated_indices_ts[0] = torch.round(rotated_indices_ts[0]).type(torch.LongTensor)
# rotated_indices_ts[1] = torch.round(rotated_indices_ts[1]).type(torch.LongTensor)
valid_y_indices_ts = torch.ge(rotated_indices_ts[0], 0) * torch.le(rotated_indices_ts[0], mem_hei-1)
valid_x_indices_ts = torch.ge(rotated_indices_ts[1], 0) * torch.le(rotated_indices_ts[0], mem_wid-1)
print(valid_y_indices_ts.view(mem_hei, mem_wid))
print(valid_x_indices_ts.view(mem_hei, mem_wid))
valid_indices_ts = valid_y_indices_ts * valid_x_indices_ts
print(valid_indices_ts.view(mem_hei, mem_wid))

final_indices_ts = rotated_indices_ts[0] * mem_wid + rotated_indices_ts[1]
print(final_indices_ts)
rotated_indices_ts[0] = torch.clamp(rotated_indices_ts[0], min=0, max=mem_hei-1)
rotated_indices_ts[1] = torch.clamp(rotated_indices_ts[1], min=0, max=mem_wid-1)

final_indices_ts = rotated_indices_ts[0] * mem_wid + rotated_indices_ts[1]
print(final_indices_ts.view(mem_hei, mem_wid))
print(a)
print((torch.index_select(a.view(1, mem_hei * mem_wid), 1, Variable(final_indices_ts.type(torch.LongTensor))) * Variable(valid_indices_ts.type(torch.FloatTensor))).view(mem_hei, mem_wid))


##################################
def get_trans_ts(trans_x, trans_y):
    trans_ts = torch.eye(3, 3)
    trans_ts[0][2] = trans_x
    trans_ts[1][2] = trans_y
    return trans_ts
def get_rotat_ts(origin_x, origin_y, turn_by):
    r00 =   np.cos(turn_by)
    r01 = - np.sin(turn_by)
    r10 =   np.sin(turn_by)
    r11 =   np.cos(turn_by)
    rotat_ts = torch.zeros(3, 3)
    rotat_ts[0][0] = r00
    rotat_ts[0][1] = r01
    rotat_ts[0][2] = origin_x - r00 * origin_x - r01 * origin_y
    rotat_ts[1][0] = r10
    rotat_ts[1][1] = r11
    rotat_ts[1][2] = origin_y - r10 * origin_x - r11 * origin_y
    rotat_ts[2][2] = 1
    return rotat_ts
rotat_ts = get_rotat_ts(9, 1, np.deg2rad(0))
trans_ts = get_trans_ts(3, 1)
print(rotat_ts)
print(trans_ts)
pos_in = torch.Tensor([0, 0, 1]).view(3, 1)
print(pos_in)
print(torch.mm(rot_ts, pos_in))
print(torch.mm(trans_ts, pos_in))
