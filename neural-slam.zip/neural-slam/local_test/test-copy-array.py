import numpy as np
a = np.array([2,3,4])
print(a)
b = a[2]
print(b)
c = a[2].copy()
