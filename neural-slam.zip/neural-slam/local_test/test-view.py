import torch
import torch.nn as nn

a = torch.rand(2, 3, 4, 5)
print(a)

print(a.view(2, 12, 5))
