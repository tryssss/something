import torch
import torch.nn.functional as F
from torch.autograd import Variable

a = torch.rand(2, 1, 3)
b = torch.rand(2, 1, 1) + 1.
print(a)
print(b)
a / a.sum(2).expand_as(a)
ap = a.pow(b.expand_as(a))
ap / ap.sum(2).expand_as(ap)
print(ap)

batch_size = 2
input_dim = 5
input_vb = Variable(torch.rand(batch_size, input_dim))
print()
