import torch

N = 5
M = 3
w = torch.rand(N, 1)
e = torch.rand(1, M)
print(w.expand_as(torch.mm(w, e)) * e.expand_as(torch.mm(w, e)))
print(torch.mm(w, e))
