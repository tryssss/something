import torch
import torch.nn
from torch.autograd import Variable
import torch.nn.functional as F

a = torch.rand(3, 4)
a[0][0] = float('nan')
b = Variable(a)
print(a)

b.clamp(-5, 5)
print(b)
b = torch.clamp(b, -5, 5)
print(b)
