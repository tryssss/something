import torch
import torch.nn as nn
from torch.autograd import Variable

a = torch.zeros(3, 5, 5)
print(a)
a[:, 0:3, 0:2] = 1
print(a)
