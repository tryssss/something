import numpy as np
a = np.array([-4, -5, 2, 9, -10])
print(a)
print(np.sum(a>1))
a[a==2] = 3
print(a)
