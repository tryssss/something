from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import numpy as np
import os, subprocess
import roslib
import rospy
import math
import tf
import geometry_msgs.msg
import turtlesim.srv
import rospy, rosgraph
from gazebo.helpers import pose_2_pose_msg, pose_msg_2_pose

env_ind = 0
os.environ["ROS_MASTER_URI"] = "http://rosimage"+str(env_ind)+":11311"
masteruri = rosgraph.get_master_uri()
print(masteruri)

from geometry_msgs.msg import Twist
from gazebo.gym_style_gazebo.srv import PytorchRL

gazebo_srv = rospy.ServiceProxy('/gazebo_env_io/pytorch_io_service', PytorchRL)
print(gazebo_srv)

req_init_action = Twist()
req_action = req_init_action.clone()
from std_msgs.msg import Bool
a = Bool()
