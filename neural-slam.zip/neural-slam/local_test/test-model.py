from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
from torch.nn import Parameter

model = torch.load("/home/zhang/ws/17_ws/neural-slam/models/aisgpu3_17062400_0.pth")
num = 0
for key, value in model.items():
    print(value)
    num += value.nelement()
print(num)
