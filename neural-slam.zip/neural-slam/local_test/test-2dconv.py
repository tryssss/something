import torch
from torch.autograd import Variable
import torch.nn.functional as F

filters = Variable(torch.ones(8,4,3,3))
inputs = Variable(torch.ones(1,4,5,5))
F.conv2d(inputs, filters, padding=1)
F.conv2d(inputs, filters, padding=1)
F.conv2d(inputs, filters, padding=2)
