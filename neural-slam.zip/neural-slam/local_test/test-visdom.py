import torch
import visdom

vis = visdom.Visdom()
win_world  = vis.image(, win=win_world,  opts=dict(title="world"))
self.win_world  = self.vis.image(self._mat_to_img(self._draw_dir(self._expand_mat(self.world))), env=self.refs, win=self.win_world,  opts=dict(title="world"))
vis.line(Y=torch.Tensor([[0., 0.], [1., 1.]]))
vis.image(torch.rand(100, 100))

img = torch.zeros(300, 300)
img[0:100,   0:100] = 100
img[0:100, 100:200] = 200
vis.image(img)
# self.win_head = self.vis.heatmap(self.wl_curr_vb.data[0][0].clone().cpu().numpy().reshape(self.mem_hei, self.mem_wid), env=self.refs, win=self.win_head, opts=dict(title="write_head"))
vis.heatmap(img[::, :])

def tile_ts(input_ts, tile_by=21):  # NOTE: cos grid_siz=21
    # input_ts: [hei x wid]
    assert input_ts.dim() == 2
    hei = input_ts.size(0)
    wid = input_ts.size(0)
    output_ts = torch.zeros(hei * tile_by, wid * tile_by)
    for y in range(hei):
        for x in range(wid):
            output_ts[(y*tile_by):((y+1)*tile_by), (x*tile_by):((x+1)*tile_by)] = input_ts[y][x]
    return output_ts
a = torch.rand(16, 16)
vis.image(a)
vis.image(tile_ts(a))
vis.image(img)
vis.heatmap(img)
