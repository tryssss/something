import numpy as np
import roslib
import rospy
import math
import tf
import geometry_msgs.msg
import turtlesim.srv

pose = geometry_msgs.msg.Pose()
print(pose)
roll  = np.deg2rad(0)
pitch = np.deg2rad(0)
yaw   = np.deg2rad(-177)

# euler to quaternion
quaternion = tf.transformations.quaternion_from_euler(roll, pitch, yaw)
#type(pose) = geometry_msgs.msg.Pose
pose.orientation.x = quaternion[0]
pose.orientation.y = quaternion[1]
pose.orientation.z = quaternion[2]
pose.orientation.w = quaternion[3]
print(pose)

# quaternion to euler
quaternion = (
    pose.orientation.x,
    pose.orientation.y,
    pose.orientation.z,
    pose.orientation.w
)
euler = tf.transformations.euler_from_quaternion(quaternion)
roll  = np.rad2deg(euler[0])
pitch = np.rad2deg(euler[1])
yaw   = np.rad2deg(euler[2])
print(roll, pitch, yaw)

def _action_2_twist_msg(action):
    """
    variables needed:
        action:             [linear_vel, angular_vel]: action indexes
    returns:
        twist_msg:
            linear:         Vector3
            angular:        Vector3
    """
    pass

def _pose_2_pose_msg(pose):
    """
    variables needed:
        pose: [y, x, dir]   NOTE: dir: [0, 3]
    returns:
        pose_msg:
            position:       Point
            orientation:    Quaternion
    we only initialize the bot's direction in sharp angles
    then we dicretize the angle also to sharp angles to isualize
    """
    pose_msg = geometry_msgs.msg.Pose()
    # position
    pose_msg.position.x = pose[1] - 4.5
    pose_msg.position.y = 4.5 - pose[0]
    pose_msg.position.z = 0 # TODO: set to defalut value
    # orientation
    quaternion = tf.transformations.quaternion_from_euler(0, 0, np.deg2rad(360.) - np.deg2rad(90.) * pose[2])
    pose_msg.orientation.x = quaternion[0]
    pose_msg.orientation.y = quaternion[1]
    pose_msg.orientation.z = quaternion[2]
    pose_msg.orientation.w = quaternion[3]
    # wrap up
    return pose_msg

pose_msg = _pose_2_pose_msg([3, 1, 2])

def _pose_msg_2_pose(pose_msg):
    """
    variables needed:
        pose_msg:
            position:       Point
            orientation:    Quaternion
    returns:
        pose: [y, x, dir]   NOTE: dir: [0, 3]
    """
    pose = np.array([0, 0, 0]) # [y, x, dir]
    # position
    pose[0] = np.ceil(4 - pose_msg.position.y) # y
    pose[1] = np.ceil( pose_msg.position.x + 4) # x
    # orientation
    quaternion = (
        pose_msg.orientation.x,
        pose_msg.orientation.y,
        pose_msg.orientation.z,
        pose_msg.orientation.w
    )
    euler = tf.transformations.euler_from_quaternion(quaternion)
    pose[2] = np.rad2deg(euler[2])
    if pose[2] < 0: pose[2] += 360
    pose[2] = int(360 - pose[2]) // 90
    if pose[2] >= 4: pose[2] -= 4
    if pose[2] < 0:  pose[2] += 4
    # wrap up
    return pose

pose_msg.position.x = 2.1
pose_msg.position.y = -0.99
pose = _pose_msg_2_pose(pose_msg)
print(pose)
