import torch
# print(torch.eye(1, 3, 5))
batch_size = 3
num_heads = 5
mem_hei = 7
mem_wid = 7
wl_prev_ts = torch.eye(1, mem_hei).unsqueeze(0).expand(batch_size, num_heads, mem_hei)
print(wl_prev_ts)

wl_prev_ts = torch.zeros(batch_size, num_heads, mem_hei * mem_wid)
wl_prev_ts[:, :, 0] = 1
print(wl_prev_ts.view(batch_size, num_heads, mem_hei, mem_wid))
