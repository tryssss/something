import torch
import torch.nn as nn
from torch.autograd import Variable
import torch.nn.functional as F
from utils.kernels import gaussian_kernel

a = torch.rand(1, 1, 3, 5)
b = torch.FloatTensor([1])
print(torch.max(a, b.expand_as(a)))
