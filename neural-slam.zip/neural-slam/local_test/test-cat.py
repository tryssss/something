import torch
import torch.nn as nn
from torch.autograd import Variable

a = Variable(torch.rand(1, 3))
b = Variable(torch.rand(1, 7))
c = Variable(torch.rand(1, 5))
lst = []
lst.append(a)
lst.append(b)
lst.append(c)
c = torch.cat(lst, 1)
print(c)
