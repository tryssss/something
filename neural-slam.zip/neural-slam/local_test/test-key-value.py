import numpy as np

a = {}
a[(2, 3, 0)] = 0
a[(2, 3, 1)] = 1
a[(2, 3, 2)] = 0
a[(2, 3, 3)] = 0

b = np.sum(a.values())
print(b)
a = dict.fromkeys(a, 0)
