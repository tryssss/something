import torch
import torch.nn as nn
from torch.autograd import Variable
import torch.nn.functional as F
from utils.kernels import gaussian_kernel

"""
first we should know how to get the density mass out of the write/read weights
should we apply to the write/read weights seperately or should they somehow be consistent w/ each other?
should not be calculated from the map itself, but should be from the weights, cos this
represents the current belief of the state
or should the weights also just directly have the direction information in it??
or we could not have the initialization assumption if we use the particle filter???
No, we should, cos we wouldn't know where to map at the first time step, then everything would be wrong

Particle filter:
we view the weights as the weights for the particle filters,
the content focus is like the data association,
then the location focus is doing the motion model based on the data association
"""

batch_size = 2
num_heads = 1
mem_hei = 8
mem_wid = 8
mem_init_y_min = 0
mem_init_y_max = 4
mem_init_x_min = 2
mem_init_x_max = 4

bot_init_y = 2
bot_init_x = 2

wl_prev_ts = torch.zeros(batch_size, num_heads, mem_hei, mem_wid)
wl_prev_ts[:, :, mem_init_y_min:mem_init_y_max+1, mem_init_x_min:mem_init_x_max+1] = gaussian_kernel().unsqueeze(0).unsqueeze(0).expand(batch_size, num_heads, mem_init_y_max+1-mem_init_y_min, mem_init_x_max+1-mem_init_x_min)
wl_prev_ts = wl_prev_ts.view(batch_size, num_heads, mem_hei * mem_wid)
wl_prev_vb = Variable(wl_prev_ts)
print(wl_prev_vb.view(batch_size, num_heads, mem_hei, mem_wid)[0])
def get_sensing_area_indices(bot_y, bot_x, bot_dir, laser_len=3, map_hei=mem_hei, map_wid=mem_wid):
    """
    NOTE: get the indices for the sensing area from [bot_y, bot_x] facing bot_dir
    NOTE: we then use this to multiple w/ the head weights to get the density mass on this sensing area
    NOTE: so as to choose the direction w/ the largest density mass as our direction
    """
    indices = torch.zeros(mem_hei, mem_wid)
    for dir in np.arange(bot_dir - np.deg2rad(90.), bot_dir + np.deg2rad(91.), np.deg2rad(1.)):
        for len in range(0, laser_len):
            y = np.minimum(np.maximum(0, np.round(bot_y + len * np.sin(dir))), mem_hei - 1)
            x = np.minimum(np.maximum(0, np.round(bot_x + len * np.cos(dir))), mem_wid - 1)
            indices[y][x] = 1
    return indices.view(mem_hei * mem_wid)

# now we need to first localize
def localize(particle_weights_vb):
    """
    variables needed:
        particle_weights: [batch_size x num_heads x(mem_hei x mem_wid)]
    returns:
        bot_pose:         [bot_y, bot_x, bot_dir]
            bot_y:        [batch_size x num_heads x 1]
            bot_x:        [batch_size x num_heads x 1]
            bot_dir:      [batch_size x num_heads x 1]: rad
    # y=2  /   /   /
    # y=1  /   /   /
    # y=0  /   /   /
    #     x=0 x=1 x=2
    #        ^ (90.)
    # < (0.)          > (180.)
    #        V (270.)
    NOTE: from the calculation from the last time step, the correct localization would gaurantee
    NOTE: that the bot is not outside of the area
    NOTE: this gaurantee should also be checked after this forward motion here
    TODO: if there are multiple heads, then they can actually be viewed as multiple particles
    TODO: think about it again as where should those beliefs of those particles be combined
    TODO: and also whether function should return the max over all the particles or just the
    TODO: individual beliefs of each particle
    TODO: and also how to view the connection of the write/read weights
    """
    # first we need to localize
    particle_weights_ts = particle_weights_vb.data
    _, max_ind = torch.max(particle_weights_ts, 2)
    bot_y = max_ind / mem_wid
    bot_x = max_ind % mem_wid
    # now we get the direction by looking at the densist direction of mass of direction from this position
    bot_dir = torch.zeros(batch_size, num_heads, 1)
    max_density = 0.
    for batch_ind in range(batch_size):
        for head_ind in range(num_heads):
            for dir in range(0, 4):
                particle_density_ts = particle_weights_ts[batch_ind][head_ind] * get_sensing_area_indices(bot_y[batch_ind][head_ind][0], bot_x[batch_ind][head_ind][0], np.deg2rad(dir * 90.))
                # print(particle_density_ts.view(mem_hei, mem_wid))
                if particle_density_ts.sum() >= max_density:
                    max_density = particle_density_ts.sum()
                    bot_dir[batch_ind][head_ind][0] = np.deg2rad(180.) - np.deg2rad(90.) * dir
                    if bot_dir[batch_ind][head_ind][0] < np.deg2rad(0.):
                        bot_dir[batch_ind][head_ind][0] += np.deg2rad(360.)
    return bot_y, bot_x, bot_dir

def get_trans_ts(trans_x, trans_y):
    # http://www.euclideanspace.com/maths/geometry/affine/aroundPoint/matrix2d/
    trans_ts = torch.eye(3, 3)
    trans_ts[0][2] = trans_x
    trans_ts[1][2] = trans_y
    return trans_ts

def get_rotat_ts(origin_x, origin_y, turn_by):
    # http://www.euclideanspace.com/maths/geometry/affine/aroundPoint/matrix2d/
    r00 =   np.cos(turn_by)
    r01 = - np.sin(turn_by)
    r10 =   np.sin(turn_by)
    r11 =   np.cos(turn_by)
    rotat_ts = torch.zeros(3, 3)
    rotat_ts[0][0] = r00
    rotat_ts[0][1] = r01
    rotat_ts[0][2] = origin_x - r00 * origin_x - r01 * origin_y
    rotat_ts[1][0] = r10
    rotat_ts[1][1] = r11
    rotat_ts[1][2] = origin_y - r10 * origin_x - r11 * origin_y
    rotat_ts[2][2] = 1
    return rotat_ts

def translate(particle_weights_vb, bot_dir, translate_by=1):
    transform_ts = get_trans_ts(np.cos(bot_dir) * translate_by, np.sin(bot_dir) * translate_by)
    return transform(particle_weights_vb, transform_ts)

# print(wl_prev_vb[0].view(mem_hei, mem_wid))
# translate(wl_prev_vb[0], np.deg2rad(0), translate_by=3).view(mem_hei, mem_wid)

def rotate(particle_weights_vb, origin_y, origin_x, turn_by=np.deg2rad(90.)):
    transform_ts = get_rotat_ts(origin_x, origin_y, turn_by)
    return transform(particle_weights_vb, transform_ts)

def transform(particle_weights_vb, transform_ts):
    """
    NOTE: we transform the weight by the transformation defined in transform_ts
    NOTE: inside this function the graph cannot be lost
    http://www.euclideanspace.com/maths/geometry/affine/aroundPoint/matrix2d/
    """
    # 0. we first prepare the indices of all the points in the current weight
    # y=2  /   /   /
    # y=1  /   /   /
    # y=0  /   /   /
    #     x=0 x=1 x=2
    indices_ts = torch.ones(3, mem_hei*mem_wid) # [x; y; 1]
    for y in range(0, mem_hei):
        for x in range(0, mem_wid):
            indices_ts[0][y * mem_wid + x] = x
            indices_ts[1][y * mem_wid + x] = y
    # 1. now we transform the indices to get the transformed indices
    transformed_indices_ts    = torch.mm(transform_ts, indices_ts)
    transformed_indices_ts[0] = torch.round(transformed_indices_ts[0]).type(torch.LongTensor) # x
    transformed_indices_ts[1] = torch.round(transformed_indices_ts[1]).type(torch.LongTensor) # y
    # 2. we also would only use those valid points: that after transformation they are still in the current map
    valid_x_indices_ts = torch.ge(transformed_indices_ts[0], 0) * torch.le(transformed_indices_ts[0], mem_wid-1) # x
    valid_y_indices_ts = torch.ge(transformed_indices_ts[1], 0) * torch.le(transformed_indices_ts[0], mem_hei-1) # y
    valid_indices_ts = valid_x_indices_ts * valid_y_indices_ts
    # 3. then we clamp the transformed indices
    transformed_indices_ts[0] = torch.clamp(transformed_indices_ts[0], min=0, max=mem_wid-1) # x
    transformed_indices_ts[1] = torch.clamp(transformed_indices_ts[1], min=0, max=mem_hei-1) # y
    # 4. finally we get the final indices
    final_indices_ts = transformed_indices_ts[1] * mem_wid + transformed_indices_ts[0]
    transformed_weights_vb = torch.index_select(particle_weights_vb.view(1, mem_hei * mem_wid), 1, Variable(final_indices_ts.type(torch.LongTensor))) * Variable(valid_indices_ts.type(torch.FloatTensor)).view(mem_hei, mem_wid)
    return transformed_weights_vb



bot_y, bot_x, bot_dir = localize(wl_prev_vb)#.view(batch_size, num_heads, mem_hei, mem_wid))
print(bot_y[0, 0, 0], bot_x[0, 0, 0], bot_dir[0, 0, 0])
print(wl_prev_vb[0].view(mem_hei, mem_wid))
trans(wl_prev_vb[0], 0, 0, , turn_by=np.deg2rad(-45.)).view(mem_hei, mem_wid)
rotat(wl_prev_vb[0], 0, 0, turn_by=np.deg2rad(-45.)).view(mem_hei, mem_wid)

print(wl_prev_vb[0].view(mem_hei, mem_wid))
rotate(wl_prev_vb[0], 2, 2, np.deg2rad(270)).view(mem_hei, mem_wid)
