import torch
import torch.nn as nn
from torch.autograd import Variable
import torch.nn.functional as F

a = Variable(torch.zeros(1, 1, 14, 14))
conv1 = nn.Conv2d(1, 1, 3, 2, 1)
conv2 = nn.Conv2d(1, 1, 3, 2, 1)
conv3 = nn.Conv2d(1, 1, 3, 2, 1)
conv4 = nn.Conv2d(1, 1, 3, 2, 1)
print(conv4(conv3(conv2(conv1(a)))))
