import torch
from torch.autograd import Variable
import torch.nn.functional as F

mem_hei = 8
mem_wid = 8
mem_dep = 32

memory_vb = Variable(torch.zeros(mem_hei, mem_wid, mem_dep))
map_vb = F.hardtanh(memory_vb.mean(2), min_val=0., max_val=1.).squeeze(2)
print(map_vb)
new_memory_vb = memory_vb + Variable(torch.rand(mem_hei, mem_wid, mem_dep) - 0.5)
new_map_vb = F.hardtanh(new_memory_vb.mean(2)).squeeze(2)
print(new_map_vb)
reduced_uncertainty_vb = (new_map_vb - map_vb).abs()
print(reduced_uncertainty_vb.sum())
