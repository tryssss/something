* ```normal_main.py```
> for grid-world experiments

* ```main.py```
> for gazebo experiments

* ```get_random_baseline_stats.py```
> for getting stats for episode_steps & episode_reward for finshing 10,000 episodes with random actions
> files need to be modified:
  * courses.py: change map size for each course
  * options.py: choose random agent, then in AgentParams, change the file names and steps
  * after files are saved, use get_random_baseline_stats to calculate the stats

* general (new, mostly would cover half of the world size)

| size | total steps | time     |
| ---  | ---         | ---      |
|  8   |   1,686,546 |  167.590 |
| 10   |   6,419,110 | 1713.324 |
| 12   |  14,668,245 | 3620.619 |
| 14   |  26,500,388 | 5731.187 |
| 16   |  41,667,564 | 7192.068 |

* steps

| size | mean     | std      | min | max    | mean + 3std | mean + 2std | mean + 1std |
| ---  | ---      | ---      | --- | ---    | ---         | ---         | ---         |
|  8   |  170.106 |  180.449 |   4 |  2,119 |     711.453 |     531.004 |     350.555 |
| 10   |  641.911 |  570.399 |  33 |  9,251 |   2,353.108 |    1782.709 |    1212.310 |
| 12   | 1466.825 | 1173.801 | 103 | 16,067 |   4,988.228 |    3814.427 |    2640.626 |
| 14   | 2650.039 | 1998.033 | 232 | 26,435 |   8,644.138 |    6646.105 |    4648.072 |
| 16   | 4166.756 | 2894.716 | 406 | 37,749 |  12,850.904 |    9956.188 |    7061.472 |

* reward

| size | mean     | std      | min       | max    |
| ---  | ---      | ---      | ---       | ---    |
|  8   |  -10.809 |   29.906 |  -306.013 | 11.013 |
| 10   |  -74.653 |   85.880 | -1386.520 | 11.053 |
| 12   | -162.847 |  154.385 | -2327.040 |  7.853 |
| 14   | -275.263 |  238.269 | -3467.867 |  1.547 |
| 16   | -404,142 |  312.411 | -4146.627 | -4.600 |

* general (old, where there might be a lot of worlds with only 1 free grid)

| size | total steps | time     |
| ---  | ---         | ---      |
|  8   |   1,316,797 |  141.069 |
| 10   |   4,721,585 |  489.143 |
| 12   |  10,584,727 | 1072.630 |
| 14   |  18,851,358 | 3551.464 |
| 16   |  29,568,076 | 4921.653 |

* steps

| size | mean     | std      | min | max    | mean + 3std |
| ---  | ---      | ---      | --- | ---    | ---         |
|  8   |  131.680 |  170.298 |   1 |  1,731 |     642.574 |
| 10   |  472.159 |  573.747 |   1 |  9,394 |   2,193.400 |
| 12   | 1058.473 | 1180.586 |   1 | 14,526 |   4,600.231 |
| 14   | 1885.136 | 1991.912 |   1 | 28,217 |   7,860.872 |
| 16   | 2956.808 | 3102.769 |   1 | 38,248 |  12,265.115 |

* reward

| size | mean     | std      | min       | max    |
| ---  | ---      | ---      | ---       | ---    |
|  8   |  -10.809 |   29.906 |  -306.013 | 11.013 |
| 10   |  -51.990 |   82.681 | -1468.147 | 10.813 |
| 12   | -110.964 |  146.813 | -2077.667 | 10.413 |
| 14   | -183.477 |  220.075 | -3266.933 | 10.480 |
| 16   | -267,983 |  306,972 | -3583,933 | 10.533 |
