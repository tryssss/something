from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import numpy as np

class Courses(object):  # courses for curriculum learning
    def __init__(self):
        self.world_siz_start = 4 - 2 + 6  # [6x6]   we leave 2 for edge
        self.world_siz_end   = 4 - 2 + 14 #10#15 # [15x15] we leave 2 for edge
        self.world_siz_inc   = 2    # NOTE: should be increase by 2 so that we can pad 1's on the smaller worlds
        # course_ind -> world_siz
        self.schedule = list(range(self.world_siz_start, self.world_siz_end + self.world_siz_inc, self.world_siz_inc))
        # self.early_stops = [711, 1783, 2641, 2650, 4167]
        self.early_stops = [750, 750, 750, 750, 750]
        # self.early_stops = [None, None, None, None, None]
        # self.early_stops = [2, 3, 8, 7, 4]
        self.num_courses = len(self.schedule)

    def get_course_ind(self, progress):
        # train_step/steps -> course_ind
        return np.floor(progress * self.num_courses).astype(int)

    def get_early_stop(self, course_ind):
        return self.early_stops[course_ind]

# courses = Courses()
# print(courses.schedule)
# print(courses.schedule[0])
# print(courses.get_course_ind(0.81))
# print(courses.get_early_stop(courses.get_course_ind(0.59)))
