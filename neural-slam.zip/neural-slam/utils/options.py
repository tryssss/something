from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import os
import visdom
import torch
import torch.nn as nn
import torch.optim as optim

from utils.helpers import loggerConfig
from utils.sharedAdam import SharedAdam

CONFIGS = [
# agent_type, env_type,     game,         model_type
# [ "empty",    "grid-world", "simple",     "none"      ], # 0
# [ "empty",    "grid-world", "curriculum", "none"      ], # 0
# [ "empty",    "gazebo",     "simple",     "none"      ], # 0
[ "random",   "grid-world", "curriculum", "none"      ], # 0
[ "a3c",      "grid-world", "simple",     "plain"     ], # 1
[ "a3c",      "grid-world", "curriculum", "plain"     ], # 2
[ "a3c",      "grid-world", "simple",     "slam"      ], # 3
[ "a3c",      "grid-world", "curriculum", "slam"      ], # 4
[ "a3c",      "gazebo",     "simple",     "plain"     ], # 5
[ "a3c",      "gazebo",     "simple",     "slam"      ]  # 6
]

class Params(object):   # NOTE: shared across all modules
    def __init__(self):
        self.verbose     = 0            # 0(warning) | 1(info) | 2(debug)

        # training signature
        # # NOTE: no motion, for course=0
        # self.machine     = "aiscpu3"    # "machine_id"
        # self.timestamp   = "17053000_1" # "yymmdd##"
        # # NOTE: motion, for course=0
        # self.machine     = "aisgpu3"    # "machine_id"
        # self.timestamp   = "17062400_0" # "yymmdd##"
        # # NOTE: motion, for course=1
        # self.machine     = "aisgpu8"    # "machine_id"
        # self.timestamp   = "17062100_1" # "yymmdd##"
        # # NOTE: motion, for course=2
        # self.machine     = "aisgpu8"    # "machine_id"
        # self.timestamp   = "17062100_22" # "yymmdd##"
        # NOTE
        self.machine     = "aisgpu2"    # "machine_id"
        self.timestamp   = "17091000"   # "yymmdd##"
        # training configuration
        self.mode        = 1            # 1(train) | 2(test model_file)
        self.config      = 2

        self.seed        = 123
        self.render      = False        # whether render the window from the original envs or not
        self.visualize   = True         # whether do online plotting and stuff or not
        self.save_best   = False        # save model w/ highest reward if True, otherwise always save the latest model

        self.agent_type, self.env_type, self.game, self.model_type = CONFIGS[self.config]

        self.enable_random_init_pose            = True  # NOTE: for env
        self.enable_internal_explore_reward     = False # NOTE: for env & agent:calculate explore_reward out of memory | from true map
        if self.agent_type == "a3c":
            self.enable_lstm        = True
            self.enable_continuous  = False
            self.enable_motion_model            = True  # NOTE: plain: True:  push motion also into the model
                                                        # NOTE: plain: False: 1 lstm w/ no motion input
                                                        # NOTE: slam:  True:  for head: apply explicit motion model motion before location focus
                                                        # NOTE: slam:  False: for head: input motion after lstm
            self.enable_nav_lstms_0             = False # NOTE: plain: True:  2 lstms, motion into the 1nd one
            self.enable_nav_lstms_1             = True  # NOTE: plain: True:  2 lstms, motion into the 2nd one
            if self.enable_nav_lstms_0 or self.enable_nav_lstms_1: assert self.enable_motion_model
            # NOTE: for plain:
            # NOTE: enable_motion_model=False                                                    | 1lstm, no motion input
            # NOTE: enable_motion_model=True, enable_nav_lstms_0=False, enable_nav_lstms_1=False | 1lstm, motion into 1st lstm
            # NOTE: enable_motion_model=True, enable_nav_lstms_0=True,  enable_nav_lstms_1=False | 2lstm, motion into 1st lstm
            # NOTE: enable_motion_model=True, enable_nav_lstms_0=False, enable_nav_lstms_1=True  | 2lstm, motion into 2st lstm
            # NOTE: for slam:
            # NOTE: enable_motion_model=False                                                    | motion input into ntm
            # NOTE: enable_motion_model=True                                                     | explicit motion model onto attention mechanism
            self.enable_eval_pregen_worlds      = True  # NOTE: use pregenerated worlds for evaluation
            if self.enable_internal_explore_reward: assert self.enable_motion_model
            if self.enable_eval_pregen_worlds:      assert self.env_type == "grid-world" and self.game == "curriculum"

            if self.env_type == "grid-world":
                self.num_processes  = 16
            elif self.env_type == "gazebo":
                self.num_processes  = 24

            self.use_cuda           = False
            self.dtype              = torch.FloatTensor
        else:
            self.enable_continuous  = False

            self.use_cuda           = torch.cuda.is_available()
            self.dtype              = torch.cuda.FloatTensor if torch.cuda.is_available() else torch.FloatTensor

        # prefix for model/log/visdom
        self.refs        = self.machine + "_" + self.timestamp # NOTE: using this as env for visdom
        self.root_dir    = os.getcwd()

        # model files
        # NOTE: will save the current model to model_name
        self.model_name  = self.root_dir + "/models/" + self.refs + ".pth"
        # NOTE: will load pretrained model_file if not None
        self.model_file  = None#self.root_dir + "/models/{TODO:FILL_IN_PRETAINED_MODEL_FILE}.pth"
        if self.mode == 2:
            self.model_file  = self.model_name  # NOTE: so only need to change self.mode to 2 to test the current training
            assert self.model_file is not None, "Pre-Trained model is None, Testing aborted!!!"
            self.refs = self.refs + "_test"     # NOTE: using this as env for visdom for testing, to avoid accidentally redraw on the training plots

        # logging configs
        self.log_name    = self.root_dir + "/logs/" + self.refs + ".log"
        self.logger      = loggerConfig(self.log_name, self.verbose)
        self.logger.warning("<===================================>")
        if self.enable_eval_pregen_worlds:
            self.eval_pregen_worlds_fil = self.root_dir + "/data/eval_pregen_worlds.pt"

        if self.visualize:
            self.vis = visdom.Visdom()
            self.logger.warning("bash$: python -m visdom.server")           # activate visdom server on bash
            self.logger.warning("http://localhost:8097/env/" + self.refs)   # open this address on browser

        # log options
        self.logger.warning("enable_random_init_pose:             " + str(self.enable_random_init_pose))
        self.logger.warning("enable_internal_explore_reward:      " + str(self.enable_internal_explore_reward))
        if self.agent_type == "a3c":
            self.logger.warning("enable_motion_model:                 " + str(self.enable_motion_model))

class EnvParams(Params):
    def __init__(self):
        super(EnvParams, self).__init__()

        self.enable_random_init_pose = None
        self.enable_internal_explore_reward = None

        self.batch_size = None
        if self.env_type == "grid-world":
            # self.sensor_type = "laser"
            self.sensor_type = "rectangle"
            self.laser_len = 3  # local view: [(2x3-1)x3]
            self.grid_siz  = 21 # size for each grid to show
            self.act_set   = 1  # 0: go {up, down, left, right}
                                # 1: turn-go {turn-left, turn-right, go}
        elif self.env_type == "gazebo": # TODO: check what is actually needed
            self.laser_len = 4  # TODO: should be same as range in kobuki urdf file
            self.grid_siz  = 21 # size for each grid to show
            # self.hei_state = 60
            # self.wid_state = 80
            # self.preprocess_mode = 1  # 0(nothing) | 1(rgb2gray) | 2(rgb2y) | 3(crop&resize depth)
            # self.img_encoding_type = "bgr8"
            #self.img_encoding_type = "32FC1"

class ControllerParams(Params):
    def __init__(self):
        super(ControllerParams, self).__init__()

        self.batch_size     = None
        self.input_dim      = None  # set after env
        self.read_vec_dim   = None  # num_read_heads x mem_wid
        self.output_dim     = None  # set after env
        self.hidden_dim     = None  #
        self.mem_hei        = None  # set after memory
        self.mem_wid        = None  # set after memory
        self.mem_dep        = None  # set after memory

class HeadParams(Params):
    def __init__(self):
        super(HeadParams, self).__init__()

        self.enable_motion_model = None
        self.num_heads = None
        self.batch_size = None
        self.output_dim = None
        self.hidden_dim = None
        self.mem_hei = None
        self.mem_wid = None
        self.mem_dep = None
        self.laser_len = None
        self.num_allowed_shifts = 3

class WriteHeadParams(HeadParams):
    def __init__(self):
        super(WriteHeadParams, self).__init__()

class ReadHeadParams(HeadParams):
    def __init__(self):
        super(ReadHeadParams, self).__init__()

class MemoryParams(Params):
    def __init__(self):
        super(MemoryParams, self).__init__()

        self.batch_size = None
        self.mem_hei = None
        self.mem_wid = None
        self.mem_dep = None
        self.laser_len = None   # for computing internal reward

class AccessorParams(Params):
    def __init__(self):
        super(AccessorParams, self).__init__()

        self.enable_motion_model = None
        self.batch_size = None
        self.output_dim = None
        self.hidden_dim = None
        self.num_write_heads = None
        self.num_read_heads = None
        self.mem_hei = None
        self.mem_wid = None
        self.mem_dep = None
        self.laser_len = None
        self.clip_value = None
        self.write_head_params = WriteHeadParams()
        self.read_head_params  = ReadHeadParams()
        self.memory_params     = MemoryParams()

class ModelParams(Params):# settings for network architecture
    def __init__(self):
        super(ModelParams, self).__init__()

        self.batch_size     = None
        self.input_dim      = None  # set after env
        self.read_vec_dim   = None  # num_read_heads x mem_wid
        self.output_dim     = None  # set after env
        self.hidden_dim     = None

        if self.model_type == "plain":
            self.num_write_heads = 1
            self.num_read_heads  = 1
            self.mem_hei         = 16   # TODO: should be set after env
            self.mem_wid         = 16   # TODO: should be set after env
            self.mem_dep         = 16
            self.clip_value      = 20.  # clips controller and model output values to in between
        elif self.model_type == "slam":
            self.enable_motion_model = None

            self.num_write_heads = 1
            self.num_read_heads  = 1
            self.mem_hei         = None # TODO: should be set after env
            self.mem_wid         = None # TODO: should be set after env
            self.mem_dep         = 16
            self.clip_value      = 20.  # clips controller and model output values to in between

        self.controller_params = ControllerParams()
        self.accessor_params   = AccessorParams()

class AgentParams(Params):  # hyperparameters for drl agents
    def __init__(self):
        super(AgentParams, self).__init__()

        self.hidden_dim = None  # set after model
        if self.agent_type == "empty":
            self.value_criteria = nn.BCELoss()
            self.optim          = optim.RMSprop
            # self.optim_eps      = 1e-10     # NOTE: we use this setting to be equivalent w/ the default settings in tensorflow
            # self.optim_alpha    = 0.9       # NOTE: only for rmsprop, alpha is the decay in tensorflow, whose default is 0.9

            self.steps          = 1000#100000    # max #iterations
            self.batch_size     = 1
            self.hidden_dim     = 128
            self.early_stop     = 200       # max #steps per episode
            self.gamma          = 0.99
            self.clip_grad      = 50.
            self.lr             = 1e-4
            self.eval_freq      = 500
            self.eval_steps     = 50
            self.prog_freq      = self.eval_freq
            self.test_nepisodes = 5

            self.rollout_steps  = 1#20        # max look-ahead steps in a single rollout
        elif self.agent_type == "random":
            self.value_criteria = nn.BCELoss()
            self.optim          = optim.RMSprop
            # self.optim_eps      = 1e-10     # NOTE: we use this setting to be equivalent w/ the default settings in tensorflow
            # self.optim_alpha    = 0.9       # NOTE: only for rmsprop, alpha is the decay in tensorflow, whose default is 0.9

            # TODO: modify this block
            self.visualize      = False
            self.steps_fil      = self.root_dir + "/data/episode_steps_grid_world_4.pt"
            self.reward_fil     = self.root_dir + "/data/episode_reward_grid_world_4.pt"
            self.steps          = 510200000  # max #iterations

            self.batch_size     = 1
            self.hidden_dim     = 128
            self.early_stop     = None      # NOTE: for this agent we want the agent to do random actions to finish episodes
            self.gamma          = 0.99
            self.clip_grad      = 50.
            self.lr             = 1e-4
            self.eval_freq      = self.steps + 1 # NOTE: for this agent we don't need evaluation
            self.eval_steps     = 50
            self.prog_freq      = self.eval_freq
            self.test_nepisodes = 5

            self.rollout_steps  = 1#20        # max look-ahead steps in a single rollout
        elif self.agent_type == "a3c":
            self.value_criteria = nn.MSELoss()
            self.optim          = SharedAdam  # NOTE: should add a shared rmsprop
            # self.optim_eps      = 1e-10     # NOTE: we use this setting to be equivalent w/ the default settings in tensorflow
            # self.optim_alpha    = 0.9       # NOTE: only for rmsprop, alpha is the decay in tensorflow, whose default is 0.9

            # NOTE: {} steps (training): at most {}xrollout_steps frames == {}xrollout_steps/early_stop episodes
            self.steps          = 5000000#2500000   # max #iterations
            self.batch_size     = 1
            self.hidden_dim     = 128
            self.gamma          = 0.99
            self.clip_grad      = 50.
            self.lr             = 1e-4
            self.eval_freq      = 300       # NOTE: here means every this many seconds
            self.prog_freq      = self.eval_freq
            self.test_nepisodes = 10

            if self.env_type == "grid-world":
                if self.game == "simple":
                    self.steps      = 1000000
                    self.rollout_steps  = 20    # max look-ahead steps in a single rollout
                    self.early_stop     = 500   # max #steps per episode
                    self.eval_steps     = 3000
                elif self.game == "curriculum":
                    self.steps      = 5000000
                    self.rollout_steps  = 20    # max look-ahead steps in a single rollout
                    self.early_stop     = 750   # max #steps per episode
                    self.eval_steps     = 5000#3000
            elif self.env_type == "gazebo":
                self.rollout_steps  = 50    # max look-ahead steps in a single rollout
                self.early_stop     = 2500  # max #steps per episode
                self.eval_steps     = 5000
            self.tau            = 1.

        self.env_params   = EnvParams()
        self.model_params = ModelParams()

class Options(Params):
    agent_params  = AgentParams()
