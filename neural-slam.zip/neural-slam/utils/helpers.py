from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import logging
import numpy as np
# import cv2
from collections import namedtuple
import torch

def loggerConfig(log_file, verbose=2):
   logger      = logging.getLogger()
   formatter   = logging.Formatter('[%(levelname)-8s] (%(processName)-11s) %(message)s')
   fileHandler = logging.FileHandler(log_file, 'w')
   fileHandler.setFormatter(formatter)
   logger.addHandler(fileHandler)
   # logger.addHandler(logging.StreamHandler())
   if verbose >= 2:
       logger.setLevel(logging.DEBUG)
   elif verbose >= 1:
       logger.setLevel(logging.INFO)
   else:
       # NOTE: we currently use this level to log to get rid of visdom's info printouts
       logger.setLevel(logging.WARNING)
   return logger

# This is to be understood as a transition: Given `state0`, performing `action`
# yields `reward` and results in `state1`, which might be `terminal`.
# NOTE: used as the return format for Env(), and for format to push into replay memory for off-policy methods
# NOTE: when return from Env(), state0 is always None
Experience  = namedtuple('Experience',  'state0, action, reward, state1, terminal1')
# NOTE: also used for on-policy methods for collect experiences over a rollout of an episode
# NOTE: policy_vb & value0_vb for storing output Variables along a rollout # NOTE: they should not be detached from the graph!
AugmentedExperience = namedtuple('AugmentedExperience', 'state0, action, reward, state1, terminal1, policy_vb, sigmoid_vb, value0_vb')

# TODO: check the order rgb to confirm
def rgb2gray(rgb):
    gray_image     = 0.2126 * rgb[..., 0]
    gray_image[:] += 0.0722 * rgb[..., 1]
    gray_image[:] += 0.7152 * rgb[..., 2]
    return gray_image

def bgr2gray(bgr):
    gray_image     = 0.2126 * bgr[..., 2]
    gray_image[:] += 0.0722 * bgr[..., 1]
    gray_image[:] += 0.7152 * bgr[..., 0]
    return gray_image

# TODO: check the order rgb to confirm
def rgb2y(rgb):
    y_image     = 0.299 * rgb[..., 0]
    y_image[:] += 0.587 * rgb[..., 1]
    y_image[:] += 0.114 * rgb[..., 2]
    return y_image

def scale(image, hei_image, wid_image):
    return cv2.resize(image, (wid_image, hei_image)) # better change hei and wid

def one_hot(n_classes, labels):
    one_hot_labels = np.zeros(labels.shape + (n_classes,))
    for c in range(n_classes):
        one_hot_labels[labels == c, c] = 1
    return one_hot_labels

def tile_ts(input_ts, tile_by=21):  # NOTE: cos grid_siz=21
    # input_ts: [hei x wid]
    assert input_ts.dim() == 2
    hei = input_ts.size(0)
    wid = input_ts.size(0)
    output_ts = torch.zeros(hei * tile_by, wid * tile_by)
    for y in range(hei):
        for x in range(wid):
            output_ts[(y*tile_by):((y+1)*tile_by), (x*tile_by):((x+1)*tile_by)] = input_ts[y][x]
    return output_ts
