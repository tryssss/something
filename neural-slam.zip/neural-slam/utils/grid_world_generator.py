from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import numpy as np
from random import shuffle

from utils.courses import Courses

class GridWorldGenerator(object):
    def __init__(self, laser_len, level=2):
        self.laser_len = laser_len
        self.level = level
        # NOTE: we curriculum from easy to hard over the training

        self.courses = Courses()

    @property
    def map_siz(self):
        return self.courses.world_siz_end

    @property
    def sensor_len(self):
        return self.laser_len

    def get_new(self, course_ind):
        world_siz = self.courses.schedule[course_ind]
        # setting up
        burn_prob = (10. - self.level) / 10.
        edge_len = self.laser_len - 1
        # # NOTE: option 1: always burn from the upper left corner
        # bot_y_start = edge_len
        # bot_x_start = edge_len
        min_x = edge_len
        min_y = edge_len
        max_x = world_siz - edge_len - 1
        max_y = world_siz - edge_len - 1
        # NOTE: option 2: random burn starting locations
        bot_y_start = np.random.randint(min_y, max_y + 1)
        bot_x_start = np.random.randint(min_x, max_x + 1)
        assert world_siz > edge_len * 2
        # NOTE: we start off w/ all 1's then grass_fire 0 from the starting position
        # NOTE: we would make sure the borders of the world don't get burnt
        # NOTE: so bot cannot see through walls
        world = np.ones([world_siz, world_siz]).astype(np.float64)
        max_num_obj = world_siz * world_siz - ((max_y - min_y + 1) * (max_x - min_x + 1) / 2)
        return self.do_grass_fire(world, max_num_obj, bot_y_start, bot_x_start, min_y, max_y, min_x, max_x, burn_prob)

    def do_grass_fire(self, world, max_num_obj, fire_y_start, fire_x_start, min_y, max_y, min_x, max_x, burn_prob):
        # we generate random mazes until criterion is met
        # or if we still cannot get a satisfactory one we just use the best one of those 10 mazes
        worlds = []
        worlds.append(world)
        worlds[0][fire_y_start][fire_x_start] = 0
        for i in range(100):
            worlds.append(self.grass_fire(worlds[i].copy(), min_y, max_y, min_x, max_x, burn_prob))
            if np.sum(worlds[-1]) <= max_num_obj:
                break
        return worlds[-1]

    def grass_fire(self, world, min_y, max_y, min_x, max_x, burn_prob):
        grass_list = [] # list of all neighboring grass
        grass_list.append([ 0, -1])
        grass_list.append([ 0,  1])
        grass_list.append([ 1,  0])
        grass_list.append([-1,  0])
        grass_order = [i for i in range(len(grass_list))]
        shuffle(grass_order)
        # 0. first we push the starting position of fire into open_list
        open_list = []
        closed_list = []
        for y in range(min_y, max_y + 1):
            for x in range(min_x, max_x + 1):
                if world[y][x] == 0:
                    open_list.append([y, x])
        # 1. now we start the fire
        while len(open_list) > 0:
            fire = open_list.pop(0)
            closed_list.append(fire)
            # make it a free cell by some burn probability
            if np.random.uniform() < burn_prob:
                world[fire[0]][fire[1]] = 0
                # we only will burn its neighbors if it is burnt
                # we shuffle the order to choose neighbors to increase randomness
                shuffle(grass_order) # NOTE: this func works in place
                for i in range(len(grass_order)):
                    grass = list(np.array(fire) + np.array(grass_list[grass_order[i]]))
                    if grass[0] >= min_y and grass[0] <= max_y and \
                       grass[1] >= min_x and grass[1] <= max_x and \
                       grass not in closed_list and \
                       world[grass[0]][grass[1]] == 1:   # has not been burnt
                        if np.random.uniform() < burn_prob:
                            open_list.append(grass)
        return world

    # def do_grass_fire_old(self, world, max_num_obj, fire_y_start, fire_x_start, min_y, max_y, min_x, max_x, burn_prob):
    #     # we generate random mazes until criterion is met
    #     # or if we still cannot get a satisfactory one we just use the best one of those 10 mazes
    #     worlds = []
    #     worlds.append(world)
    #     world_ind = 0
    #     for i in range(100):
    #         worlds.append(self.grass_fire_old(worlds[i].copy(), max_num_obj, fire_y_start, fire_x_start, min_y, max_y, min_x, max_x, burn_prob))
    #     return worlds[-1]
    #
    # def grass_fire_old(self, world, max_num_obj, fire_y_start, fire_x_start, min_y, max_y, min_x, max_x, burn_prob):
    #     grass_list = [] # list of all neighboring grass
    #     grass_list.append([ 0, -1])
    #     grass_list.append([ 0,  1])
    #     grass_list.append([ 1,  0])
    #     grass_list.append([-1,  0])
    #     grass_order = [i for i in range(len(grass_list))]
    #     shuffle(grass_order)
    #     # 0. first we push the starting position of fire into open_list
    #     open_list = []
    #     closed_list = []
    #     open_list.append([fire_y_start, fire_x_start])
    #     # 1. now we start the fire
    #     while len(open_list) > 0:
    #         fire = open_list.pop(0)
    #         closed_list.append(fire)
    #         # make it a free cell by some burn probability
    #         if (fire[0] == fire_y_start and fire[1] == fire_x_start) or \
    #            np.random.uniform() < burn_prob:
    #             world[fire[0]][fire[1]] = 0
    #             # we only will burn its neighbors if it is burnt
    #             # we shuffle the order to choose neighbors to increase randomness
    #             shuffle(grass_order) # NOTE: this func works in place
    #             for i in range(len(grass_order)):
    #                 grass = list(np.array(fire) + np.array(grass_list[grass_order[i]]))
    #                 if grass[0] >= min_y and grass[0] <= max_y and \
    #                    grass[1] >= min_x and grass[1] <= max_x and \
    #                    grass not in closed_list and \
    #                    world[grass[0]][grass[1]] == 1:   # has not been burnt
    #                     if np.random.uniform() < burn_prob:
    #                         open_list.append(grass)
    #     return world

# worlds = GridWorldGenerator(10, 3)
# print(worlds.get_new(10))
# pass
# pass
# import numpy as np
# world_siz_start = 6
# world_siz_end = 15
# total_nepisodes = 100
# nepisodes = 1000
# world_siz = np.floor(world_siz_start + (world_siz_end - world_siz_start + 1) * (nepisodes / total_nepisodes)).astype(int)
# world_siz = min(world_siz, world_siz_end)
# print(world_siz)
