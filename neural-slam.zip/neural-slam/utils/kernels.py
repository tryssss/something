from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import numpy as np
import scipy.stats as st
import torch
import torch.nn.functional as F
from torch.autograd import Variable

"""
      ^ (3)
< (2)       > (0)
      V (1)
"""

def gaussian_kernel(kernel_siz, n_sigma=3):
    """
    generates a 2D Gaussian kernel tensor
    returns:
        kernel_ts: [kernel_siz x kernel_siz]
    """
    interval = (2 *n_sigma + 1.) / (kernel_siz)
    x = np.linspace(- n_sigma-interval / 2., n_sigma + interval / 2., kernel_siz + 1)
    kernel_1d = np.diff(st.norm.cdf(x))
    kernel_raw = np.sqrt(np.outer(kernel_1d, kernel_1d))
    kernel = kernel_raw / kernel_raw.sum()
    return torch.from_numpy(kernel)

def init_particle_weights_ts(map_hei, map_wid, laser_len=3, init_pose=[2,2,0], pad_edg=2):
    """
    returns:
        particle_weights_ts: [map_hei x map_wid]
    """
    # init_pose = [laser_len - 1, laser_len - 1, 0]   # put pose in center of the kernel
    bot_y   = init_pose[0]
    bot_x   = init_pose[1]
    bot_dir = init_pose[2]
    edg_len = laser_len - 1
    kernel_siz = 2 * laser_len - 1
    kernel_ts = gaussian_kernel(kernel_siz)
    if bot_dir == 0:
        min_y = bot_y - edg_len
        max_y = bot_y + edg_len
        min_x = bot_x
        max_x = bot_x + edg_len
        kernel_ts = kernel_ts[:, (laser_len-1)::]
    elif bot_dir == 1:
        min_y = bot_y
        max_y = bot_y + edg_len
        min_x = bot_x - edg_len
        max_x = bot_x + edg_len
        kernel_ts = kernel_ts[(laser_len-1)::, :]
    elif bot_dir == 2:
        min_y = bot_y - edg_len
        max_y = bot_y + edg_len
        min_x = bot_x - edg_len
        max_x = bot_x
        kernel_ts = kernel_ts[:, 0:laser_len]
    elif bot_dir == 3:
        min_y = bot_y - edg_len
        max_y = bot_y
        min_x = bot_x - edg_len
        max_x = bot_x + edg_len
        kernel_ts = kernel_ts[0:laser_len, :]
    kernel_ts = kernel_ts / kernel_ts.sum()
    # particle_weights_ts = torch.zeros(map_hei, map_wid)
    # particle_weights_ts[min_y:max_y+1, min_x:max_x+1] = kernel_ts
    # NOTE: for the gazebo_env, so that we don't have to pad everything in world
    particle_weights_ts = torch.zeros(map_hei + 2 * pad_edg, map_wid + 2 * pad_edg)
    particle_weights_ts[pad_edg+min_y:pad_edg+max_y+1, pad_edg+min_x:pad_edg+max_x+1] = kernel_ts
    particle_weights_ts = particle_weights_ts[pad_edg:map_hei+pad_edg, pad_edg:map_wid+pad_edg]
    return particle_weights_ts

# map_hei = 8
# map_wid = 8
# bot_y = 1
# bot_x = 1
# bot_dir = 3
#
# print(init_particle_weights_ts(map_hei, map_wid, laser_len, [bot_y, bot_x, bot_dir]))
