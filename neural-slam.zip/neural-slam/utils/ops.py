from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import torch
import torch.nn.functional as F
# from torch.autograd import Variable

def stable_log(input_vb, eps=1e-6):
    return torch.log(input_vb + eps)

def stable_softmax(input_vb):
    return F.softmax(input_vb)

# def stable_softmax(input_vb, min_val=-50):
#     # NOTE: we add this value to avoid trouble in log of
#     # NOTE: a really small value when doing backward
#     input_vb = torch.clamp(input_vb, min=min_val)
#     return F.softmax(input_vb)

# def clamp_memory(input_vb, clamp_val=50):
#     input_vb = torch.clamp(input_vb, min=-clamp_val, max=clamp_val)
#     return clamp_out_zero(input_vb)
#
# def clamp_out_zero(input_vb, eps=1e-6):
#     # NOTE: we clamp out the values in between [-eps,eps]
#     return torch.sign(input_vb) * torch.clamp(torch.abs(input_vb), min=eps)

# batch_size = 3
# input_dim  = 5
# input_ts = torch.rand(batch_size, input_dim)
# input_ts[0, :] = 1e-200
# input_ts[:, 2] = 100
# input_vb = Variable(input_ts)
# print(input_vb)
# print(torch.log(input_vb))
# print(stable_log(input_vb))
# print(clamp_memory(input_vb))
# print(stable_softmax(clamp_memory(input_vb)))
# print(torch.log(stable_softmax(clamp_memory(input_vb))))

# print(clamp_out_zero(input_vb))
# print(np.exp(-10))
# input_ts[:, -1] = -50
# input_vb = Variable(input_ts)
# print(input_vb)
# # print(F.softmax(input_vb))
# out = stable_softmax(input_vb)
# print(torch.log(out))
# # print(stable_softmax(input_vb))
