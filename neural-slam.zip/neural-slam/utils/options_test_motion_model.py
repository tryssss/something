from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import os
import visdom
import torch
import torch.nn as nn
import torch.optim as optim

from utils.helpers import loggerConfig
from utils.sharedAdam import SharedAdam

CONFIGS = [
# agent_type, env_type,     game,         model_type
# [ "empty",    "grid-world", "simple",     "none"      ], # 0
[ "empty",    "grid-world", "curriculum", "none"      ], # 0
# [ "empty",    "gazebo",     "simple",     "none"      ], # 0
[ "a3c",      "grid-world", "simple",     "plain"     ], # 1
[ "a3c",      "grid-world", "curriculum", "plain"     ], # 2
[ "a3c",      "grid-world", "simple",     "slam"      ], # 3
[ "a3c",      "grid-world", "curriculum", "slam"      ], # 4
[ "a3c",      "gazebo",     "simple",     "slam"      ]  # 5
]

class Params(object):   # NOTE: shared across all modules
    def __init__(self):
        self.verbose     = 0            # 0(warning) | 1(info) | 2(debug)

        # training signature
        self.machine     = "aiscpu3"    # "machine_id"
        self.timestamp   = "17060500"   # "yymmdd##"
        # training configuration
        self.mode        = 2            # 1(train) | 2(test model_file)
        self.config      = 3

        self.seed        = 123
        self.render      = False        # whether render the window from the original envs or not
        self.visualize   = True         # whether do online plotting and stuff or not
        self.save_best   = False        # save model w/ highest reward if True, otherwise always save the latest model

        self.agent_type, self.env_type, self.game, self.model_type = CONFIGS[self.config]

        self.enable_random_init_pose            = True  # NOTE: for env
        self.enable_internal_explore_reward     = False # NOTE: for env & agent:calculate explore_reward out of memory | from true map
        if self.agent_type == "a3c":
            self.enable_lstm        = True
            self.enable_continuous  = False
            self.enable_motion_model            = True  # NOTE: for head: apply motion before location focus
            if self.enable_internal_explore_reward: assert self.enable_motion_model

            self.num_processes      = 16

            self.use_cuda           = False
            self.dtype              = torch.FloatTensor
        else:
            self.enable_continuous  = False

            self.use_cuda           = torch.cuda.is_available()
            self.dtype              = torch.cuda.FloatTensor if torch.cuda.is_available() else torch.FloatTensor

        # prefix for model/log/visdom
        self.refs        = self.machine + "_" + self.timestamp # NOTE: using this as env for visdom
        self.root_dir    = os.getcwd()

        # model files
        # NOTE: will save the current model to model_name
        self.model_name  = self.root_dir + "/models/" + self.refs + ".pth"
        # NOTE: will load pretrained model_file if not None
        self.model_file  = None#self.root_dir + "/models/{TODO:FILL_IN_PRETAINED_MODEL_FILE}.pth"
        if self.mode == 2:
            self.model_file  = self.model_name  # NOTE: so only need to change self.mode to 2 to test the current training
            assert self.model_file is not None, "Pre-Trained model is None, Testing aborted!!!"
            self.refs = self.refs + "_test"     # NOTE: using this as env for visdom for testing, to avoid accidentally redraw on the training plots

        # logging configs
        self.log_name    = self.root_dir + "/logs/" + self.refs + ".log"
        self.logger      = loggerConfig(self.log_name, self.verbose)
        self.logger.warning("<===================================>")

        if self.visualize:
            self.vis = visdom.Visdom()
            self.logger.warning("bash$: python -m visdom.server")           # activate visdom server on bash
            self.logger.warning("http://localhost:8097/env/" + self.refs)   # open this address on browser

        # log options
        self.logger.warning("enable_random_init_pose:             " + str(self.enable_random_init_pose))
        self.logger.warning("enable_internal_explore_reward:      " + str(self.enable_internal_explore_reward))
        if self.agent_type == "a3c":
            self.logger.warning("enable_motion_model:                 " + str(self.enable_motion_model))

class EnvParams(Params):
    def __init__(self):
        super(EnvParams, self).__init__()

        self.enable_random_init_pose = None
        self.enable_internal_explore_reward = None

        self.batch_size = None
        if self.env_type == "grid-world":
            # self.sensor_type = "laser"
            self.sensor_type = "rectangle"
            self.laser_len = 3  # local view: [(2x3-1)x3]
            self.grid_siz  = 21 # size for each grid to show
            self.act_set   = 1  # 0: go {up, down, left, right}
                                # 1: turn-go {turn-left, turn-right, go}
        elif self.env_type == "gazebo": # TODO: check what is actually needed
            self.laser_len = 4  # TODO: should be same as range in kobuki urdf file
            self.grid_siz  = 21 # size for each grid to show
            # self.hei_state = 60
            # self.wid_state = 80
            # self.preprocess_mode = 1  # 0(nothing) | 1(rgb2gray) | 2(rgb2y) | 3(crop&resize depth)
            # self.img_encoding_type = "bgr8"
            #self.img_encoding_type = "32FC1"

class ControllerParams(Params):
    def __init__(self):
        super(ControllerParams, self).__init__()

        self.batch_size     = None
        self.input_dim      = None  # set after env
        self.read_vec_dim   = None  # num_read_heads x mem_wid
        self.output_dim     = None  # set after env
        self.hidden_dim     = None  #
        self.mem_hei        = None  # set after memory
        self.mem_wid        = None  # set after memory
        self.mem_dep        = None  # set after memory

class HeadParams(Params):
    def __init__(self):
        super(HeadParams, self).__init__()

        self.enable_motion_model = None
        self.num_heads = None
        self.batch_size = None
        self.hidden_dim = None
        self.mem_hei = None
        self.mem_wid = None
        self.mem_dep = None
        self.laser_len = None
        self.num_allowed_shifts = 3

class WriteHeadParams(HeadParams):
    def __init__(self):
        super(WriteHeadParams, self).__init__()

class ReadHeadParams(HeadParams):
    def __init__(self):
        super(ReadHeadParams, self).__init__()

class MemoryParams(Params):
    def __init__(self):
        super(MemoryParams, self).__init__()

        self.batch_size = None
        self.mem_hei = None
        self.mem_wid = None
        self.mem_dep = None

class AccessorParams(Params):
    def __init__(self):
        super(AccessorParams, self).__init__()

        self.enable_motion_model = None
        self.batch_size = None
        self.hidden_dim = None
        self.num_write_heads = None
        self.num_read_heads = None
        self.mem_hei = None
        self.mem_wid = None
        self.mem_dep = None
        self.clip_value = None
        self.write_head_params = WriteHeadParams()
        self.read_head_params  = ReadHeadParams()
        self.memory_params     = MemoryParams()

class ModelParams(Params):# settings for network architecture
    def __init__(self):
        super(ModelParams, self).__init__()

        self.batch_size     = None
        self.input_dim      = None  # set after env
        self.read_vec_dim   = None  # num_read_heads x mem_wid
        self.output_dim     = None  # set after env
        self.hidden_dim     = None

        if self.model_type == "plain":
            self.num_write_heads = 1
            self.num_read_heads  = 1
            self.mem_hei         = 16   # TODO: should be set after env
            self.mem_wid         = 16   # TODO: should be set after env
            self.mem_dep         = 16
            self.clip_value      = 20.  # clips controller and model output values to in between
        elif self.model_type == "slam":
            self.enable_motion_model = None

            self.num_write_heads = 1
            self.num_read_heads  = 1
            self.mem_hei         = None # TODO: should be set after env
            self.mem_wid         = None # TODO: should be set after env
            self.mem_dep         = 16
            self.clip_value      = 20.  # clips controller and model output values to in between

        self.controller_params = ControllerParams()
        self.accessor_params   = AccessorParams()

class AgentParams(Params):  # hyperparameters for drl agents
    def __init__(self):
        super(AgentParams, self).__init__()

        self.hidden_dim = None  # set after model
        if self.agent_type == "empty":
            self.value_criteria = nn.BCELoss()
            self.optim          = optim.RMSprop
            # self.optim_eps      = 1e-10     # NOTE: we use this setting to be equivalent w/ the default settings in tensorflow
            # self.optim_alpha    = 0.9       # NOTE: only for rmsprop, alpha is the decay in tensorflow, whose default is 0.9

            self.steps          = 5#1000#100000    # max #iterations
            self.batch_size     = 1
            self.hidden_dim     = 128
            self.early_stop     = 1#200       # max #steps per episode
            self.gamma          = 0.99
            self.clip_grad      = 50.
            self.lr             = 1e-4
            self.eval_freq      = 500
            self.eval_steps     = 50
            self.prog_freq      = self.eval_freq
            self.test_nepisodes = 5

            self.rollout_steps  = 1#20        # max look-ahead steps in a single rollout
        elif self.agent_type == "a3c":
            self.value_criteria = nn.MSELoss()
            self.optim          = SharedAdam  # NOTE: should add a shared rmsprop
            # self.optim_eps      = 1e-10     # NOTE: we use this setting to be equivalent w/ the default settings in tensorflow
            # self.optim_alpha    = 0.9       # NOTE: only for rmsprop, alpha is the decay in tensorflow, whose default is 0.9

            # NOTE: {} steps (training): at most {}xrollout_steps frames == {}xrollout_steps/early_stop episodes
            self.steps          = 50#5000000#2500000   # max #iterations
            self.batch_size     = 1
            self.hidden_dim     = 128
            self.gamma          = 0.99
            self.clip_grad      = 50.
            self.lr             = 1e-4
            self.eval_freq      = 300       # NOTE: here means every this many seconds
            self.prog_freq      = self.eval_freq
            self.test_nepisodes = 5#10

            if self.env_type == "grid-world":
                self.rollout_steps  = 20    # max look-ahead steps in a single rollout
                self.early_stop     = 10#500   # max #steps per episode
                self.eval_steps     = 3000
            elif self.env_type == "gazebo":
                self.rollout_steps  = 50    # max look-ahead steps in a single rollout
                self.early_stop     = 5000  # max #steps per episode
                self.eval_steps     = 5000
            self.tau            = 1.

        self.env_params   = EnvParams()
        self.model_params = ModelParams()

class Options(Params):
    agent_params  = AgentParams()
