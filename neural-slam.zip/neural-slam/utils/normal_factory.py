from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from core.envs.grid_world import GridWorldEnv
# from gazebo.gazebo_env import GazeboEnv
EnvDict = {"grid-world": GridWorldEnv,
           "gazebo":     None}

from core.models.plain_model import PlainModel
from core.models.slam_model import SLAMModel
ModelDict = {"none":  None,
             "plain": PlainModel, # with only controller, no accessor
             "slam":  SLAMModel}  # we want this circuit to learn to do slam hopefully :P

from core.agents.empty import EmptyAgent
from core.agents.random import RandomAgent
from core.agents.a3c import A3CAgent
AgentDict = {"empty":  EmptyAgent,  # to test integration of new envs, contains only the most basic control loop
             "random": RandomAgent, # to get baseline stats for random actions for different world sizes
             "a3c":    A3CAgent}    # we want the agent to learn to active-slam w/ the SLAMCircuit :P
