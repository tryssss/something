from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import numpy as np
from pathlib2 import Path
import time
import torch
import torch.nn as nn
from torch.autograd import Variable
import torch.nn.functional as F

class MotionModel(object):
    def __init__(self, env_type, root_dir, map_hei, map_wid, laser_len, num_actions):
        self.env_type = env_type
        self.data_fil = root_dir + "/data/sensing_area_indices_ts_map{" + str(map_hei).zfill(2) + "x" + str(map_wid).zfill(2) + "}_laser{" + str(laser_len) + "}.pt"
        self.map_hei = map_hei
        self.map_wid = map_wid
        self.laser_len = laser_len
        self.num_actions = num_actions
        self._load_sensing_area_indices_ts()

    def _load_sensing_area_indices_ts(self):
        deg_inc = 1
        if Path(self.data_fil).is_file():   # already exists
            print("Data Loaded")
            self.sensing_area_indices_ts = torch.load(self.data_fil)
        else:
            self.sensing_area_indices_ts = None
            for bot_y in range(self.map_hei):
                for bot_x in range(self.map_wid):
                    for bot_dir in range(0, 360, deg_inc):
                        if self.sensing_area_indices_ts is None:
                            self.sensing_area_indices_ts = self._get_sensing_area_indices(bot_y, bot_x, np.deg2rad(bot_dir))
                        else:
                            self.sensing_area_indices_ts = torch.cat((self.sensing_area_indices_ts,
                                                                      self._get_sensing_area_indices(bot_y, bot_x, np.deg2rad(bot_dir))), 0)
            torch.save(self.sensing_area_indices_ts.view(self.map_hei, self.map_wid, 360//deg_inc, self.map_hei * self.map_wid), self.data_fil)

    # localization funcs
    def _get_sensing_area_indices(self, bot_y, bot_x, bot_dir):
        """
        get the indices for the sensing area from [bot_y, bot_x] facing bot_dir
        we then use this to multiply w/ the head weights to get the density mass
        on this sensing area so as to choose the direction w/ the largest density
        mass as our direction
        """
        indices = torch.zeros(self.map_hei, self.map_wid)
        for dir in np.arange(bot_dir - np.deg2rad(90.), bot_dir + np.deg2rad(91.), np.deg2rad(1.)):
            for len in range(0, self.laser_len):
                y = np.minimum(np.maximum(0, np.round(bot_y + len * np.sin(dir))), self.map_hei - 1)
                x = np.minimum(np.maximum(0, np.round(bot_x + len * np.cos(dir))), self.map_wid - 1)
                indices[y][x] = 1
        return indices.view(1, self.map_hei * self.map_wid)

    def _localize(self, particle_weights_vb):
        """
        variables needed:
            particle_weights: [batch_size x num_particles x(map_hei x map_wid)]
        returns:
            bot_pose:         [bot_y, bot_x, bot_dir]
                bot_y:        [batch_size x num_particles]
                bot_x:        [batch_size x num_particles]
                bot_dir:      [batch_size x num_particles]: rad
        # y=2  /   /   /
        # y=1  /   /   /
        # y=0  /   /   /
        #     x=0 x=1 x=2
        #        ^ (90.)
        # < (0.)          > (180.)
        #        V (270.)
        TODO: if there are multiple heads, then they can actually be viewed as
        TODO: multiple particles; think about it again as where should those beliefs
        TODO: of those particles be combined and also whether function should return
        TODO: the max over all the particles or just the individual beliefs of each
        TODO: particle and also how to view the connection of the write/read weights
        """
        batch_size = particle_weights_vb.size(0)
        num_particles = particle_weights_vb.size(1)
        assert self.map_hei * self.map_wid == particle_weights_vb.size(2)
        # first we need to localize
        # NOTE: here we are only gettint the index
        # NOTE: so no need to do the computation in Variables
        particle_weights_ts = particle_weights_vb.data
        _, max_ind = torch.max(particle_weights_ts, 2)
        bot_y = max_ind / self.map_wid
        bot_x = max_ind % self.map_wid
        bot_y = bot_y.squeeze(2)
        bot_x = bot_x.squeeze(2)
        # NOTE: now we get the direction by looking at the densist direction of mass
        # NOTE: of direction from this position
        bot_dir = torch.zeros(batch_size, num_particles)
        max_density = 0.
        for batch_ind in range(batch_size):
            for particle_ind in range(num_particles):
                for dir in range(0, 4):
                    local_sensing_area_indices_ts = self.sensing_area_indices_ts[bot_y[batch_ind][particle_ind]][bot_x[batch_ind][particle_ind]][dir * 90]
                    particle_density_ts = particle_weights_ts[batch_ind][particle_ind] * local_sensing_area_indices_ts
                    if particle_density_ts.sum() >= max_density:
                        max_density = particle_density_ts.sum()
                        bot_dir[batch_ind][particle_ind] = np.deg2rad(90.) * dir - np.deg2rad(180.)
                        if bot_dir[batch_ind][particle_ind] < np.deg2rad(0.):
                            bot_dir[batch_ind][particle_ind] += np.deg2rad(360.)
        return bot_y, bot_x, bot_dir

    # motion funcs
    def _transform(self, particle_weights_vb, transform_ts):
        """
        variables needed:
            particle_weights_vb:    [(map_hei x map_wid)]
            transform_ts:           [3 x 3]
        returns:
            transformed_weights_vb: [mem_hei x map_wid]
        NOTE: we transform the weight by the transformation defined in transform_ts
        NOTE: inside this function the graph cannot be lost
        http://www.euclideanspace.com/maths/geometry/affine/aroundPoint/matrix2d/
        """
        # 0. we first prepare the indices of all the points in the current weight
        # y=2  /   /   /
        # y=1  /   /   /
        # y=0  /   /   /
        #     x=0 x=1 x=2
        indices_ts = torch.ones(3, self.map_hei * self.map_wid) # [x; y; 1]
        for y in range(0, self.map_hei):
            for x in range(0, self.map_wid):
                indices_ts[0][y * self.map_wid + x] = x
                indices_ts[1][y * self.map_wid + x] = y
        # 1. now we transform the indices to get the transformed indices
        transformed_indices_ts    = torch.mm(transform_ts, indices_ts)
        transformed_indices_ts[0] = torch.round(transformed_indices_ts[0]).type(torch.LongTensor) # x
        transformed_indices_ts[1] = torch.round(transformed_indices_ts[1]).type(torch.LongTensor) # y
        # 2. we also would only use those valid points: that after transformation they are still in the current map
        valid_x_indices_ts = torch.ge(transformed_indices_ts[0], 0) * torch.le(transformed_indices_ts[0], self.map_wid-1) # x
        valid_y_indices_ts = torch.ge(transformed_indices_ts[1], 0) * torch.le(transformed_indices_ts[0], self.map_hei-1) # y
        valid_indices_ts = valid_x_indices_ts * valid_y_indices_ts
        # 3. then we clamp the transformed indices
        transformed_indices_ts[0] = torch.clamp(transformed_indices_ts[0], min=0, max=self.map_wid-1) # x
        transformed_indices_ts[1] = torch.clamp(transformed_indices_ts[1], min=0, max=self.map_hei-1) # y
        # 4. finally we get the final indices
        final_indices_ts = transformed_indices_ts[1] * self.map_wid + transformed_indices_ts[0]
        transformed_weights_vb = torch.index_select(particle_weights_vb.view(1, self.map_hei * self.map_wid), 1, Variable(final_indices_ts.type(torch.LongTensor))) * Variable(valid_indices_ts.type(torch.FloatTensor)).view(self.map_hei, self.map_wid)
        return transformed_weights_vb

    def _get_trans_ts(self, trans_x, trans_y):
        """
        translate by trans_x & trans_y
        # http://www.euclideanspace.com/maths/geometry/affine/aroundPoint/matrix2d/
        """
        trans_ts = torch.eye(3, 3)
        trans_ts[0][2] = trans_x
        trans_ts[1][2] = trans_y
        return trans_ts

    def _get_rotat_ts(self, origin_x, origin_y, turn_by):
        """
        rotate turn_by by [origin_x, origin_y]
        # http://www.euclideanspace.com/maths/geometry/affine/aroundPoint/matrix2d/
        """
        r00 =   np.cos(turn_by)
        r01 = - np.sin(turn_by)
        r10 =   np.sin(turn_by)
        r11 =   np.cos(turn_by)
        rotat_ts = torch.zeros(3, 3)
        rotat_ts[0][0] = r00
        rotat_ts[0][1] = r01
        rotat_ts[0][2] = origin_x - r00 * origin_x - r01 * origin_y
        rotat_ts[1][0] = r10
        rotat_ts[1][1] = r11
        rotat_ts[1][2] = origin_y - r10 * origin_x - r11 * origin_y
        rotat_ts[2][2] = 1
        return rotat_ts

    def _translate(self, particle_weights_vb, bot_dir, translate_by=1):
        """
        variables needed:
            particle_weights_vb:         [(map_hei x map_wid)]
            bot_dir:                   > rad, along which direction to do the translation
            translate_by:              > translate by this much distance
        returns:
            updated_particle_weights_vb: [batch_size x num_particles x(mem_hei x map_wid)]
        """
        transform_ts = self._get_trans_ts(np.cos(bot_dir) * translate_by, np.sin(bot_dir) * translate_by)
        return self._transform(particle_weights_vb, transform_ts)

    def _rotate(self, particle_weights_vb, origin_y, origin_x, turn_by):
        """
        variables needed:
            particle_weights_vb:         [(map_hei x map_wid)]
            [origin_y, origin_x]:      > rotate around this point
            turn_by:                   > rad, rotate by this much
        returns:
            updated_particle_weights_vb: [batch_size x num_particles x(mem_hei x map_wid)]
        """
        transform_ts = self._get_rotat_ts(origin_x, origin_y, turn_by)
        return self._transform(particle_weights_vb, transform_ts)

    # put them together
    def apply_motion(self, particle_weights_vb, actions):
        """
        variables needed:
            particle_weights_vb:         [batch_size x num_particles x(map_hei x map_wid)]
            actions:                     [batch_size]
                                       > all the heads in the same batch use the same motion
        returns:
            updated_particle_weights_vb: [batch_size x num_particles x(mem_hei x map_wid)]
        """
        # we first need to localize
        bot_y, bot_x, bot_dir = self._localize(particle_weights_vb)
        # print("................................................................. localize:", bot_y[0][0], bot_x[0][0], np.rad2deg(bot_dir[0][0]))
        # then we iterate throught all the batches
        # NOTE: all the heads in one batch use the same action
        batch_size = particle_weights_vb.size(0)
        num_particles = particle_weights_vb.size(1)
        assert self.map_hei * self.map_wid == particle_weights_vb.size(2)
        updated_particle_weights_vb = []
        for batch_ind in range(batch_size):
            action = actions[batch_ind]
            for particle_ind in range(num_particles):
                if self.env_type == "grid-world":
                    if action == 0:     # stand still
                        updated_particle_weights_vb.append(particle_weights_vb[batch_ind][particle_ind])
                    if action == 1:     # turn left
                        updated_particle_weights_vb.append(self._rotate(particle_weights_vb[batch_ind][particle_ind], bot_y[batch_ind][particle_ind], bot_x[batch_ind][particle_ind], np.deg2rad(90.)))
                    elif action == 2:   # turn right
                        updated_particle_weights_vb.append(self._rotate(particle_weights_vb[batch_ind][particle_ind], bot_y[batch_ind][particle_ind], bot_x[batch_ind][particle_ind], np.deg2rad(-90.)))
                    elif action == 3:   # go straight
                        updated_particle_weights_vb.append(self._translate(particle_weights_vb[batch_ind][particle_ind], bot_dir[batch_ind][particle_ind], 1))
                elif self.env_type == "gazebo":
                    if action == 0:     # stand still
                        updated_particle_weights_vb.append(particle_weights_vb[batch_ind][particle_ind])
                    if action == 1:     # turn left
                        updated_particle_weights_vb.append(self._rotate(particle_weights_vb[batch_ind][particle_ind], bot_y[batch_ind][particle_ind], bot_x[batch_ind][particle_ind], np.deg2rad(22.5)))
                    elif action == 2:   # turn right
                        updated_particle_weights_vb.append(self._rotate(particle_weights_vb[batch_ind][particle_ind], bot_y[batch_ind][particle_ind], bot_x[batch_ind][particle_ind], np.deg2rad(-22.5)))
                    elif action == 3:   # go straight
                        updated_particle_weights_vb.append(self._translate(particle_weights_vb[batch_ind][particle_ind], bot_dir[batch_ind][particle_ind], 1))
        return torch.cat(updated_particle_weights_vb, 0).view(batch_size, num_particles, self.map_hei * self.map_wid)

# from utils.kernels import gaussian_kernel
# batch_size = 2
# num_heads = 1
# mem_hei = 16
# mem_wid = 16
# laser_len = 3
# mem_init_y_min = 0
# mem_init_y_max = 4
# mem_init_x_min = 2
# mem_init_x_max = 4
# wl_prev_ts = torch.zeros(batch_size, num_heads, mem_hei, mem_wid)
# wl_prev_ts[0, :, mem_init_y_min:mem_init_y_max+1, mem_init_x_min:mem_init_x_max+1] = gaussian_kernel().unsqueeze(0).unsqueeze(0).expand(1, num_heads, mem_init_y_max+1-mem_init_y_min, mem_init_x_max+1-mem_init_x_min)
# wl_prev_ts[1, :, mem_init_x_min+2:mem_init_x_max+3, mem_init_y_min:mem_init_y_max+1] = gaussian_kernel().transpose(0, 1).unsqueeze(0).unsqueeze(0).expand(1, num_heads, mem_init_x_max+1-mem_init_x_min, mem_init_y_max+1-mem_init_y_min)
# wl_prev_ts = wl_prev_ts.view(batch_size, num_heads, mem_hei * mem_wid)
# wl_prev_vb = Variable(wl_prev_ts)
# print(wl_prev_vb[0].view(mem_hei, mem_wid))
# print(wl_prev_vb[1].view(mem_hei, mem_wid))
# actions = []
# actions.append(1)
# actions.append(3)
# print(actions)
#
# import os
# root_dir = os.getcwd()
# motion_model = MotionModel(root_dir, mem_hei, mem_wid, laser_len)
# print(motion_model.apply_motion(wl_prev_vb, actions).view(batch_size, num_heads, mem_hei,mem_wid))
