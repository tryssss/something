from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import numpy as np
import tf   # NOTE: we do it here cos will report error if imported after torch

from utils.options import Options
from utils.factory import EnvDict, ModelDict, AgentDict

# 0. setting up
opt = Options()
np.random.seed(opt.seed)

# 1. env   (prototype)
env_prototype   = EnvDict[opt.env_type]
# 2. model (prototype)
model_prototype = ModelDict[opt.model_type]
# 3. agent
agent = AgentDict[opt.agent_type](opt.agent_params,
                                  env_prototype   = env_prototype,
                                  model_prototype = model_prototype)
# 4. fit model
if opt.mode == 1:   # train
    agent.fit_model()
elif opt.mode == 2: # test opt.model_file
    agent.test_model()

# 5. wrap up
del opt, env_prototype, model_prototype, agent
