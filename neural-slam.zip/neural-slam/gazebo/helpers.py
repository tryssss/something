from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import numpy as np
import roslib
import rospy
import math
import tf
import geometry_msgs.msg

def pose_2_pose_msg(pose):
    """
    variables needed:
        pose: [y, x, dir]   NOTE: dir: [0, 3]
    returns:
        pose_msg:
            position:       Point
            orientation:    Quaternion
    we only initialize the bot's direction in sharp angles
    then we dicretize the angle also to sharp angles to isualize
    """
    pose_msg = geometry_msgs.msg.Pose()
    # position
    pose_msg.position.x = pose[1] - 4.5
    pose_msg.position.y = 4.5 - pose[0]
    pose_msg.position.z = 0 # TODO: set to defalut value
    # orientation
    quaternion = tf.transformations.quaternion_from_euler(0, 0, np.deg2rad(360.) - np.deg2rad(90.) * pose[2])
    pose_msg.orientation.x = quaternion[0]
    pose_msg.orientation.y = quaternion[1]
    pose_msg.orientation.z = quaternion[2]
    pose_msg.orientation.w = quaternion[3]
    # wrap up
    return pose_msg

def pose_msg_2_pose(pose_msg):
    """
    variables needed:
        pose_msg:
            position:       Point
            orientation:    Quaternion
    returns:
        pose: [y, x, dir]   NOTE: dir: [0, 3]
    """
    pose = np.array([0, 0, 0]) # [y, x, dir]
    # position
    pose[0] = np.ceil(4 - pose_msg.position.y) # y
    pose[1] = np.ceil( pose_msg.position.x + 4) # x
    # orientation
    quaternion = (
        pose_msg.orientation.x,
        pose_msg.orientation.y,
        pose_msg.orientation.z,
        pose_msg.orientation.w
    )
    euler = tf.transformations.euler_from_quaternion(quaternion)
    pose[2] = np.rad2deg(euler[2])
    if pose[2] >= 360: pose[2] -= 360
    if pose[2] < 0: pose[2] += 360
    pose[2] = int(360 + 45 - pose[2]) // 90
    if pose[2] >= 4: pose[2] -= 4
    if pose[2] < 0:  pose[2] += 4
    # wrap up
    return pose
