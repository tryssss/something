cp -r ~/catkin_ws/devel/lib/python2.7/dist-packages/gym_style_gazebo/ ~/ws/17_ws/neural-slam/gazebo/
