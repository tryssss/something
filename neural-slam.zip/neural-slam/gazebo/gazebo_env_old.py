from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import numpy as np
from copy import deepcopy
from gym.spaces.box import Box
import inspect
import os, subprocess
import cv2
import time
import rospy, rosgraph
from sensor_msgs.msg import Image
from cv_bridge import CvBridge

from utils.helpers import rgb2gray, bgr2gray, rgb2y, scale
from core.env import Env

class GazeboEnv(Env):
    """Build the gym stle gazebo training env"""

    def __init__(self, args,env_ind=0):
        super(GazeboEnv, self).__init__(args,env_ind)
        self.env_ind = env_ind
        self.enable_continuous = args.enable_continuous
        os.environ["ROS_MASTER_URI"] = "http://rosimage"+str(env_ind)+":11311"
        time.sleep(2)
        self.masteruri = rosgraph.get_master_uri()

        try:
            from geometry_msgs.msg import Twist
            from gazebo.gym_style_gazebo.srv import PytorchRL
        except ImportError as e: self.logger.warning("WARNING: gym not found")

        self.simulation_service = rospy.ServiceProxy('/gazebo_env_io/pytorch_io_service',PytorchRL)
        self.img_encoding_type = args.img_encoding_type
        self.hei_state = args.hei_state
        self.wid_state = args.wid_state
        self.preprocess_mode = args.preprocess_mode if not None else 0 # 0(crop&resize) | 1(rgb2gray) | 2(rgb2y)

        self.logger.warning("Action Space: %s", "2")

        # state space setup
        self.logger.warning("State  Space: %s", "[160,120], 4")
        #config move command
        self.move_command = Twist()
        self.move_command.linear.x = 0
        self.move_command.linear.y = 0
        self.move_command.linear.z = 0
        self.move_command.angular.x = 0
        self.move_command.angular.z = 0
        self.move_command.angular.y = 0

        #config reset flag
        self.set_flag = False

        self.bridge = CvBridge()

        if not self.enable_continuous:
            self.actions = {
                    0:[0,1],
                    1:[0.5,0],
                    2:[-0.5,0],
                    3:[1,0],
                    4:[-1,0],
                    5:[0,0] #only for initialize
                    }

    def __del__(self):
        self.simulation_service.close()

    @property
    def action_dim(self):
        if self.enable_continuous:
            return 2
        else:
            return 5

    @property
    def state_shape(self):
        return (self.hei_state, self.wid_state)

    def visual(self):
        pass
        #if self.visualize:
            #img_ = self._preprocessState(self.exp_state1)[0]
            #self.win_state1 = self.vis.image(img_, env=self.refs, win=self.win_state1, opts=dict(title="state1"))
        #if self.mode == 2:
            #frame_name = self.img_dir + "frame_%04d.jpg" % self.frame_ind
            #self.imsave(frame_name, self.exp_state1)
            #self.logger.warning("Saved  Frame    @ Step: " + str(self.frame_ind) + " To: " + frame_name)
            #self.frame_ind += 1

    def _preprocessState(self, state):

        #img_ = np.nan_to_num(np.array(state[0].data).reshape(
            #state[0].layout.dim[0].size,
            #state[0].layout.dim[1].size,
            #state[0].layout.dim[2].size))
        # TODO add noise to image
        # TODO checkout rgb or depth
        img_ = self.bridge.imgmsg_to_cv2(state[0], self.img_encoding_type)
        if self.preprocess_mode == 3:   # for depth image
            img_ = scale(img_, self.hei_state, self.wid_state) / 8.
        if self.preprocess_mode == 2:   # rgb2y
            img_ = scale(rgb2y(img_), self.hei_state, self.wid_state) / 255.
        elif self.preprocess_mode == 1: # rgb2gray
            img_ = scale(bgr2gray(img_), self.hei_state, self.wid_state) / 255.
        elif self.preprocess_mode == 0: # do nothing
            pass
        img_.reshape((self.hei_state, self.wid_state))

        if self.enable_continuous:
            return [img_, np.array(state[1])]
        else:
            return[img_,
                    np.array(
                [self.exp_reward,
                self.actions[self.action_idx][0],
                self.actions[self.action_idx][1]])
                    ]

    def _preprocessAction(self, action):
        if self.enable_continuous:
            self.move_command.linear.x = action[0,0]
            self.move_command.angular.z = action[0,1]
        else:
            self.move_command.angular.z = self.actions[action][0]
            self.move_command.linear.x = self.actions[action][1]

    def step(self, exp_action):
        self._preprocessAction(exp_action)
        self.action_idx = exp_action
        try:
            os.environ["ROS_MASTER_URI"] = "http://rosimage"+str(self.env_ind)+":11311"
            response = self.simulation_service(self.move_command, self.set_flag)
            self.exp_state1 = [response.state_1, response.state_2.data]
            self.exp_reward = response.reward
            self.exp_terminal1 = response.terminal
        except rospy.ServiceException, e:
            print("Service call failed during step: %s" %e)
        return self._get_experience()

    def render(self):
        if self.mode == 2:
            frame = self.exp_state1[0]
            frame_name = self.img_dir + "Gazebo_frame_%04d.jpg" % self.frame_ind
            self.imsave(frame_name, frame)
            self.logger.warning("Saved  Frame    @ Step: " + str(self.frame_ind) + " To: " + frame_name)
            self.frame_ind += 1
            return frame
        else:
            pass

    def reset(self):
        self._reset_experience()
        self.set_flag = True
        self.action_idx = 5 # ony for initial
        try:
            os.environ["ROS_MASTER_URI"] = "http://rosimage"+str(self.env_ind)+":11311"
            response = self.simulation_service(self.move_command, self.set_flag)
            self.set_flag = False
        except rospy.ServiceException, e:
            print("Service call failed during resetp: %s" %e)
        self.exp_state1 = [response.state_1, response.state_2.data]
        self.exp_reward = response.reward # for the first step input
        return self._get_experience()
