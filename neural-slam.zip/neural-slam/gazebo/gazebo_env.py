from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import numpy as np; np.set_printoptions(threshold=np.nan)
from copy import deepcopy
from gym.spaces.box import Box
import inspect
import os, subprocess
import cv2
import time
import rospy, rosgraph
import tf
import geometry_msgs.msg
from sensor_msgs.msg import Image
from cv_bridge import CvBridge

from geometry_msgs.msg import Twist
from geometry_msgs.msg import Pose
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import OccupancyGrid
from gazebo.gym_style_gazebo.srv import PytorchRL

from utils.helpers import rgb2gray, bgr2gray, rgb2y, scale
from gazebo.helpers import pose_2_pose_msg, pose_msg_2_pose
from core.env import Env

class GazeboEnv(Env):
    def __init__(self, args, env_ind=0):
        super(GazeboEnv, self).__init__(args, env_ind)
        self.env_ind = env_ind
        self.enable_continuous = args.enable_continuous

        # grid-world-specific params
        self.enable_random_init_pose = args.enable_random_init_pose
        self.enable_internal_explore_reward = args.enable_internal_explore_reward
        self.laser_len = args.laser_len
        self.grid_siz = args.grid_siz

        # ros service setup
        # os.environ["ROS_MASTER_URI"] = "http://rosimage"+str(env_ind)+":11311"
        # os.environ["ROS_MASTER_URI"] = "http://172.17.0.2:11311"
        os.environ["ROS_MASTER_URI"] = "http://localhost:11311"
        time.sleep(2)
        self.masteruri = rosgraph.get_master_uri()
        self.gazebo_srv = rospy.ServiceProxy('/gazebo_env_io/pytorch_io_service', PytorchRL)
        self._reset_service()

        # NOTE: for image states
        # self.hei_state = args.hei_state
        # self.wid_state = args.wid_state
        # self.img_encoding_type = args.img_encoding_type
        # self.preprocess_mode = args.preprocess_mode if not None else 0 # 0(crop&resize) | 1(rgb2gray) | 2(rgb2y)
        # self.bridge = CvBridge()

        # NOTE: we make this assumption here that bot always starts at the bottom left facing left
        # NOTE: we make sure all worlds are padded w/ self.view_len-1 1's on the edge
        # TODO: check if this one make sense in the simple.world
        self.bot_pose_reset = np.array([8, 8, 2])           # [y, x, dir]
        self.bot_pose       = self.bot_pose_reset.copy()    # [y, x, dir]
        self.bot_pose_old   = self.bot_pose_reset.copy()    # [y, x, (dir: not really used here)]
        self.res_pose_old   = Pose()

        # action space setup
        if not self.enable_continuous:
            self.actions = { # [linear, angular]
                    # 0: [0.,  np.deg2rad( 0.)], # only for initialize
                    # 1: [0.,  np.deg2rad(45.)],
                    # 2: [0., -np.deg2rad(45.)],
                    # 3: [0.,  np.deg2rad(90.)],
                    # 4: [0., -np.deg2rad(90.)],
                    # 5: [2,   np.deg2rad( 0.)]
                    0: [0.,  np.deg2rad( 0.)], # only for initialize
                    1: [0.,  np.deg2rad(90.)],
                    2: [0., -np.deg2rad(90.)],
                    3: [1.2, np.deg2rad( 0.)]
            }
        self.logger.warning("Action Space: %s", self.actions)    # TODO

        # state space setup
        if self.game == "simple":   # here just train on the same world # TODO: check if possible to load different maps in different courses
            from gazebo.worlds import worlds as worlds
            self.worlds = worlds
            self.map_siz = self.worlds[len(self.worlds)-1].shape[0]
        self.logger.warning("State  Space: %s", "[160, 120], 4") # TODO

        # additional display setup
        if self.visualize:
            self.win_world  = "win_world"   # the whole world
            # self.win_local  = "win_local"   # laser scan
            # self.win_map    = "win_map"     # state1[1]: explored areas in the map

    def __del__(self):
        self.gazebo_srv.close()

    def _reset_service(self):
        # request: action
        self.req_action_reset = Twist()
        self.req_action_reset.linear.x = 0.
        self.req_action_reset.linear.y = 0.
        self.req_action_reset.linear.z = 0.
        self.req_action_reset.angular.x = 0.
        self.req_action_reset.angular.z = 0.
        self.req_action_reset.angular.y = 0.
        # request: init_pose
        self.req_init_pose_reset = Pose()
        self.req_init_pose_reset.position.x = 0.
        self.req_init_pose_reset.position.y = 0.
        self.req_init_pose_reset.position.z = 0.
        self.req_init_pose_reset.orientation.x = 0.
        self.req_init_pose_reset.orientation.y = 0.
        self.req_init_pose_reset.orientation.z = 0.
        self.req_init_pose_reset.orientation.w = 1.
        # request: reset
        self.req_reset_reset = False
        # reset
        self.req_action = Twist()
        self.req_init_pose = Pose()
        self.req_reset = False
        self._reset_request()

    def _reset_request(self):
        self._reset_req_action()
        self._reset_req_init_pose()
        self._reset_req_reset()

    def _reset_req_action(self):
        self.req_action.linear.x  = self.req_action_reset.linear.x
        self.req_action.linear.y  = self.req_action_reset.linear.y
        self.req_action.linear.z  = self.req_action_reset.linear.z
        self.req_action.angular.x = self.req_action_reset.angular.x
        self.req_action.angular.y = self.req_action_reset.angular.y
        self.req_action.angular.z = self.req_action_reset.angular.z

    def _reset_req_init_pose(self):
        self.req_init_pose.position.x = self.req_init_pose_reset.position.x
        self.req_init_pose.position.y = self.req_init_pose_reset.position.y
        self.req_init_pose.position.z = self.req_init_pose_reset.position.z
        self.req_init_pose.orientation.x = self.req_init_pose_reset.orientation.x
        self.req_init_pose.orientation.y = self.req_init_pose_reset.orientation.y
        self.req_init_pose.orientation.z = self.req_init_pose_reset.orientation.z
        self.req_init_pose.orientation.w = self.req_init_pose_reset.orientation.w

    def _reset_req_reset(self):
        self.req_reset = self.req_reset_reset

    def _reset_experience(self):
        self.exp_state0 = None  # NOTE: always None in this module
        self.exp_action = None
        self.exp_reward = None
        self.exp_state1 = []    # [0]: laser scan, [1]: map, [2]: pose
        self.exp_terminal1 = None

    # def _preprocessState(self, state, action):
    #     # 1. we first compute how much had the pose actually changed
    #     print("==========================>", action)
    #     print(self.res_pose)
    #     print(self.res_pose_old)
    #     # 4. keep track of old poses    # NOTE: old pose has already been erased from world now
    #     self.res_pose_old.position.x = self.res_pose.position.x
    #     self.res_pose_old.position.y = self.res_pose.position.y
    #     self.res_pose_old.position.z = self.res_pose.position.z
    #     self.res_pose_old.orientation.x = self.res_pose.orientation.x
    #     self.res_pose_old.orientation.y = self.res_pose.orientation.y
    #     self.res_pose_old.orientation.z = self.res_pose.orientation.z
    #     self.res_pose_old.orientation.w = self.res_pose.orientation.w
    #     self.bot_pose_old = self.bot_pose.copy()
    #     # prepare the action command
    #     motion_command = []
    #     motion_command.append(action)   # 0: action_ind
    #     if action == 0:                 # 1: linear; 2: angular
    #         motion_command.append(0)
    #         motion_command.append(np.deg2rad(0.))
    #     elif action == 1:
    #         motion_command.append(0)
    #         motion_command.append(np.deg2rad(45.))
    #     elif action == 2:
    #         motion_command.append(0)
    #         motion_command.append(np.deg2rad(-45.))
    #     elif action == 3:
    #         motion_command.append(1)
    #         motion_command.append(np.deg2rad(0.))
    #     return [state[0], state[1], motion_command]

    def _preprocessState(self, state):
        # # 1. we first compute how much had the pose actually changed
        # print(self.res_pose)
        # print(self.res_pose_old)
        # # 1.1 rotation
        # quat = (
        #     self.res_pose.orientation.x,
        #     self.res_pose.orientation.y,
        #     self.res_pose.orientation.z,
        #     self.res_pose.orientation.w
        # )
        # quat_old = (
        #     self.res_pose_old.orientation.x,
        #     self.res_pose_old.orientation.y,
        #     self.res_pose_old.orientation.z,
        #     self.res_pose_old.orientation.w
        # )
        # euler     = tf.transformations.euler_from_quaternion(quat)
        # euler_old = tf.transformations.euler_from_quaternion(quat_old)
        # print(np.rad2deg(euler[2]), np.rad2deg(euler_old[2]))
        # # 1.2 translation
        # print(np.sqrt((self.res_pose.position.x - self.res_pose_old.position.x) ** 2 +
        #               (self.res_pose.position.y - self.res_pose_old.position.y) ** 2 +
        #               (self.res_pose.position.z - self.res_pose_old.position.z) ** 2))
        # 2. keep track of old poses    # NOTE: old pose has already been erased from world now
        self.res_pose_old.position.x = self.res_pose.position.x
        self.res_pose_old.position.y = self.res_pose.position.y
        self.res_pose_old.position.z = self.res_pose.position.z
        self.res_pose_old.orientation.x = self.res_pose.orientation.x
        self.res_pose_old.orientation.y = self.res_pose.orientation.y
        self.res_pose_old.orientation.z = self.res_pose.orientation.z
        self.res_pose_old.orientation.w = self.res_pose.orientation.w
        self.bot_pose_old = self.bot_pose.copy()
        return state

    def _preprocessAction(self, action_ind):
        if self.enable_continuous:
            self.req_action.linear.x  = action[0, 0]
            self.req_action.angular.z = action[0, 1]
        else:
            self.req_action.linear.x  = self.actions[action_ind][0]
            self.req_action.angular.z = self.actions[action_ind][1]

    @property
    def state_shape(self):  # TODO: set # laser ranges
        # return [181, 32 * 32]
        return [15, 32 * 32]

    @property
    def action_dim(self):
        if self.enable_continuous:
            return 2
        else:
            return len(self.actions)

    @property
    def mem_siz(self):
        return self.map_siz

    @property
    def init_pose(self):    # NOTE: should only be called after reset
        return self.bot_pose

    def visual(self):
        if self.visualize:
            self.win_world  = self.vis.image(self._mat_to_img(self._draw_dir(self._expand_mat(self.world))), env=self.refs, win=self.win_world,  opts=dict(title="world"))
            # self.win_local  = self.vis.image(self._mat_to_img(self._expand_mat(self.exp_state1[0])),         env=self.refs, win=self.win_local,  opts=dict(title="state1[0]:local"))
            # self.win_map    = self.vis.image(self._mat_to_img(self._expand_mat(self.exp_state1[1])),         env=self.refs, win=self.win_map,    opts=dict(title="state1[1]:map"))

    def render(self):
        if self.mode == 2:
            frame = self.exp_state1[0]
            frame_name = self.img_dir + "Gazebo_frame_%04d.jpg" % self.frame_ind
            self.imsave(frame_name, frame)
            self.logger.warning("Saved  Frame    @ Step: " + str(self.frame_ind) + " To: " + frame_name)
            self.frame_ind += 1
            return frame
        else:
            pass

    @property
    def latest_course_ind(self):
        return 0

    @property
    def num_explored_grid(self):    # TODO: maybe we check this later
        return self.explored_area_old

    def _call_gazebo_srv(self):
        response = None
	while response is None:
            try:
                # os.environ["ROS_MASTER_URI"] = "http://rosimage" + str(self.env_ind) + ":11311"
                # os.environ["ROS_MASTER_URI"] = "http://172.17.0.2:11311"
                os.environ["ROS_MASTER_URI"] = "http://localhost:11311"
                response = self.gazebo_srv(self.req_action, self.req_init_pose, self.req_reset)
            except rospy.ServiceException, e:
                print("Service call failed during step: %s" %e)
        return response

    def reset(self, _): # NOTE: to be consistent w/ the format of grid-world, cos here we only train on one map
        # 0. setting up
        self._reset_experience()
        self._reset_request()
        # 1. reset world
        # 1.1. load new world
        self.world_original = self.worlds[0].copy()
        self.world = self.worlds[0].copy()
        self.world_hei = self.world.shape[0]
        self.world_wid = self.world.shape[1]
        # 2. reset bot's starting pose
        if self.enable_random_init_pose:
            num_free_cells = self.world_hei * self.world_wid - self.world.sum()
            free_cell_lst = []
            for y in range(self.world_hei):
                for x in range(self.world_wid):
                    if self.world[y][x] == 0:   # free
                        free_cell_lst.append([y, x])
            assert len(free_cell_lst) == self.world_hei * self.world_wid - self.world.sum()
            init_pose_ind = np.random.randint(len(free_cell_lst))
            self.bot_pose[0]  = free_cell_lst[init_pose_ind][0]
            self.bot_pose[1]  = free_cell_lst[init_pose_ind][1]
            self.bot_pose[2]  = np.random.randint(4)    # TODO: num directions
        else:
            self.bot_pose = self.bot_pose_reset.copy()
        # 3. call service
        self.req_init_pose = pose_2_pose_msg(self.bot_pose)
        self.req_reset = True
        response = self._call_gazebo_srv()
        while response is None or \
              np.abs(response.state_3.position.x - self.req_init_pose.position.x) >= 0.1 or \
              np.abs(response.state_3.position.y - self.req_init_pose.position.y) >= 0.1:
            response = self._call_gazebo_srv()
        # 4. fill in experience
        # 4.2 state_2: OccupancyGrid
        # NOTE: here we only use state_2 to get the initial explored_area
        res_map_hei = response.state_2.info.height
        res_map_wid = response.state_2.info.width
        res_map_original = np.array(response.state_2.data).reshape(res_map_hei, res_map_wid)
        res_map = np.ones(res_map_original.shape) * 0.5         # NOTE: not really used for now
        res_map[res_map_original ==   0] = 0
        res_map[res_map_original == 100] = 1
        self.explored_area_old = np.sum(res_map_original >= 0)  # NOTE: all initialized w/ -1
        # 4.3 state_3: current pose
        self.res_pose = response.state_3
        self.bot_pose = pose_msg_2_pose(self.res_pose)
        self.res_pose_old.position.x = self.res_pose.position.x
        self.res_pose_old.position.y = self.res_pose.position.y
        self.res_pose_old.position.z = self.res_pose.position.z
        self.res_pose_old.orientation.x = self.res_pose.orientation.x
        self.res_pose_old.orientation.y = self.res_pose.orientation.y
        self.res_pose_old.orientation.z = self.res_pose.orientation.z
        self.res_pose_old.orientation.w = self.res_pose.orientation.w
        self.bot_pose_old = self.bot_pose.copy()
        # NOTE: for the first several frames, the map returned will still be the same as the last frame from the last episode
        # NOTE: which might already be satisfying the terminal condition, which we don't want
        # NOTE: so we force it to not terminal until th explored_area actually have changed (meaning that the returned is finally from this current episode)
        self.could_terminal = False
        # 5. wrap up
        return self.step(0) # NOTE: need to do this here cos there's a lag, so we use the pose after calling step here

    def step(self, act_ind=0):
        # 0. setting up
        self.exp_action    = act_ind
        self.exp_reward    = -0.005 # TODO: check the scale again # NOTE: we just add step cost here, other rewards will be added in _act
        self.exp_state1    = []     # NOTE
        self.exp_terminal1 = False
        self._reset_request()
        # 1. erase bot's last pose on world (for visualization)
        self.world[self.bot_pose_old[0]][self.bot_pose_old[1]] = self.world_original[self.bot_pose_old[0]][self.bot_pose_old[1]]
        # 2. prepare action & call service
        self._preprocessAction(self.exp_action)
        response = self._call_gazebo_srv()
        # 3. fill in experience
        # 3.1 state_1: laser ranges # NOTE: normalize by max_range
        res_laser = np.array(response.state_1.ranges) / response.state_1.range_max
        res_laser[np.isinf(res_laser)] = 1. # NOTE: we set those out of range values to 1
        res_laser[np.isnan(res_laser)] = 0. # NOTE: we set those too near            to 0
        self.exp_state1.append(res_laser)
        # 3.2 state_2: OccupancyGrid
        res_map_hei = response.state_2.info.height
        res_map_wid = response.state_2.info.width
        res_map_original = np.array(response.state_2.data).reshape(res_map_hei, res_map_wid)
        res_map = np.ones(res_map_original.shape) * 0.5
        res_map[res_map_original ==   0] = 0
        res_map[res_map_original == 100] = 1
        self.explored_area = np.sum(res_map_original >= 0)
        if not self.could_terminal and self.explored_area != self.explored_area_old:
            self.could_terminal = True
        self.exp_state1.append(res_map)
        # NOTE: here we also add the exploration reward
        if not self.enable_internal_explore_reward: # NOTE: only calculate the explore_reward using the true map here if not using internal map to calculate
            # explore_reward = np.maximum(self.explored_area - self.explored_area_old, 0) * 0.01
            explore_reward = np.minimum(np.maximum(self.explored_area - self.explored_area_old, 0) / (np.pi * self.laser_len ** 2 / 2), 1)
            self.exp_reward += explore_reward * 0.1             # NOTE: check the scale here again
        if self.could_terminal and self.explored_area >= 98:    # NOTE: check here again
            self.exp_reward = 1.                                # NOTE: check the scale here again
            self.exp_terminal1 = True
        self.explored_area_old = self.explored_area
        # 3.3 state_3: current pose
        self.res_pose = response.state_3
        self.bot_pose = pose_msg_2_pose(self.res_pose)
        # NOTE: we use this to check collision
        if not self.exp_terminal1 and self.world_original[self.bot_pose[0]][self.bot_pose[1]] == 1:
            self.exp_reward = -0.05         # NOTE: if collision, just give -0.05
        # # 4. keep track of old poses        # NOTE: old pose has already been erased from world now
        # self.bot_pose_old = self.bot_pose.copy()
        # 5. indicate bot's current position
        self.world[self.bot_pose[0]][self.bot_pose[1]] = 0.25
        # 6. wrap up
        return self._get_experience()
