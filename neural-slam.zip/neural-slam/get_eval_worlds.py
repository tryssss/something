from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import matplotlib.pyplot as plt
import numpy as np
import random
import time
import torch

from utils.options import Options
from utils.grid_world_generator import GridWorldGenerator

laser_len = 3
world_generator = GridWorldGenerator(laser_len)

worlds = []
for course_ind in range(5):
    print(course_ind)
    tmp_worlds = []
    for world_ind in range(1000):
        tmp_worlds.append(world_generator.get_new(course_ind))
    worlds.append(tmp_worlds)

opt = Options()
print(opt.eval_worlds_fil)
torch.save(worlds, opt.eval_worlds_fil)

# eval_worlds = torch.load(opt.eval_worlds_fil)

# print(worlds[0][0])
# plt.imshow(1-worlds[2][5], cmap='hot', interpolation='nearest')
# plt.show()
