from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import matplotlib.pyplot as plt
import numpy as np
import torch

from utils.options import Options

opt = Options()

steps_fil  = opt.root_dir + "/data/episode_steps_grid_world_4.pt"
reward_fil = opt.root_dir + "/data/episode_reward_grid_world_4.pt"
episodes_steps_log_ts  = torch.load(steps_fil)
episodes_reward_log_ts = torch.load(reward_fil)

plt.hist(episodes_steps_log_ts, 50, normed=1, facecolor='green', alpha=0.75)
plt.show()

print(episodes_steps_log_ts.mean())
print(episodes_steps_log_ts.std())
print(episodes_steps_log_ts.min())
print(episodes_steps_log_ts.max())
print(episodes_reward_log_ts.mean())
print(episodes_reward_log_ts.std())
print(episodes_reward_log_ts.min())
print(episodes_reward_log_ts.max())
